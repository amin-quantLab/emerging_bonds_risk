# %% END-TO-END THESIS PIPELINE OPTIMIZER
#!/usr/bin/env python3
"""
End-to-end optimizer for the regime-aware EM corporate-bond thesis pipeline.

The optimizer controls all three empirical stages:
    1. feature_engineering.py
       Tests alternative rolling windows, macro transformations, liquidity
       windows, FX/GPR standardisation settings, and LATAM credit-risk methods.
    2. data_cleaning.py
       Runs the complete cleaning and screening pipeline for every generated
       feature dataset, varying correlation/VIF thresholds and panel choices.
    3. master_thesis_analysis.py
       Tests alternative feature subsets, PCA/HMM specifications, robust OLS
       covariance estimators, winsorisation bounds, and regime smoothing.

Search objective
----------------
The winning specification balances:
    - HMM-conditioned R² and adjusted R²;
    - fraction of statistically significant coefficients;
    - absolute contribution share of the Regime component;
    - incremental R² added by the HMM-conditioned specification;
    - significance of direct regime and block×regime terms;
    - minimum HMM stability/occupancy safeguards.

No plots are produced during search. Only after the complete search does the
script rerun the exact winning specification and save every final chart as a
standalone HTML file.

Output policy
-------------
The script creates exactly one persistent folder inside OUTPUT_DIR:
    OUTPUT_DIR / "main_results"

That folder is flat: no trials/, best_run/, model_results/, or plot subfolders.
It contains LaTeX/Overleaf-ready CSV tables, one consolidated Excel workbook,
the optimizer leaderboards, the winning configuration, and all final plots as
HTML. Feature-engineering, cleaning, and trial-model artifacts are created in a
temporary system directory and deleted automatically after the winning rerun.

Important inference note
------------------------
Searching directly on p-values and in-sample R² is specification selection.
The resulting p-values are therefore post-selection statistics, not untouched
confirmatory inference.  Keep the full leaderboard and report this procedure in
thesis methodology; ideally validate the winner on a held-out time period.
"""

from __future__ import annotations

import contextlib
import io
import json
import math
import re
import shutil
import sys
import tempfile
import traceback
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from path_config import DEFAULT_SHEET, OUTPUT_DIR

from cpt_feature_eng import (
    FeatureBuilderConfig,
    make_default_feature_config,
    run_feature_engineering,
)
from data_cleaning import (
    DataCleaningConfig,
    make_cleaning_config,
    run_cleaning,
)
from master_thesis_analysis import (
    RiskDecompositionConfig,
    RegimeRiskDecompositionPipeline,
    is_allowed_model_input_feature,
    is_latam_specific_feature,
    run_analysis,
)


# ==========================================================
# SEARCH SPACES
# ==========================================================

FEATURE_SEARCH_SPACE: dict[str, list[Any]] = {
    "macro_windows": [
        (3,), (5,), (10,), (21,),
        (3, 5), (5, 10), (3, 10),
    ],
    "macro_methods": [
        ("mean",),
        ("ewm",),
        ("median",),
        ("zscore",),
        ("mean", "zscore"),
        ("mean", "diff"),
    ],
    "zr_window": [10, 21, 42, 63],
    "zr_min_periods": [3, 5, 10],
    "roll_credit_risk_features": [False, True],
    "credit_zscore_window_weeks": [26, 52, 104],
    "credit_momentum_window_weeks": [2, 4, 8],
    "credit_vol_window_weeks": [8, 12, 26],
    "credit_max_stale_days": [7, 10, 14],
    "fx_zscore_window": [126, 252, 504],
    "fx_zscore_min_periods": [30, 60, 126],
    "fx_exclude_ars": [False, True],
    "gpr_zscore_window": [24, 36, 60, None],
    "gpr_momentum_window": [6, 12, 18],
    "gpr_vol_window": [6, 12, 24],
}

CLEANING_SEARCH_SPACE: dict[str, list[Any]] = {
    "target_mode": ["weekly_pct_change", "weekly_diff"],
    "target_lag_periods": [1, 2],
    "fixed_coupon_only": [True],
    "exclude_government": [True],
    "drop_option_bonds": [False, True],
    "corr_threshold": [0.70, 0.80, 0.90, 0.95],
    "vif_threshold": [5.0, 10.0, 15.0, 20.0],
    "time_fixed_effect": ["none", "year"],
    "max_dummy_levels": [20, 40],
    "max_corr_features": [30, 45, 60],
    "max_vif_features": [60, 90, 120],
}

MODEL_SEARCH_SPACE: dict[str, list[Any]] = {
    "feature_selection_method": ["all", "random", "block_random", "regime_focused"],
    "feature_fraction": [0.50, 0.70, 0.85, 1.00],
    "hmm_covariance_type": ["diag", "full", "tied", "spherical"],
    "hmm_n_starts": [10, 20, 30, 50],
    "hmm_max_features": [4, 5, 6, 7, 8],
    "n_pca_components": [2, 3, 4],
    "min_isins_per_period": [3, 5, 7],
    "min_regime_duration": [2, 3, 4, 5],
    "ols_cov_type": ["HC3", "HC1", "HC0"],
    "winsorize_lower": [0.005, 0.010, 0.020],
    "winsorize_upper": [0.980, 0.990, 0.995],
    "standardize_features": [True, False],
    "hmm_include_pc1": [True, False],
}

DEFAULT_SCORE_WEIGHTS: dict[str, float] = {
    "r2": 0.25,
    "adjusted_r2": 0.10,
    "significance": 0.20,
    "regime_component_share": 0.20,
    "regime_term_significance": 0.10,
    "regime_incremental_r2": 0.10,
    "regime_stability": 0.05,
}

ENGINEERED_PREFIX_RE = re.compile(r"^(?:MA|MED|EWM|ZS|DIFF|PCT)\d+_")
REGIME_FOCUS_TOKENS = (
    "VIX", "MOVE", "EMBI", "MSCI_EM", "CDS", "JPM_SPREAD",
    "GPR", "EPU", "BFCI", "CDX", "ITRX", "STOXX", "SP500",
    "AONILS", "LATAM", "BZSTSETA", "MXONBR",
)


# ==========================================================
# CONFIGURATION
# ==========================================================

@dataclass
class OptimizerConfig:
    n_data_variants: int = 6
    n_model_variants_per_data: int = 12
    universe_mode: str = "LATAM"
    random_seed: int = 42

    source_target_col: str = "Z_SPREAD_MID"
    sheet_name: int | str = DEFAULT_SHEET

    # Exactly one persistent folder is created under OUTPUT_DIR.
    output_root: str = str(OUTPUT_DIR / "main_results")
    intermediate_format: str = "parquet"  # parquet | csv | xlsx

    # Output behaviour.
    reset_output_folder: bool = True
    save_every_n_models: int = 10
    min_required_rows: int = 5000
    export_final_tables: bool = True
    export_row_level_decomposition: bool = False
    save_final_plots_html: bool = True
    show_final_plots: bool = False
    html_include_plotlyjs: bool = True
    main_workbook_name: str = "main_results.xlsx"

    min_regime_occupancy: float = 0.02
    min_avg_self_transition: float = 0.50
    require_three_regimes: bool = True

    score_weights: dict[str, float] = field(
        default_factory=lambda: dict(DEFAULT_SCORE_WEIGHTS)
    )

    def __post_init__(self) -> None:
        self.universe_mode = str(self.universe_mode).upper().strip()
        if self.universe_mode not in {"LATAM", "ALL_EM"}:
            raise ValueError("universe_mode must be 'LATAM' or 'ALL_EM'.")
        if self.n_data_variants < 1 or self.n_model_variants_per_data < 1:
            raise ValueError("Both iteration counts must be >= 1.")

        self.intermediate_format = (
            str(self.intermediate_format).lower().strip().lstrip(".")
        )
        if self.intermediate_format not in {"parquet", "csv", "xlsx"}:
            raise ValueError(
                "intermediate_format must be parquet, csv, or xlsx."
            )

        self.source_target_col = str(self.source_target_col).upper().strip()
        if self.source_target_col not in {"Z_SPREAD_MID", "Z_SPREAD_BPS"}:
            raise ValueError(
                "source_target_col must be Z_SPREAD_MID or Z_SPREAD_BPS."
            )

        self.output_root = str(Path(self.output_root))
        if Path(self.output_root).name in {"", ".", ".."}:
            raise ValueError(
                "output_root must point to one named result folder."
            )

        workbook = str(self.main_workbook_name).strip()
        if not workbook.lower().endswith(".xlsx"):
            workbook += ".xlsx"
        self.main_workbook_name = workbook

        if self.save_every_n_models < 1:
            raise ValueError("save_every_n_models must be >= 1.")
        if self.min_required_rows < 1:
            raise ValueError("min_required_rows must be >= 1.")

        unknown = set(self.score_weights) - set(DEFAULT_SCORE_WEIGHTS)
        if unknown:
            raise ValueError(f"Unknown score weight(s): {sorted(unknown)}")
        merged = dict(DEFAULT_SCORE_WEIGHTS)
        merged.update(self.score_weights)
        total = float(sum(merged.values()))
        if total <= 0:
            raise ValueError("Score weights must sum to a positive value.")
        self.score_weights = {
            key: float(value) / total for key, value in merged.items()
        }

    @property
    def use_latam(self) -> bool:
        return self.universe_mode == "LATAM"

    @property
    def root(self) -> Path:
        return Path(self.output_root)


# ==========================================================
# SERIALIZATION / UTILITY HELPERS
# ==========================================================

def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (set, frozenset, tuple)):
        return list(value)
    if pd.isna(value):
        return None
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def json_dumps(value: Any) -> str:
    return json.dumps(value, default=_json_default, sort_keys=True)


def choose(rng: np.random.Generator, values: list[Any]) -> Any:
    return values[int(rng.integers(0, len(values)))]


def sample_space(rng: np.random.Generator, space: dict[str, list[Any]]) -> dict[str, Any]:
    return {key: choose(rng, values) for key, values in space.items()}


def silent_call(func, *args, **kwargs):
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(buffer):
        return func(*args, **kwargs)


def read_table(path: str | Path, sheet_name: int | str = 0) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path, sheet_name=sheet_name)
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".parquet":
        return pd.read_parquet(path)
    raise ValueError(f"Unsupported table format: {path}")


def resolve_intermediate_format(requested: str) -> str:
    if requested != "parquet":
        return requested
    try:
        import pyarrow  # noqa: F401
        return "parquet"
    except Exception:
        print("pyarrow unavailable; intermediate format changed from parquet to csv.")
        return "csv"


def normalized_incremental_r2(value: float, reference_gain: float = 0.10) -> float:
    if pd.isna(value):
        return 0.0
    return float(np.clip(value / reference_gain, 0.0, 1.0))


# ==========================================================
# OBJECTIVE
# ==========================================================

def score_trial(
    metrics: dict[str, float],
    config: OptimizerConfig,
) -> tuple[float, bool, str]:
    """Return weighted score, eligibility flag, and any constraint reason."""
    reasons: list[str] = []

    n_regimes = int(metrics.get("n_regimes_identified", 0) or 0)
    min_occupancy = float(metrics.get("min_regime_occupancy", np.nan))
    avg_self = float(metrics.get("avg_self_transition", np.nan))

    if config.require_three_regimes and n_regimes != 3:
        reasons.append(f"n_regimes={n_regimes}")
    if pd.isna(min_occupancy) or min_occupancy < config.min_regime_occupancy:
        reasons.append(f"min_occupancy={min_occupancy:.4f}")
    if pd.isna(avg_self) or avg_self < config.min_avg_self_transition:
        reasons.append(f"avg_self_transition={avg_self:.4f}")

    values = {
        "r2": float(np.clip(metrics.get("hmm_r2", 0.0), 0.0, 1.0)),
        "adjusted_r2": float(np.clip(metrics.get("hmm_adj_r2", 0.0), 0.0, 1.0)),
        "significance": float(np.clip(metrics.get("pct_significant", 0.0), 0.0, 1.0)),
        "regime_component_share": float(
            np.clip(metrics.get("regime_component_share", 0.0), 0.0, 1.0)
        ),
        "regime_term_significance": float(
            np.clip(metrics.get("pct_regime_terms_significant", 0.0), 0.0, 1.0)
        ),
        "regime_incremental_r2": normalized_incremental_r2(
            metrics.get("regime_incremental_r2", 0.0)
        ),
        "regime_stability": float(np.clip(avg_self if pd.notna(avg_self) else 0.0, 0.0, 1.0)),
    }

    raw_score = float(sum(config.score_weights[k] * values[k] for k in values))
    eligible = not reasons
    # Keep failed-constraint models in the leaderboard, but ensure that a stable
    # admissible model wins whenever one exists.
    final_score = raw_score if eligible else raw_score * 0.50
    return final_score, eligible, " | ".join(reasons)


# ==========================================================
# FEATURE / HMM SUBSET SELECTION
# ==========================================================

def _strip_macro_prefix(feature: str) -> str:
    return ENGINEERED_PREFIX_RE.sub("", str(feature).upper().strip())


def _feature_type_column(feature_df: pd.DataFrame) -> str:
    for candidate in ["FEATURE_TYPE", "TYPE", "BLOCK"]:
        if candidate in feature_df.columns:
            return candidate
    return ""


def select_model_features(
    feature_df: pd.DataFrame,
    *,
    method: str,
    fraction: float,
    rng: np.random.Generator,
    use_latam: bool,
) -> list[str]:
    df = feature_df.copy()
    df.columns = [str(c).upper().strip() for c in df.columns]
    if "FEATURE" not in df.columns:
        raise KeyError("selected_features.csv must contain FEATURE.")

    df["FEATURE"] = df["FEATURE"].astype(str).str.upper().str.strip()
    df = df.loc[df["FEATURE"].map(is_allowed_model_input_feature)].copy()
    if not use_latam:
        df = df.loc[~df["FEATURE"].map(is_latam_specific_feature)].copy()
    df = df.drop_duplicates("FEATURE")

    all_features = df["FEATURE"].tolist()
    if not all_features:
        return []

    method = str(method).lower().strip()
    fraction = float(np.clip(fraction, 0.10, 1.00))
    target_n = max(6, min(len(all_features), int(math.ceil(len(all_features) * fraction))))

    if method == "all" or target_n >= len(all_features):
        return all_features

    if method == "random":
        idx = sorted(rng.choice(len(all_features), size=target_n, replace=False).tolist())
        return [all_features[i] for i in idx]

    if method == "block_random":
        type_col = _feature_type_column(df)
        if not type_col:
            return select_model_features(
                df, method="random", fraction=fraction, rng=rng, use_latam=use_latam
            )
        selected: list[str] = []
        for _, group in df.groupby(type_col, dropna=False):
            feats = group["FEATURE"].tolist()
            n = max(1, min(len(feats), int(math.ceil(len(feats) * fraction))))
            idx = sorted(rng.choice(len(feats), size=n, replace=False).tolist())
            selected.extend(feats[i] for i in idx)
        if len(selected) > target_n:
            idx = sorted(rng.choice(len(selected), size=target_n, replace=False).tolist())
            selected = [selected[i] for i in idx]
        return list(dict.fromkeys(selected))

    if method == "regime_focused":
        focused = [
            f for f in all_features
            if any(token in f for token in REGIME_FOCUS_TOKENS)
        ]
        other = [f for f in all_features if f not in set(focused)]
        selected = list(focused)
        remaining = max(0, target_n - len(selected))
        if remaining and other:
            n = min(remaining, len(other))
            idx = sorted(rng.choice(len(other), size=n, replace=False).tolist())
            selected.extend(other[i] for i in idx)
        if len(selected) > target_n:
            # Keep direct LATAM risk composites and sample the rest.
            mandatory = [f for f in selected if f.startswith("LATAM_")]
            optional = [f for f in selected if f not in mandatory]
            n_optional = max(0, target_n - len(mandatory))
            idx = sorted(rng.choice(len(optional), size=n_optional, replace=False).tolist())
            selected = mandatory + [optional[i] for i in idx]
        return list(dict.fromkeys(selected))

    raise ValueError(f"Unknown feature selection method: {method}")


def candidate_hmm_features(features: list[str], use_latam: bool) -> list[str]:
    candidates: list[str] = []
    for feature in features:
        name = str(feature).upper().strip()
        base = _strip_macro_prefix(name)
        if not use_latam and is_latam_specific_feature(name):
            continue
        if name.startswith("LATAM_") or any(token in base for token in REGIME_FOCUS_TOKENS):
            candidates.append(name)
    return list(dict.fromkeys(candidates))


def sample_hmm_features(
    model_features: list[str],
    max_features: int,
    rng: np.random.Generator,
    use_latam: bool,
) -> list[str]:
    pool = candidate_hmm_features(model_features, use_latam=use_latam)
    n = min(int(max_features), len(pool))
    if n < 2:
        return []
    # Guarantee core market-stress coverage when available, then randomize the rest.
    core_tokens = ("VIX", "MOVE", "EMBI", "MSCI_EM")
    core = []
    for token in core_tokens:
        hit = next((f for f in pool if token in f), None)
        if hit and hit not in core:
            core.append(hit)
    core = core[:n]
    remainder = [f for f in pool if f not in core]
    need = n - len(core)
    if need > 0:
        idx = sorted(rng.choice(len(remainder), size=need, replace=False).tolist())
        core.extend(remainder[i] for i in idx)
    return core


# ==========================================================
# OPTIMIZER
# ==========================================================

class EndToEndPipelineOptimizer:
    def __init__(self, config: OptimizerConfig) -> None:
        self.cfg = config
        self.rng = np.random.default_rng(config.random_seed)
        self.intermediate_format = resolve_intermediate_format(
            config.intermediate_format
        )

        self.trials_dir: Optional[Path] = None

        self.leaderboard_path = self.cfg.root / "optimizer_leaderboard.csv"
        self.data_leaderboard_path = (
            self.cfg.root / "data_variant_leaderboard.csv"
        )
        self.workbook_path = self.cfg.root / self.cfg.main_workbook_name
        self.best_configuration_path = (
            self.cfg.root / "best_configuration.json"
        )

        self.results: list[dict[str, Any]] = []
        self.data_results: list[dict[str, Any]] = []
        self.leaderboard: Optional[pd.DataFrame] = None
        self.best_result: Optional[dict[str, Any]] = None
        self.final_pipeline: Optional[
            RegimeRiskDecompositionPipeline
        ] = None

        self._transient_path_columns: set[str] = {
            "feature_path",
            "clean_path",
            "base_selected_features_path",
            "exact_selected_features_path",
            "selected_features_path",
        }

    # ------------------------------------------------------
    # Search
    # ------------------------------------------------------

    def run(self) -> pd.DataFrame:
        self._prepare_output_folder()

        print("\n" + "=" * 88)
        print("END-TO-END FEATURE → CLEANING → REGIME ANALYSIS OPTIMIZER")
        print("=" * 88)
        print(f"Data variants             : {self.cfg.n_data_variants}")
        print(
            "Model variants / dataset  : "
            f"{self.cfg.n_model_variants_per_data}"
        )
        print(
            "Total planned models      : "
            f"{self.cfg.n_data_variants * self.cfg.n_model_variants_per_data}"
        )
        print(f"Universe                  : {self.cfg.universe_mode}")
        print(f"Intermediate format       : {self.intermediate_format}")
        print(f"Minimum required rows     : {self.cfg.min_required_rows:,}")
        print(f"Single persistent folder  : {self.cfg.root}")
        print("Trial artifacts           : temporary and auto-deleted")
        print("Plots during search       : disabled")
        print("Final plots               : saved as HTML")
        print("=" * 88)

        global_model_id = 0

        with tempfile.TemporaryDirectory(
            prefix="thesis_optimizer_"
        ) as temporary_root:
            self.trials_dir = Path(temporary_root) / "trials"
            self.trials_dir.mkdir(parents=True, exist_ok=True)

            for data_id in range(1, self.cfg.n_data_variants + 1):
                data_dir = self.trials_dir / f"data_{data_id:04d}"
                data_dir.mkdir(parents=True, exist_ok=True)

                fe_params = self._sample_feature_params()
                clean_params = sample_space(
                    self.rng, CLEANING_SEARCH_SPACE
                )

                print(
                    f"\n[Data {data_id:>3}/{self.cfg.n_data_variants}] "
                    "generating and cleaning dataset ...",
                    end=" ",
                    flush=True,
                )
                data_result = self._run_data_variant(
                    data_id,
                    data_dir,
                    fe_params,
                    clean_params,
                )
                self.data_results.append(data_result)

                if data_result["status"] != "ok":
                    print("ERROR")
                    print(
                        str(data_result.get("error_message", ""))[:500]
                    )
                    self._save_progress()
                    continue

                print(
                    "OK — "
                    f"rows={data_result['n_rows']:,}, "
                    f"selected={data_result['n_selected_features']:,}"
                )

                for model_id in range(
                    1,
                    self.cfg.n_model_variants_per_data + 1,
                ):
                    global_model_id += 1
                    model_params = sample_space(
                        self.rng, MODEL_SEARCH_SPACE
                    )
                    result = self._run_model_variant(
                        global_model_id=global_model_id,
                        data_id=data_id,
                        model_id=model_id,
                        data_result=data_result,
                        model_params=model_params,
                    )
                    self.results.append(result)

                    if result["status"] == "ok":
                        flag = (
                            "eligible"
                            if result["eligible"]
                            else "penalized"
                        )
                        print(
                            f"  Model {model_id:>3}/"
                            f"{self.cfg.n_model_variants_per_data} "
                            f"score={result['score']:.4f} "
                            f"R²={result['hmm_r2']:.4f} "
                            f"sig={result['pct_significant']:.1%} "
                            "regime="
                            f"{result['regime_component_share']:.1%} "
                            f"[{flag}]"
                        )
                    else:
                        print(
                            f"  Model {model_id:>3}/"
                            f"{self.cfg.n_model_variants_per_data} "
                            "ERROR — "
                            f"{str(result.get('error_message', ''))[:160]}"
                        )

                    if (
                        global_model_id
                        % self.cfg.save_every_n_models
                        == 0
                    ):
                        self._save_progress()

                self._save_progress()

            self._finalize_leaderboard()
            if (
                self.leaderboard is None
                or self.leaderboard.empty
            ):
                raise RuntimeError(
                    "No successful model trial was produced."
                )

            self.best_result = self._select_best_result()
            self.final_pipeline = self._materialize_and_rerun_best()
            self._save_progress()

        # The temporary directory is now deleted automatically.
        self._print_summary()
        return self.leaderboard

    def _prepare_output_folder(self) -> None:
        root = self.cfg.root
        if root.exists() and self.cfg.reset_output_folder:
            shutil.rmtree(root)
        root.mkdir(parents=True, exist_ok=True)

    def _public_leaderboard(
        self,
        frame: pd.DataFrame,
    ) -> pd.DataFrame:
        if frame is None or frame.empty:
            return pd.DataFrame()
        return frame.drop(
            columns=[
                column
                for column in self._transient_path_columns
                if column in frame.columns
            ],
            errors="ignore",
        ).copy()

    def _public_data_leaderboard(
        self,
        frame: pd.DataFrame,
    ) -> pd.DataFrame:
        if frame is None or frame.empty:
            return pd.DataFrame()
        return frame.drop(
            columns=[
                column
                for column in self._transient_path_columns
                if column in frame.columns
            ],
            errors="ignore",
        ).copy()

    # ------------------------------------------------------
    # Stage 1 + 2: feature engineering and cleaning
    # ------------------------------------------------------

    def _sample_feature_params(self) -> dict[str, Any]:
        params = sample_space(self.rng, FEATURE_SEARCH_SPACE)
        weights = self.rng.dirichlet(np.array([6.0, 3.0, 1.0]))
        params["credit_level_weight"] = float(weights[0])
        params["credit_momentum_weight"] = float(weights[1])
        params["credit_vol_weight"] = float(weights[2])
        return params

    def _make_feature_config(self, params: dict[str, Any]) -> FeatureBuilderConfig:
        return make_default_feature_config(
            macro_windows=tuple(params["macro_windows"]),
            macro_methods=tuple(params["macro_methods"]),
            zr_window=int(params["zr_window"]),
            zr_min_periods=int(params["zr_min_periods"]),
            roll_credit_risk_features=bool(params["roll_credit_risk_features"]),
            credit_overrides={
                "zscore_window_weeks": int(params["credit_zscore_window_weeks"]),
                "momentum_window_weeks": int(params["credit_momentum_window_weeks"]),
                "vol_window_weeks": int(params["credit_vol_window_weeks"]),
                "max_stale_days": int(params["credit_max_stale_days"]),
                "level_weight": float(params["credit_level_weight"]),
                "momentum_weight": float(params["credit_momentum_weight"]),
                "vol_weight": float(params["credit_vol_weight"]),
            },
            fx_overrides={
                "zscore_window": int(params["fx_zscore_window"]),
                "zscore_min_periods": int(params["fx_zscore_min_periods"]),
                "exclude_ars": bool(params["fx_exclude_ars"]),
            },
            gpr_overrides={
                "zscore_window": params["gpr_zscore_window"],
                "momentum_window": int(params["gpr_momentum_window"]),
                "vol_window": int(params["gpr_vol_window"]),
            },
        )

    def _run_data_variant(
        self,
        data_id: int,
        data_dir: Path,
        feature_params: dict[str, Any],
        cleaning_params: dict[str, Any],
    ) -> dict[str, Any]:
        extension = self.intermediate_format
        feature_path = data_dir / f"feature_engineered.{extension}"
        clean_path = data_dir / f"master_clean.{extension}"
        selected_path = data_dir / "selected_features.csv"

        result: dict[str, Any] = {
            "data_id": data_id,
            "status": "error",
            "feature_path": str(feature_path),
            "clean_path": str(clean_path),
            "selected_features_path": str(selected_path),
            "feature_params_json": json_dumps(feature_params),
            "cleaning_params_json": json_dumps(cleaning_params),
            "n_rows": 0,
            "n_selected_features": 0,
            "error_message": "",
        }

        try:
            feature_config = self._make_feature_config(feature_params)
            silent_call(run_feature_engineering, feature_config, feature_path)

            cleaning_config = make_cleaning_config(
                data_path=feature_path,
                output_dataset=clean_path,
                output_features=selected_path,
                sheet_name=0,
                target_col=self.cfg.source_target_col,
                target_mode=str(cleaning_params["target_mode"]),
                target_lag_periods=int(cleaning_params["target_lag_periods"]),
                latam_only=self.cfg.use_latam,
                fixed_coupon_only=bool(cleaning_params["fixed_coupon_only"]),
                exclude_government=bool(cleaning_params["exclude_government"]),
                drop_option_bonds=bool(cleaning_params["drop_option_bonds"]),
                corr_threshold=float(cleaning_params["corr_threshold"]),
                vif_threshold=float(cleaning_params["vif_threshold"]),
                time_fixed_effect=str(cleaning_params["time_fixed_effect"]),
                max_dummy_levels=int(cleaning_params["max_dummy_levels"]),
                max_corr_features=int(cleaning_params["max_corr_features"]),
                max_vif_features=int(cleaning_params["max_vif_features"]),
            )
            pipeline = silent_call(
                run_cleaning,
                cleaning_config,
                show_plots=False,
                sanitize_features=True,
            )

            if not clean_path.exists() or not selected_path.exists():
                raise FileNotFoundError("Cleaning stage did not produce required outputs.")

            n_rows = int(len(pipeline.df)) if pipeline.df is not None else 0
            if n_rows < self.cfg.min_required_rows:
                raise ValueError(
                    f"Cleaned dataset has {n_rows:,} rows; "
                    f"minimum required is {self.cfg.min_required_rows:,}."
                )

            result.update({
                "status": "ok",
                "n_rows": n_rows,
                "n_selected_features": int(len(pipeline.selected_features)),
            })
        except Exception:
            result["error_message"] = traceback.format_exc(limit=8)

        return result

    # ------------------------------------------------------
    # Stage 3: analysis specifications
    # ------------------------------------------------------

    def _run_model_variant(
        self,
        *,
        global_model_id: int,
        data_id: int,
        model_id: int,
        data_result: dict[str, Any],
        model_params: dict[str, Any],
    ) -> dict[str, Any]:
        model_dir = self.trials_dir / f"data_{data_id:04d}" / f"model_{model_id:04d}"
        model_dir.mkdir(parents=True, exist_ok=True)
        exact_features_path = model_dir / "selected_features_exact.csv"

        result: dict[str, Any] = {
            "global_model_id": global_model_id,
            "data_id": data_id,
            "model_id": model_id,
            "status": "error",
            "eligible": False,
            "score": np.nan,
            "constraint_reason": "",
            "feature_path": data_result["feature_path"],
            "clean_path": data_result["clean_path"],
            "base_selected_features_path": data_result["selected_features_path"],
            "exact_selected_features_path": str(exact_features_path),
            "feature_params_json": data_result["feature_params_json"],
            "cleaning_params_json": data_result["cleaning_params_json"],
            "model_params_json": json_dumps(model_params),
            "exact_features_json": "[]",
            "hmm_features_json": "[]",
            "error_message": "",
        }

        try:
            feature_df = pd.read_csv(data_result["selected_features_path"])
            selected = select_model_features(
                feature_df,
                method=str(model_params["feature_selection_method"]),
                fraction=float(model_params["feature_fraction"]),
                rng=self.rng,
                use_latam=self.cfg.use_latam,
            )
            if len(selected) < 4:
                raise ValueError(f"Only {len(selected)} model features selected.")

            normalized = feature_df.copy()
            normalized.columns = [str(c).upper().strip() for c in normalized.columns]
            normalized["FEATURE"] = normalized["FEATURE"].astype(str).str.upper().str.strip()
            exact_df = normalized.loc[normalized["FEATURE"].isin(selected)].copy()
            exact_df.to_csv(exact_features_path, index=False)

            hmm_features = sample_hmm_features(
                selected,
                max_features=int(model_params["hmm_max_features"]),
                rng=self.rng,
                use_latam=self.cfg.use_latam,
            )
            if len(hmm_features) < 2:
                raise ValueError("Fewer than two valid HMM state features.")

            cleaning_params = json.loads(data_result["cleaning_params_json"])
            analysis_config = RiskDecompositionConfig(
                data_path=data_result["clean_path"],
                features_path=str(exact_features_path),
                sheet_name=0,
                universe_mode=self.cfg.universe_mode,
                use_latam_specific_inputs=self.cfg.use_latam,
                target_col="MODEL_TARGET_LEVEL",
                regime_target_col="MODEL_TARGET",
                source_target_col=self.cfg.source_target_col,
                target_mode_label=str(cleaning_params["target_mode"]),
                winsorize_target=True,
                winsorize_lower=float(model_params["winsorize_lower"]),
                winsorize_upper=float(model_params["winsorize_upper"]),
                ols_cov_type=str(model_params["ols_cov_type"]),
                standardize_features=bool(model_params["standardize_features"]),
                n_pca_components=int(model_params["n_pca_components"]),
                min_isins_per_period=int(model_params["min_isins_per_period"]),
                n_regimes=3,
                hmm_covariance_type=str(model_params["hmm_covariance_type"]),
                hmm_n_iter=400,
                hmm_tol=1e-4,
                hmm_n_starts=int(model_params["hmm_n_starts"]),
                hmm_random_state=self.cfg.random_seed + global_model_id,
                hmm_include_pc1=bool(model_params["hmm_include_pc1"]),
                hmm_features=hmm_features,
                hmm_auto_select_features=False,
                hmm_max_features=int(model_params["hmm_max_features"]),
                smooth_regime_states=True,
                min_regime_duration=int(model_params["min_regime_duration"]),
                output_dir=str(model_dir / "analysis_output"),
            )

            pipeline: RegimeRiskDecompositionPipeline = silent_call(
                run_analysis,
                analysis_config,
                show_plots=False,
                export_tables=False,
                show_monitoring_table=False,
            )
            n_model_rows = (
                int(len(pipeline.df_model))
                if pipeline.df_model is not None
                else 0
            )
            if n_model_rows < self.cfg.min_required_rows:
                raise ValueError(
                    f"Final model sample has {n_model_rows:,} rows; "
                    f"minimum required is {self.cfg.min_required_rows:,}."
                )

            metrics = pipeline.extract_objective_metrics(alpha=0.05)
            score, eligible, reason = score_trial(metrics, self.cfg)

            result.update({
                "status": "ok",
                "eligible": bool(eligible),
                "score": float(score),
                "constraint_reason": reason,
                "exact_features_json": json_dumps(selected),
                "hmm_features_json": json_dumps(hmm_features),
                "n_model_rows": n_model_rows,
                **{key: value for key, value in metrics.items()},
                **{f"model_{key}": value for key, value in model_params.items()},
            })

        except Exception:
            result["error_message"] = traceback.format_exc(limit=8)

        return result

    # ------------------------------------------------------
    # Ranking and exact final rerun
    # ------------------------------------------------------

    def _finalize_leaderboard(self) -> None:
        if not self.results:
            self.leaderboard = pd.DataFrame()
            return

        df = pd.DataFrame(self.results)
        ok = df.loc[df["status"].eq("ok")].copy()
        err = df.loc[~df["status"].eq("ok")].copy()

        if not ok.empty:
            ok = ok.sort_values(
                [
                    "eligible",
                    "score",
                    "hmm_r2",
                    "pct_significant",
                    "regime_component_share",
                ],
                ascending=[False, False, False, False, False],
            ).reset_index(drop=True)
            ok.insert(0, "rank", np.arange(1, len(ok) + 1))

        if not err.empty:
            err.insert(0, "rank", np.nan)

        self.leaderboard = pd.concat(
            [ok, err],
            ignore_index=True,
            sort=False,
        )
        self._public_leaderboard(
            self.leaderboard
        ).to_csv(
            self.leaderboard_path,
            index=False,
        )

    def _select_best_result(self) -> dict[str, Any]:
        if self.leaderboard is None:
            raise RuntimeError("Leaderboard not built.")
        ok = self.leaderboard.loc[self.leaderboard["status"].eq("ok")].copy()
        if ok.empty:
            raise RuntimeError("No successful model trial.")
        eligible = ok.loc[ok["eligible"].astype(bool)]
        winner = eligible.iloc[0] if not eligible.empty else ok.iloc[0]
        return winner.to_dict()

    def _materialize_and_rerun_best(
        self,
    ) -> RegimeRiskDecompositionPipeline:
        if self.best_result is None:
            raise RuntimeError("Best result not selected.")

        source_clean = Path(self.best_result["clean_path"])
        source_exact_features = Path(
            self.best_result["exact_selected_features_path"]
        )

        if not source_clean.exists():
            raise FileNotFoundError(
                f"Winning cleaned dataset not found: {source_clean}"
            )
        if not source_exact_features.exists():
            raise FileNotFoundError(
                "Winning selected-features file not found: "
                f"{source_exact_features}"
            )

        final_features = (
            self.cfg.root / "winning_selected_features.csv"
        )
        shutil.copy2(source_exact_features, final_features)

        model_params = json.loads(
            self.best_result["model_params_json"]
        )
        cleaning_params = json.loads(
            self.best_result["cleaning_params_json"]
        )
        hmm_features = json.loads(
            self.best_result["hmm_features_json"]
        )

        config = RiskDecompositionConfig(
            data_path=str(source_clean),
            features_path=str(source_exact_features),
            sheet_name=0,
            universe_mode=self.cfg.universe_mode,
            use_latam_specific_inputs=self.cfg.use_latam,
            target_col="MODEL_TARGET_LEVEL",
            regime_target_col="MODEL_TARGET",
            source_target_col=self.cfg.source_target_col,
            target_mode_label=str(cleaning_params["target_mode"]),
            winsorize_target=True,
            winsorize_lower=float(
                model_params["winsorize_lower"]
            ),
            winsorize_upper=float(
                model_params["winsorize_upper"]
            ),
            ols_cov_type=str(model_params["ols_cov_type"]),
            standardize_features=bool(
                model_params["standardize_features"]
            ),
            n_pca_components=int(
                model_params["n_pca_components"]
            ),
            min_isins_per_period=int(
                model_params["min_isins_per_period"]
            ),
            n_regimes=3,
            hmm_covariance_type=str(
                model_params["hmm_covariance_type"]
            ),
            hmm_n_iter=500,
            hmm_tol=1e-4,
            hmm_n_starts=int(model_params["hmm_n_starts"]),
            hmm_random_state=(
                self.cfg.random_seed
                + int(self.best_result["global_model_id"])
            ),
            hmm_include_pc1=bool(
                model_params["hmm_include_pc1"]
            ),
            hmm_features=hmm_features,
            hmm_auto_select_features=False,
            hmm_max_features=int(
                model_params["hmm_max_features"]
            ),
            smooth_regime_states=True,
            min_regime_duration=int(
                model_params["min_regime_duration"]
            ),
            output_dir=str(self.cfg.root),
        )

        print("\n" + "=" * 88)
        print("FINAL RERUN OF THE EXACT WINNING SPECIFICATION")
        print("=" * 88)
        print(
            "Score                     : "
            f"{float(self.best_result['score']):.4f}"
        )
        print(
            "HMM R²                    : "
            f"{float(self.best_result['hmm_r2']):.4f}"
        )
        print(
            "Significant coefficients  : "
            f"{float(self.best_result['pct_significant']):.1%}"
        )
        print(
            "Regime contribution share : "
            f"{float(self.best_result['regime_component_share']):.1%}"
        )
        print(
            "Regime incremental R²     : "
            f"{float(self.best_result['regime_incremental_r2']):.4f}"
        )
        print("=" * 88)

        pipeline = run_analysis(
            config,
            show_plots=False,
            export_tables=False,
            show_monitoring_table=False,
        )

        final_n_rows = (
            int(len(pipeline.df_model))
            if pipeline.df_model is not None
            else 0
        )
        if final_n_rows < self.cfg.min_required_rows:
            raise RuntimeError(
                f"Winning model rerun has {final_n_rows:,} rows; "
                f"minimum required is {self.cfg.min_required_rows:,}."
            )

        if self.cfg.export_final_tables:
            self._export_main_results(
                pipeline=pipeline,
                selected_features_path=source_exact_features,
            )

        if self.cfg.save_final_plots_html:
            self._save_all_html_plots(pipeline)

        self._write_best_configuration(
            pipeline=pipeline,
            final_features_path=final_features,
        )
        return pipeline


    # ------------------------------------------------------
    # Final flat exports, HTML plots, and progress
    # ------------------------------------------------------

    @staticmethod
    def _coefficient_table(model: Any) -> pd.DataFrame:
        if model is None:
            return pd.DataFrame()

        params = pd.Series(model.params)
        bse = pd.Series(
            getattr(model, "bse", pd.Series(np.nan, index=params.index))
        ).reindex(params.index)
        pvalues = pd.Series(
            getattr(model, "pvalues", pd.Series(np.nan, index=params.index))
        ).reindex(params.index)

        try:
            confidence = pd.DataFrame(model.conf_int(), index=params.index)
            confidence.columns = ["CI_lower_95", "CI_upper_95"]
        except Exception:
            confidence = pd.DataFrame(
                {
                    "CI_lower_95": np.nan,
                    "CI_upper_95": np.nan,
                },
                index=params.index,
            )

        table = pd.DataFrame(
            {
                "Term": params.index.astype(str),
                "Coefficient": params.values,
                "Std_error": bse.values,
                "P_value": pvalues.values,
                "CI_lower_95": confidence["CI_lower_95"].values,
                "CI_upper_95": confidence["CI_upper_95"].values,
            }
        )
        table["Significant_5pct"] = table["P_value"] < 0.05
        table["Significant_10pct"] = table["P_value"] < 0.10
        table["Abs_coefficient"] = table["Coefficient"].abs()
        return table.sort_values(
            ["Significant_5pct", "Abs_coefficient"],
            ascending=[False, False],
        ).reset_index(drop=True)

    def _best_summary_table(self) -> pd.DataFrame:
        if self.best_result is None:
            return pd.DataFrame()

        fields = [
            "global_model_id",
            "data_id",
            "model_id",
            "eligible",
            "score",
            "baseline_r2",
            "baseline_adj_r2",
            "hmm_r2",
            "hmm_adj_r2",
            "rmse",
            "mae",
            "pct_significant",
            "pct_significant_p10",
            "pct_regime_terms_significant",
            "regime_component_share",
            "regime_incremental_r2",
            "avg_self_transition",
            "min_regime_occupancy",
            "n_regimes_identified",
            "pc1_variance_share",
            "n_features_used",
        ]
        return pd.DataFrame(
            [
                {
                    field: self.best_result.get(field, np.nan)
                    for field in fields
                }
            ]
        )

    @staticmethod
    def _prepare_table_for_export(
        table: Optional[pd.DataFrame],
        *,
        index_name: str = "Index",
    ) -> pd.DataFrame:
        if table is None:
            return pd.DataFrame()

        out = pd.DataFrame(table).copy()
        if not isinstance(out.index, pd.RangeIndex):
            out = out.reset_index()
            first = out.columns[0]
            if first == "index":
                out = out.rename(columns={"index": index_name})
        return out

    def _collect_main_tables(
        self,
        pipeline: RegimeRiskDecompositionPipeline,
        selected_features_path: Path,
    ) -> dict[str, pd.DataFrame]:
        tables: dict[str, pd.DataFrame] = {
            "best_model_summary": self._best_summary_table(),
            "model_comparison": self._prepare_table_for_export(
                pipeline.model_comparison
            ),
            "baseline_summary": self._prepare_table_for_export(
                pipeline.baseline_summary_table
            ),
            "baseline_block_shares": self._prepare_table_for_export(
                pipeline.baseline_block_shares
            ),
            "baseline_coefficients": self._coefficient_table(
                pipeline.baseline_model
            ),
            "final_coefficients": self._coefficient_table(
                pipeline.hmm_decomp_model
            ),
            "pca_variance": self._prepare_table_for_export(
                pipeline.pca_variance_table
            ),
            "regime_durations": self._prepare_table_for_export(
                pipeline.regime_durations
            ),
            "regime_transition_matrix": self._prepare_table_for_export(
                pipeline.regime_transition_matrix,
                index_name="From_regime",
            ),
            "final_component_shares": self._prepare_table_for_export(
                pipeline.hmm_component_shares
            ),
            "regime_component_profile": self._prepare_table_for_export(
                pipeline.regime_component_profile
            ),
            "regime_interactions": self._prepare_table_for_export(
                pipeline.regime_interaction_table
            ),
            "monitoring_summary": pipeline.build_monitoring_summary_table(),
            "hmm_features": pd.DataFrame(
                {"HMM_feature": list(pipeline.hmm_features_used)}
            ),
            "score_weights": pd.DataFrame(
                [
                    {
                        "Objective_component": key,
                        "Weight": value,
                    }
                    for key, value in self.cfg.score_weights.items()
                ]
            ),
        }

        if selected_features_path.exists():
            tables["selected_features"] = pd.read_csv(
                selected_features_path
            )

        if (
            pipeline.regime_probs is not None
            and not pipeline.regime_probs.empty
        ):
            probabilities = pipeline.regime_probs.copy().reset_index()
            probabilities = probabilities.rename(
                columns={probabilities.columns[0]: "Period"}
            )
            tables["regime_probabilities"] = probabilities

        if pipeline.df_model is not None:
            country_col = next(
                (
                    column
                    for column in [
                        "CNTRY_OF_RISK_FULL_NAME",
                        "COUNTRY_FULL_NAME",
                        "CNTRY_OF_RISK",
                    ]
                    if column in pipeline.df_model.columns
                ),
                None,
            )
            if country_col is not None:
                tables["country_share"] = pipeline._build_share_table(
                    country_col,
                    "Country",
                )

            if "INDUSTRY_SECTOR" in pipeline.df_model.columns:
                tables["sector_share"] = pipeline._build_share_table(
                    "INDUSTRY_SECTOR",
                    "Sector",
                )

        if (
            self.cfg.export_row_level_decomposition
            and pipeline.hmm_components is not None
        ):
            row_level = pipeline.hmm_components.copy()
            if pipeline.df_model is not None:
                row_level[pipeline.period_col] = (
                    pipeline.df_model[pipeline.period_col]
                    .astype(str)
                    .values
                )
                if pipeline.config.id_col in pipeline.df_model.columns:
                    row_level[pipeline.config.id_col] = (
                        pipeline.df_model[pipeline.config.id_col]
                        .astype(str)
                        .values
                    )
            tables["row_level_decomposition"] = row_level

        if self.leaderboard is not None:
            public = self._public_leaderboard(self.leaderboard)
            tables["optimizer_top_models"] = (
                public.loc[public["status"].eq("ok")]
                .head(25)
                .copy()
            )

        return tables

    def _export_main_results(
        self,
        *,
        pipeline: RegimeRiskDecompositionPipeline,
        selected_features_path: Path,
    ) -> None:
        tables = self._collect_main_tables(
            pipeline,
            selected_features_path,
        )

        csv_names = {
            "best_model_summary": "01_best_model_summary.csv",
            "model_comparison": "02_model_comparison.csv",
            "baseline_summary": "03_baseline_summary.csv",
            "baseline_block_shares": "04_baseline_block_shares.csv",
            "baseline_coefficients": "05_baseline_coefficients.csv",
            "final_coefficients": "06_final_coefficients.csv",
            "pca_variance": "07_pca_variance.csv",
            "regime_durations": "08_regime_durations.csv",
            "regime_transition_matrix": "09_regime_transition_matrix.csv",
            "final_component_shares": "10_final_component_shares.csv",
            "regime_component_profile": "11_regime_component_profile.csv",
            "regime_interactions": "12_regime_interactions.csv",
            "monitoring_summary": "13_monitoring_summary.csv",
            "country_share": "14_country_share.csv",
            "sector_share": "15_sector_share.csv",
            "regime_probabilities": "16_regime_probabilities.csv",
            "selected_features": "17_selected_features.csv",
            "hmm_features": "18_hmm_features.csv",
            "score_weights": "19_score_weights.csv",
            "optimizer_top_models": "20_optimizer_top_models.csv",
            "row_level_decomposition": "21_row_level_decomposition.csv",
        }

        for table_name, table in tables.items():
            if table is None or table.empty:
                continue
            filename = csv_names.get(table_name, f"{table_name}.csv")
            table.to_csv(self.cfg.root / filename, index=False)

        try:
            with pd.ExcelWriter(
                self.workbook_path,
                engine="openpyxl",
            ) as writer:
                for table_name, table in tables.items():
                    if table is None or table.empty:
                        continue
                    table.to_excel(
                        writer,
                        sheet_name=table_name[:31],
                        index=False,
                    )
        except Exception as exc:
            print(
                "Could not create consolidated Excel workbook: "
                f"{exc}"
            )

    def _optimizer_diagnostic_figures(
        self,
    ) -> dict[str, go.Figure]:
        if self.leaderboard is None or self.leaderboard.empty:
            return {}

        ok = self.leaderboard.loc[
            self.leaderboard["status"].eq("ok")
        ].copy()
        if ok.empty:
            return {}

        figures: dict[str, go.Figure] = {}

        by_id = ok.sort_values("global_model_id").copy()
        by_id["running_best"] = by_id["score"].cummax()
        figures["plot_12_optimizer_convergence.html"] = px.line(
            by_id,
            x="global_model_id",
            y=["score", "running_best"],
            title="End-to-end optimizer convergence",
            labels={
                "global_model_id": "Model trial",
                "value": "Objective score",
            },
            template="plotly_white",
        )

        tradeoff = px.scatter(
            ok,
            x="hmm_r2",
            y="pct_significant",
            color="regime_component_share",
            size="score",
            symbol="eligible",
            hover_data=[
                "rank",
                "data_id",
                "model_id",
                "hmm_adj_r2",
                "regime_incremental_r2",
                "pct_regime_terms_significant",
                "avg_self_transition",
                "min_regime_occupancy",
            ],
            title=(
                "R², coefficient significance, "
                "and Regime-component impact"
            ),
            labels={
                "hmm_r2": "HMM-conditioned R²",
                "pct_significant": (
                    "Significant coefficients (p < 0.05)"
                ),
                "regime_component_share": "Regime share",
            },
            template="plotly_white",
        )
        tradeoff.update_yaxes(tickformat=".0%")
        figures["plot_13_optimizer_tradeoff.html"] = tradeoff

        top = ok.head(15)[
            [
                "rank",
                "score",
                "hmm_r2",
                "hmm_adj_r2",
                "pct_significant",
                "regime_component_share",
                "regime_incremental_r2",
                "pct_regime_terms_significant",
                "avg_self_transition",
                "data_id",
                "model_id",
            ]
        ].copy()
        for column in top.columns:
            if column not in {"rank", "data_id", "model_id"}:
                top[column] = pd.to_numeric(
                    top[column],
                    errors="coerce",
                ).round(4)

        table = go.Figure(
            data=[
                go.Table(
                    header=dict(
                        values=[
                            f"<b>{column}</b>"
                            for column in top.columns
                        ],
                        align="center",
                    ),
                    cells=dict(
                        values=[
                            top[column].tolist()
                            for column in top.columns
                        ],
                        align="center",
                    ),
                )
            ]
        )
        table.update_layout(
            title="Top 15 end-to-end specifications",
            height=520,
        )
        figures["plot_14_optimizer_top15.html"] = table
        return figures

    def _save_all_html_plots(
        self,
        pipeline: RegimeRiskDecompositionPipeline,
    ) -> None:
        plot_methods = [
            ("plot_01_country_share.html", pipeline.plot_country_share),
            ("plot_02_sector_share.html", pipeline.plot_sector_share),
            (
                "plot_03_baseline_block_shares.html",
                pipeline.plot_baseline_block_shares,
            ),
            ("plot_04_pca_variance.html", pipeline.plot_pca_variance),
            ("plot_05_regime_bands.html", pipeline.plot_regime_bands),
            (
                "plot_06_regime_probabilities.html",
                pipeline.plot_regime_probabilities,
            ),
            (
                "plot_07_final_component_shares.html",
                pipeline.plot_final_component_shares,
            ),
            (
                "plot_08_contributions_over_time.html",
                pipeline.plot_contributions_over_time,
            ),
            (
                "plot_09_regime_component_profile.html",
                pipeline.plot_regime_component_profile,
            ),
            (
                "plot_10_actual_vs_fitted.html",
                pipeline.plot_actual_vs_fitted,
            ),
        ]

        figures: dict[str, go.Figure] = {}
        original_show = go.Figure.show

        try:
            # Analysis plot methods call fig.show(). Suppress those calls while
            # collecting each returned figure for a final HTML-only export.
            go.Figure.show = lambda self, *args, **kwargs: None

            for filename, plot_method in plot_methods:
                try:
                    figure = plot_method()
                except Exception as exc:
                    print(f"Could not build {filename}: {exc}")
                    continue
                if figure is not None:
                    figures[filename] = figure
        finally:
            go.Figure.show = original_show

        try:
            monitoring_figure = pipeline.plot_monitoring_summary_table(
                output_dir=str(self.cfg.root),
                filename="plot_11_monitoring_summary.html",
                show=False,
                export_csv=False,
            )
            if self.cfg.show_final_plots and monitoring_figure is not None:
                monitoring_figure.show()
        except Exception as exc:
            print(f"Could not build monitoring-summary HTML: {exc}")

        figures.update(self._optimizer_diagnostic_figures())

        for filename, figure in figures.items():
            figure.write_html(
                self.cfg.root / filename,
                include_plotlyjs=self.cfg.html_include_plotlyjs,
                full_html=True,
            )
            if self.cfg.show_final_plots:
                figure.show()

    def _write_best_configuration(
        self,
        *,
        pipeline: RegimeRiskDecompositionPipeline,
        final_features_path: Path,
    ) -> None:
        if self.best_result is None:
            return

        payload = {
            "optimizer": asdict(self.cfg),
            "best_result": {
                key: value
                for key, value in self.best_result.items()
                if key not in self._transient_path_columns
            },
            "feature_params": json.loads(
                self.best_result["feature_params_json"]
            ),
            "cleaning_params": json.loads(
                self.best_result["cleaning_params_json"]
            ),
            "model_params": json.loads(
                self.best_result["model_params_json"]
            ),
            "exact_features": json.loads(
                self.best_result["exact_features_json"]
            ),
            "hmm_features": json.loads(
                self.best_result["hmm_features_json"]
            ),
            "final_output": {
                "folder": str(self.cfg.root),
                "main_workbook": str(self.workbook_path),
                "winning_selected_features": str(
                    final_features_path
                ),
                "all_plots_format": "html",
                "temporary_trial_artifacts_saved": False,
            },
            "final_sample": {
                "n_rows": (
                    int(len(pipeline.df_model))
                    if pipeline.df_model is not None
                    else 0
                ),
                "n_features": (
                    int(pipeline.X.shape[1])
                    if pipeline.X is not None
                    else 0
                ),
                "period_column": pipeline.period_col,
            },
        }
        self.best_configuration_path.write_text(
            json.dumps(
                payload,
                indent=2,
                default=_json_default,
            ),
            encoding="utf-8",
        )

    def _save_progress(self) -> None:
        if self.data_results:
            data_frame = pd.DataFrame(self.data_results)
            self._public_data_leaderboard(data_frame).to_csv(
                self.data_leaderboard_path,
                index=False,
            )
        if self.results:
            self._finalize_leaderboard()

    def _print_summary(self) -> None:
        assert self.best_result is not None

        successful = 0
        if self.leaderboard is not None:
            successful = int(
                (self.leaderboard["status"] == "ok").sum()
            )

        html_count = len(list(self.cfg.root.glob("*.html")))
        csv_count = len(list(self.cfg.root.glob("*.csv")))

        print("\n" + "=" * 88)
        print("OPTIMIZER COMPLETE")
        print("=" * 88)
        print(f"Successful model trials   : {successful}")
        print(
            "Best score                : "
            f"{float(self.best_result['score']):.4f}"
        )
        print(
            "Best HMM R²               : "
            f"{float(self.best_result['hmm_r2']):.4f}"
        )
        print(
            "Best adjusted R²          : "
            f"{float(self.best_result['hmm_adj_r2']):.4f}"
        )
        print(
            "Significant coefficients  : "
            f"{float(self.best_result['pct_significant']):.1%}"
        )
        print(
            "Regime contribution share : "
            f"{float(self.best_result['regime_component_share']):.1%}"
        )
        print(
            "Regime-term significance  : "
            f"{float(self.best_result['pct_regime_terms_significant']):.1%}"
        )
        print(
            "Regime incremental R²     : "
            f"{float(self.best_result['regime_incremental_r2']):.4f}"
        )
        print(f"CSV result files          : {csv_count}")
        print(f"HTML plot files           : {html_count}")
        print(f"Main workbook             : {self.workbook_path}")
        print(f"Single output folder      : {self.cfg.root}")
        print("=" * 88)


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":
    # Total analysis runs:
    #     N_DATA_VARIANTS × N_MODEL_VARIANTS_PER_DATA
    #
    # The optimizer creates only:
    #     OUTPUT_DIR / "main_results"
    #
    # All trial datasets and trial models are temporary and deleted
    # automatically after the winning specification is rerun.

    N_DATA_VARIANTS = 20
    N_MODEL_VARIANTS_PER_DATA = 50

    config = OptimizerConfig(
        n_data_variants=N_DATA_VARIANTS,
        n_model_variants_per_data=N_MODEL_VARIANTS_PER_DATA,
        universe_mode="LATAM",
        random_seed=42,
        source_target_col="Z_SPREAD_MID",

        # Single persistent result folder.
        output_root=str(OUTPUT_DIR / "main_results"),
        intermediate_format="parquet",
        reset_output_folder=True,
        min_required_rows=4000,

        # Final files only: flat CSV/XLSX tables and HTML plots.
        export_final_tables=True,
        export_row_level_decomposition=False,
        save_final_plots_html=True,
        show_final_plots=False,
        html_include_plotlyjs=True,
        main_workbook_name="main_results.xlsx",

        # Explicit emphasis: fit + significance + Regime impact.
        score_weights={
            "r2": 0.25,
            "adjusted_r2": 0.10,
            "significance": 0.20,
            "regime_component_share": 0.20,
            "regime_term_significance": 0.10,
            "regime_incremental_r2": 0.10,
            "regime_stability": 0.05,
        },
    )

    optimizer = EndToEndPipelineOptimizer(config)
    optimizer.run()

# %%