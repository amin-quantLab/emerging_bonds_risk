# %% CORPORATE EM BOND FEATURE BUILDER

# ==========================================================
# Author: Amin Tarbouch
#
# Purpose:
#   Build a clean modeling table for EM corporate bond spread analysis:
#   - bond-level features
#   - macro rolling features
#   - liquidity / risk proxies
#   - structure dummies
#   - LATAM FX scores
#   - GPR features
#   - LATAM credit-risk composite features from weekly sparse CDS/JPM data
#
# New credit-risk data logic:
#   Raw weekly sparse columns in daily macro table:
#       brazil_cds_usd_sr_5y_d14_corp
#       mex_cds_usd_sr_5y_d14_corp
#       argent_cds_usd_sr_5y_d14_corp
#       colom_cds_usd_sr_5y_d14_corp
#       jcbsbrbs_index
#       jcbsmxbs_index
#       jcbsarbs_index
#       jcbscobs_index
#
#   Final output from these 8 columns ONLY:
#       latam_cds_credit_risk
#       latam_jpm_spread_credit_risk
#
# Column convention:
#   Everything is normalized to lowercase snake_case.
# ==========================================================

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd

from reader_db_fct import MasterDataset
from path_config import FEATURE_ENGINEERED, FX_LATAM, GPR


# ==========================================================
# CONSTANTS
# ==========================================================

LATAM_GDP_USD_BN: dict[str, float] = {
    "brl": 2_173.0,
    "mxn": 1_789.0,
    "ars":   621.0,
    "cop":   363.0,
    "clp":   344.0,
    "pen":   268.0,
    "gtq":    96.0,
    "uyu":    77.0,
    "crc":    68.0,
    "bob":    45.0,
    "pyg":    43.0,
    "hnl":    34.0,
    "nio":    17.0,
}

HARD_CURRENCIES: frozenset[str] = frozenset({
    "usd", "eur", "gbp", "jpy", "chf", "cad",
    "aud", "nzd", "sek", "nok", "dkk", "sgd", "hkd",
})

MACRO_COLUMNS: tuple[str, ...] = (
    "vix_index",
    "ukx_index",
    "move_index",
    "cdx_ig_cdsi_gen_5y_corp",
    "itrx_eur_cdsi_gen_5y_corp",
    "gdp_cqoq_index",
    "eugnemuq_index",
    "cpi_yoy_index",
    "eccpemuy_index",
    "bfcius_index",
    "bfcieu_index",
    "stoxx600",
    "sp500",
    "msci_em",
    "jpm_embi",
    "epucemec_index",
    "cafzuuem_index",
    "aonils_index",
    "glcrpcr_index",
    "glcrcbv_index",
    "glcrncb_index",
    "gcilmanm_index",
    "gcilnatl_index",
    "crptbraz_index",
    "crptchin_index",
    "crpthoko_index",
    "crptmexi_index",
    "crptkore_index",
    "crptindi_index",
    "crptunae_index",
    "hg1_comdty",
    "s_1_comdty",
    "gc1_comdty",
    "usgg10yr_index",
    "fedl01_index",
    "bzstseta_index",
    "mxonbr_index",
)


# ==========================================================
# NEW LATAM CREDIT-RISK DATA
# ==========================================================

LATAM_CDS_RAW_COLUMNS: dict[str, str] = {
    "bra": "brazil_cds_usd_sr_5y_d14_corp",
    "mex": "mex_cds_usd_sr_5y_d14_corp",
    "arg": "argent_cds_usd_sr_5y_d14_corp",
    "col": "colom_cds_usd_sr_5y_d14_corp",
}

LATAM_JPM_SPREAD_RAW_COLUMNS: dict[str, str] = {
    "bra": "jcbsbrbs_index",
    "mex": "jcbsmxbs_index",
    "arg": "jcbsarbs_index",
    "col": "jcbscobs_index",
}

LATAM_CREDIT_RISK_GDP_USD_BN: dict[str, float] = {
    "bra": 2_173.0,
    "mex": 1_789.0,
    "arg":   621.0,
    "col":   363.0,
}

LATAM_CDS_CREDIT_RISK_COL: str = "latam_cds_credit_risk"
LATAM_JPM_SPREAD_CREDIT_RISK_COL: str = "latam_jpm_spread_credit_risk"
LATAM_CREDIT_RISK_OUTPUT_COLUMNS: tuple[str, str] = (
    LATAM_CDS_CREDIT_RISK_COL,
    LATAM_JPM_SPREAD_CREDIT_RISK_COL,
)


# ==========================================================
# FX SCORE CONSTANTS
# ==========================================================

FX_COL_DIRECTION: str = "latam_fx_direction"
FX_COL_VOL: str = "latam_fx_vol"
FX_SCORE_COLUMNS: tuple[str, ...] = (FX_COL_DIRECTION, FX_COL_VOL)


# ==========================================================
# GPR CONSTANTS
# ==========================================================

GPR_GLOBAL_COLS: tuple[str, ...] = ("gpr", "gprt", "gpra")

GPR_LATAM_COLS: tuple[str, ...] = (
    "gprc_bra",
    "gprc_chl",
    "gprc_col",
    "gprc_mex",
    "gprc_per",
)

GPR_RAW_COLUMNS: tuple[str, ...] = GPR_GLOBAL_COLS + GPR_LATAM_COLS

GPR_LATAM_GDP_USD_BN: dict[str, float] = {
    "bra": 2_173.0,
    "mex": 1_789.0,
    "col":   363.0,
    "chl":   344.0,
    "per":   268.0,
    "cri":    68.0,
}

GPR_OUT_LEVEL: str = "gpr_level"
GPR_OUT_MOMENTUM: str = "gpr_momentum"
GPR_OUT_VOL: str = "gpr_vol"
GPR_OUT_ACTS_SHARE: str = "gpr_acts_share"

GPR_LATAM_OUT_LEVEL: str = "gpr_latam_level"
GPR_LATAM_OUT_MOMENTUM: str = "gpr_latam_momentum"
GPR_LATAM_OUT_VOL: str = "gpr_latam_vol"

GPR_COUNTRY_SUFFIXES: tuple[str, ...] = ("level", "momentum", "vol")

GPR_ENGINEERED_COLUMNS: tuple[str, ...] = (
    GPR_OUT_LEVEL,
    GPR_OUT_MOMENTUM,
    GPR_OUT_VOL,
    GPR_OUT_ACTS_SHARE,
    GPR_LATAM_OUT_LEVEL,
    GPR_LATAM_OUT_MOMENTUM,
    GPR_LATAM_OUT_VOL,
)


# ==========================================================
# CONFIGURATION
# ==========================================================

@dataclass(frozen=True)
class CreditRiskConfig:
    """
    Builds exactly two output columns from the new weekly credit-risk data:

        latam_cds_credit_risk
        latam_jpm_spread_credit_risk

    Each family is built from four country columns:
        Brazil, Mexico, Argentina, Colombia.

    Logic:
        1. Use only non-null weekly observations.
        2. Compute country-level credit stress from:
             - spread level z-score
             - spread weekly-change momentum z-score
             - spread weekly-change volatility z-score
        3. Convert sparse weekly scores to daily using backward asof merge.
        4. Carry forward only up to max_stale_days.
        5. Aggregate countries using GDP weights.
        6. Expanding-standardize final LATAM composite.
    """

    cds_raw_columns: dict[str, str] = field(
        default_factory=lambda: dict(LATAM_CDS_RAW_COLUMNS)
    )
    jpm_spread_raw_columns: dict[str, str] = field(
        default_factory=lambda: dict(LATAM_JPM_SPREAD_RAW_COLUMNS)
    )
    country_gdp_usd_bn: dict[str, float] = field(
        default_factory=lambda: dict(LATAM_CREDIT_RISK_GDP_USD_BN)
    )

    zscore_window_weeks: int = 52
    zscore_min_periods: int = 12
    momentum_window_weeks: int = 4
    vol_window_weeks: int = 12
    max_stale_days: int = 10

    level_weight: float = 0.60
    momentum_weight: float = 0.30
    vol_weight: float = 0.10


@dataclass(frozen=True)
class GprConfig:
    gpr_file_path: str = ""
    gpr_sheet_name: str = "Sheet1"
    zscore_window: Optional[int] = 36
    zscore_min_periods: int = 12
    momentum_window: int = 12
    vol_window: int = 12
    decimal: str = ","


@dataclass(frozen=True)
class FxScoreConfig:
    fx_file_path: str = ""
    fx_sheet_name: str = "Sheet1"
    latam_currencies: tuple[str, ...] = tuple(LATAM_GDP_USD_BN.keys())
    gdp_weights_usd_bn: dict[str, float] = field(
        default_factory=lambda: dict(LATAM_GDP_USD_BN)
    )
    zscore_window: Optional[int] = 252
    zscore_min_periods: int = 60
    exclude_ars: bool = False


@dataclass(frozen=True)
class FeatureBuilderConfig:
    zr_window: int = 21
    zr_min_periods: int = 5

    macro_windows: tuple[int, ...] = (3,)
    macro_methods: tuple[str, ...] = ("mean",)
    macro_min_periods: int = 1
    ewm_adjust: bool = False
    fill_macro_features: bool = True
    hard_currencies: frozenset[str] = HARD_CURRENCIES
    macro_columns: tuple[str, ...] = MACRO_COLUMNS

    credit_risk_config: Optional[CreditRiskConfig] = field(
        default_factory=CreditRiskConfig
    )
    fx_score_config: Optional[FxScoreConfig] = None
    gpr_config: Optional[GprConfig] = None

    # Important:
    #   The two credit-risk composites are NOT rolled into ma3_ columns.
    #   This guarantees that the new 8 raw columns generate exactly two
    #   output columns in the final feature-engineered table.
    roll_credit_risk_features: bool = False


# ==========================================================
# HELPER FUNCTIONS
# ==========================================================

def to_snake_case(value: object) -> str:
    text = str(value).strip().lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text)
    return text.strip("_")


def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [to_snake_case(c) for c in out.columns]
    return out.loc[:, ~out.columns.duplicated()].copy()


def parse_date_column(
    df: pd.DataFrame,
    frame_name: str = "",
) -> pd.DataFrame:
    out = standardize_columns(df)

    if "date" not in out.columns:
        raise KeyError(f"{frame_name}: dataframe must contain a date column.")

    out["date"] = pd.to_datetime(out["date"], errors="coerce")

    before = len(out)
    out = (
        out.dropna(subset=["date"])
        .sort_values("date")
        .reset_index(drop=True)
    )

    if out.empty:
        raise ValueError(f"{frame_name}: no valid date rows remain.")

    dropped = before - len(out)
    if dropped:
        print(f"⚠️  {frame_name}: dropped {dropped} rows with unparseable date.")

    return out


def rolling_zscore(
    series: pd.Series,
    window: Optional[int],
    min_periods: int,
) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce")

    if window is None:
        mu = s.expanding(min_periods=min_periods).mean()
        std = s.expanding(min_periods=min_periods).std()
    else:
        mu = s.rolling(window=window, min_periods=min_periods).mean()
        std = s.rolling(window=window, min_periods=min_periods).std()

    std = std.replace(0.0, np.nan)
    return (s - mu) / std


def expanding_standardize(
    series: pd.Series,
    min_periods: int,
) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce")
    mu = s.expanding(min_periods=min_periods).mean()
    std = s.expanding(min_periods=min_periods).std().replace(0.0, np.nan)
    return (s - mu) / std


def weighted_composite(
    df: pd.DataFrame,
    weights: dict[str, float],
) -> pd.Series:
    if df.empty:
        return pd.Series(np.nan, index=df.index, dtype=float)

    available_cols = [c for c in df.columns if c in weights]

    if not available_cols:
        return pd.Series(np.nan, index=df.index, dtype=float)

    sub = df[available_cols].copy()
    weight_vec = pd.Series({c: weights[c] for c in available_cols}, dtype=float)

    available_weight = (
        sub.notna()
        .multiply(weight_vec)
        .sum(axis=1)
        .replace(0.0, np.nan)
    )

    weighted_sum = sub.multiply(weight_vec).sum(axis=1, skipna=True)
    return weighted_sum / available_weight


def fill_numeric_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()

    for col in out.columns:
        s = pd.to_numeric(out[col], errors="coerce")

        if not s.notna().any():
            out[col] = 0.0
            continue

        s_ffill = s.ffill()
        expanding_median = s.expanding(min_periods=1).median()
        out[col] = s_ffill.fillna(expanding_median).fillna(0.0)

    return out


def normalize_text(value: object) -> str:
    if pd.isna(value):
        return ""

    text = str(value).lower().strip()
    text = re.sub(r"[_\-/]", " ", text)
    return re.sub(r"\s+", " ", text)


def normalize_yes_no(series: pd.Series) -> pd.Series:
    mapping = {
        "yes": "y",
        "true": "y",
        "1": "y",
        "y": "y",
        "no": "n",
        "false": "n",
        "0": "n",
        "n": "n",
        "nan": "n",
        "none": "n",
        "null": "n",
        "": "n",
    }

    out = series.astype(str).str.lower().str.strip().map(mapping)
    return out.fillna("n")


def first_existing_column(
    df: pd.DataFrame,
    candidates: Iterable[str],
) -> Optional[str]:
    for col in [to_snake_case(c) for c in candidates]:
        if col in df.columns:
            return col

    return None


def normalize_weights(raw_weights: dict[str, float]) -> dict[str, float]:
    total = float(sum(raw_weights.values()))

    if total <= 0:
        n = max(len(raw_weights), 1)
        return {k: 1.0 / n for k in raw_weights}

    return {k: float(v) / total for k, v in raw_weights.items()}


# ==========================================================
# LATAM CREDIT RISK BUILDER — ONLY TWO OUTPUT COLUMNS
# ==========================================================

class LatamCreditRiskCompositeBuilder:
    """
    Build exactly two composite risk features:

        latam_cds_credit_risk
        latam_jpm_spread_credit_risk

    The raw country columns are used internally and are not exported from
    this block.
    """

    def __init__(self, config: CreditRiskConfig) -> None:
        self.cfg = config

    def build(self, df_macro: pd.DataFrame) -> pd.DataFrame:
        df = parse_date_column(df_macro, frame_name="macro credit-risk input")

        out = df[["date"]].drop_duplicates().sort_values("date").reset_index(drop=True)

        cds_cols = {
            iso: to_snake_case(col)
            for iso, col in self.cfg.cds_raw_columns.items()
        }
        jpm_cols = {
            iso: to_snake_case(col)
            for iso, col in self.cfg.jpm_spread_raw_columns.items()
        }

        print("\n" + "-" * 60)
        print("LATAM CREDIT RISK — TWO COMPOSITE FEATURES")
        print("-" * 60)

        out[LATAM_CDS_CREDIT_RISK_COL] = self._build_family_composite(
            df=df,
            full_dates=out["date"],
            family_name="CDS",
            raw_columns_by_country=cds_cols,
        ).values

        out[LATAM_JPM_SPREAD_CREDIT_RISK_COL] = self._build_family_composite(
            df=df,
            full_dates=out["date"],
            family_name="JPM corporate spread",
            raw_columns_by_country=jpm_cols,
        ).values

        print("\n✅ Credit-risk outputs created:")
        print(f"   {LATAM_CDS_CREDIT_RISK_COL}")
        print(f"   {LATAM_JPM_SPREAD_CREDIT_RISK_COL}")

        return out

    def _build_family_composite(
        self,
        df: pd.DataFrame,
        full_dates: pd.Series,
        family_name: str,
        raw_columns_by_country: dict[str, str],
    ) -> pd.Series:
        country_daily_scores: dict[str, pd.Series] = {}

        for iso, raw_col in raw_columns_by_country.items():
            if raw_col not in df.columns:
                print(f"⚠️  {family_name}: missing column skipped: {raw_col}")
                continue

            raw = pd.to_numeric(df[raw_col], errors="coerce")
            raw = raw.where(raw > 0, np.nan)

            n_obs = int(raw.notna().sum())
            if n_obs == 0:
                print(f"⚠️  {family_name}: no valid observations in {raw_col}")
                continue

            country_score = self._single_country_score(
                dates=df["date"],
                raw_series=raw,
                feature_name=f"{family_name}_{iso}",
            )

            country_daily_scores[iso] = self._sparse_score_to_daily(
                full_dates=full_dates,
                score_dates=df["date"],
                score_values=country_score,
                feature_name=f"{family_name}_{iso}_score",
            )

            print(f"✅ {family_name:<22} {iso:<4} {raw_col:<35} obs={n_obs:,}")

        if not country_daily_scores:
            print(f"⚠️  {family_name}: no country scores available.")
            return pd.Series(np.nan, index=full_dates.index, dtype=float)

        available_weights = {
            iso: self.cfg.country_gdp_usd_bn[iso]
            for iso in country_daily_scores
            if iso in self.cfg.country_gdp_usd_bn
        }

        weights = normalize_weights(available_weights)

        score_frame = pd.DataFrame(country_daily_scores)
        composite = weighted_composite(score_frame, weights)

        final = expanding_standardize(
            composite,
            min_periods=self.cfg.zscore_min_periods,
        )

        self._print_family_weights(family_name, weights, available_weights)

        return final

    def _single_country_score(
        self,
        dates: pd.Series,
        raw_series: pd.Series,
        feature_name: str,
    ) -> pd.Series:
        obs = pd.DataFrame(
            {
                "date": pd.to_datetime(dates).values,
                "value": pd.to_numeric(raw_series, errors="coerce").values,
            }
        ).dropna(subset=["value"])

        obs = (
            obs.groupby("date", as_index=False)
            .last()
            .sort_values("date")
            .reset_index(drop=True)
        )

        if obs.empty:
            return pd.Series(np.nan, index=dates.index, dtype=float)

        value = pd.to_numeric(obs["value"], errors="coerce")
        weekly_change = value.diff()

        momentum_min_periods = max(
            2,
            min(self.cfg.momentum_window_weeks, self.cfg.zscore_min_periods),
        )
        vol_min_periods = max(
            3,
            min(self.cfg.vol_window_weeks, self.cfg.zscore_min_periods),
        )

        level_z = rolling_zscore(
            value,
            window=self.cfg.zscore_window_weeks,
            min_periods=self.cfg.zscore_min_periods,
        )

        momentum_raw = weekly_change.rolling(
            window=self.cfg.momentum_window_weeks,
            min_periods=momentum_min_periods,
        ).mean()

        momentum_z = rolling_zscore(
            momentum_raw,
            window=self.cfg.zscore_window_weeks,
            min_periods=self.cfg.zscore_min_periods,
        )

        vol_raw = weekly_change.rolling(
            window=self.cfg.vol_window_weeks,
            min_periods=vol_min_periods,
        ).std()

        vol_z = rolling_zscore(
            vol_raw,
            window=self.cfg.zscore_window_weeks,
            min_periods=self.cfg.zscore_min_periods,
        )

        score_parts = pd.DataFrame(
            {
                "level": self.cfg.level_weight * level_z,
                "momentum": self.cfg.momentum_weight * momentum_z,
                "vol": self.cfg.vol_weight * vol_z,
            }
        )

        score = score_parts.sum(axis=1, skipna=True)
        score = score.where(score_parts.notna().any(axis=1))

        sparse_score = pd.DataFrame(
            {
                "date": obs["date"].values,
                feature_name: score.values,
            }
        )

        merged = pd.DataFrame({"date": pd.to_datetime(dates).values}).merge(
            sparse_score,
            on="date",
            how="left",
        )

        return pd.Series(merged[feature_name].values, index=dates.index, dtype=float)

    def _sparse_score_to_daily(
        self,
        full_dates: pd.Series,
        score_dates: pd.Series,
        score_values: pd.Series,
        feature_name: str,
    ) -> pd.Series:
        full = pd.DataFrame({"date": pd.to_datetime(full_dates).values})
        full = full.sort_values("date").reset_index(drop=True)

        sparse = pd.DataFrame(
            {
                "date": pd.to_datetime(score_dates).values,
                "_obs_date": pd.to_datetime(score_dates).values,
                feature_name: pd.to_numeric(score_values, errors="coerce").values,
            }
        ).dropna(subset=[feature_name])

        if sparse.empty:
            return pd.Series(np.nan, index=full_dates.index, dtype=float)

        sparse = (
            sparse.groupby("date", as_index=False)
            .last()
            .sort_values("date")
            .reset_index(drop=True)
        )

        merged = pd.merge_asof(
            full,
            sparse,
            on="date",
            direction="backward",
            allow_exact_matches=True,
        )

        age_days = (merged["date"] - merged["_obs_date"]).dt.days
        daily_score = merged[feature_name].where(age_days <= self.cfg.max_stale_days)

        return pd.Series(daily_score.values, index=full_dates.index, dtype=float)

    @staticmethod
    def _print_family_weights(
        family_name: str,
        weights: dict[str, float],
        raw_weights: dict[str, float],
    ) -> None:
        if not weights:
            return

        print(f"\n📊 {family_name} LATAM composite GDP weights")
        print(f"  {'Country':<8} {'GDP USD bn':>12}  {'Weight':>8}")
        print(f"  {'-' * 32}")

        for iso, weight in sorted(weights.items(), key=lambda x: -x[1]):
            print(f"  {iso:<8} {raw_weights[iso]:>12,.1f}  {weight:>7.2%}")

        print()


# ==========================================================
# GPR FEATURE BUILDER
# ==========================================================

class GprFeatureBuilder:
    _COL_TO_ISO: dict[str, str] = {
        "gprc_bra": "bra",
        "gprc_chl": "chl",
        "gprc_col": "col",
        "gprc_mex": "mex",
        "gprc_per": "per",
    }

    def __init__(self, config: GprConfig) -> None:
        self.cfg = config

    def build(self) -> pd.DataFrame:
        df_raw = self._load()
        df_clean = self._clean(df_raw)

        out = df_clean[["date"]].copy()
        out = self._add_global_features(out, df_clean)

        country_feat = self._build_country_features(df_clean)
        out = self._add_latam_composite(out, country_feat)

        for col in country_feat.columns:
            out[col] = country_feat[col].values

        out = self._add_costa_rica_proxy(out)

        print(
            f"✅ GPR features built — "
            f"{out.shape[0]} months × {out.shape[1] - 1} engineered columns."
        )

        return out.reset_index(drop=True)

    def _load(self) -> pd.DataFrame:
        path = Path(self.cfg.gpr_file_path)
        suffix = path.suffix.lower()

        if not path.exists():
            raise FileNotFoundError(f"GPR file not found: {path}")

        readers = {
            ".xlsx": lambda: pd.read_excel(
                path,
                sheet_name=self.cfg.gpr_sheet_name,
                decimal=self.cfg.decimal,
            ),
            ".xls": lambda: pd.read_excel(
                path,
                sheet_name=self.cfg.gpr_sheet_name,
                decimal=self.cfg.decimal,
            ),
            ".csv": lambda: pd.read_csv(path, decimal=self.cfg.decimal),
            ".parquet": lambda: pd.read_parquet(path),
        }

        if suffix not in readers:
            raise ValueError(f"Unsupported GPR file format: {suffix}")

        df = readers[suffix]()
        print(f"✅ GPR file loaded: {path.name} shape={df.shape}")
        return df

    def _clean(self, df: pd.DataFrame) -> pd.DataFrame:
        df = standardize_columns(df)

        date_col = next(
            (c for c in df.columns if c in {"month", "date", "dt", "dates"}),
            None,
        )

        if date_col is None:
            raise KeyError(
                "GPR file must contain a month/date column. "
                f"Available columns: {df.columns.tolist()}"
            )

        df = df.rename(columns={date_col: "date"})
        df["date"] = pd.to_datetime(df["date"], dayfirst=True, errors="coerce")
        df["date"] = df["date"].dt.to_period("M").dt.to_timestamp()

        df = parse_date_column(df, frame_name="GPR file")

        num_cols = [c for c in df.columns if c != "date"]
        df[num_cols] = df[num_cols].apply(pd.to_numeric, errors="coerce")

        present = [c for c in GPR_RAW_COLUMNS if c in df.columns]
        missing = set(GPR_RAW_COLUMNS) - set(present)

        if missing:
            print(f"⚠️  GPR raw columns not found, skipped: {sorted(missing)}")

        return df[["date"] + present].copy()

    def _add_global_features(
        self,
        out: pd.DataFrame,
        df: pd.DataFrame,
    ) -> pd.DataFrame:
        if "gpr" not in df.columns:
            print("⚠️  gpr column missing — global GPR features skipped.")
            return out

        log_gpr = np.log(df["gpr"].clip(lower=1e-6))
        mom = log_gpr.diff()

        w = self.cfg.zscore_window
        mp = self.cfg.zscore_min_periods
        vw = self.cfg.vol_window
        mw = self.cfg.momentum_window

        out[GPR_OUT_LEVEL] = expanding_standardize(
            rolling_zscore(log_gpr, window=w, min_periods=mp),
            min_periods=mp,
        ).values

        roll_mom = mom.rolling(window=mw, min_periods=mp).mean()
        out[GPR_OUT_MOMENTUM] = expanding_standardize(
            rolling_zscore(roll_mom, window=w, min_periods=mp),
            min_periods=mp,
        ).values

        roll_vol = mom.rolling(window=vw, min_periods=mp).std()
        out[GPR_OUT_VOL] = expanding_standardize(
            rolling_zscore(roll_vol, window=w, min_periods=mp),
            min_periods=mp,
        ).values

        if "gpra" in df.columns:
            out[GPR_OUT_ACTS_SHARE] = (
                df["gpra"]
                .div(df["gpr"].replace(0, np.nan))
                .clip(0, 1)
                .values
            )
        else:
            print("⚠️  gpra column missing — gpr_acts_share skipped.")

        return out

    def _build_country_features(
        self,
        df: pd.DataFrame,
    ) -> pd.DataFrame:
        w = self.cfg.zscore_window
        mp = self.cfg.zscore_min_periods
        vw = self.cfg.vol_window
        mw = self.cfg.momentum_window

        frames: dict[str, pd.Series] = {}

        for raw_col, iso in self._COL_TO_ISO.items():
            if raw_col not in df.columns:
                print(f"⚠️  {raw_col} not found — {iso} GPR features skipped.")
                continue

            log_s = np.log(df[raw_col].clip(lower=1e-9))
            mom = log_s.diff()

            frames[f"gpr_{iso}_level"] = expanding_standardize(
                rolling_zscore(log_s, window=w, min_periods=mp),
                min_periods=mp,
            )

            roll_mom = mom.rolling(window=mw, min_periods=mp).mean()
            frames[f"gpr_{iso}_momentum"] = expanding_standardize(
                rolling_zscore(roll_mom, window=w, min_periods=mp),
                min_periods=mp,
            )

            roll_vol = mom.rolling(window=vw, min_periods=mp).std()
            frames[f"gpr_{iso}_vol"] = expanding_standardize(
                rolling_zscore(roll_vol, window=w, min_periods=mp),
                min_periods=mp,
            )

        return pd.DataFrame(frames)

    def _add_latam_composite(
        self,
        out: pd.DataFrame,
        country_feat: pd.DataFrame,
    ) -> pd.DataFrame:
        available_isos = [
            iso for iso in self._COL_TO_ISO.values()
            if f"gpr_{iso}_level" in country_feat.columns
        ]

        if not available_isos:
            print("⚠️  No country GPR columns available — LATAM GPR composite skipped.")
            return out

        raw_w = {iso: GPR_LATAM_GDP_USD_BN.get(iso, 0.0) for iso in available_isos}
        norm_w = normalize_weights(raw_w)

        for suffix in GPR_COUNTRY_SUFFIXES:
            cols = {
                f"gpr_{iso}_{suffix}": norm_w[iso]
                for iso in available_isos
                if f"gpr_{iso}_{suffix}" in country_feat.columns
            }

            signals = country_feat[[c for c in cols if c in country_feat.columns]]

            if signals.empty:
                continue

            composite = weighted_composite(signals, cols)
            out_col = f"gpr_latam_{suffix}"

            out[out_col] = expanding_standardize(
                composite,
                self.cfg.zscore_min_periods,
            ).values

        return out

    def _add_costa_rica_proxy(self, out: pd.DataFrame) -> pd.DataFrame:
        mapping = {
            "gpr_cri_level": GPR_LATAM_OUT_LEVEL,
            "gpr_cri_momentum": GPR_LATAM_OUT_MOMENTUM,
            "gpr_cri_vol": GPR_LATAM_OUT_VOL,
        }

        for cri_col, source_col in mapping.items():
            if source_col in out.columns:
                out[cri_col] = out[source_col].values
            else:
                out[cri_col] = np.nan

        return out


# ==========================================================
# LATAM FX SCORE BUILDER
# ==========================================================

class LatamFxScoreBuilder:
    def __init__(self, config: FxScoreConfig) -> None:
        self.cfg = config

    def build(self) -> pd.DataFrame:
        df_raw = self._load()
        df_clean = self._clean(df_raw)
        weights = self._resolve_weights(df_clean)

        ccy_cols = [c for c in df_clean.columns if c != "date"]
        df_log = np.log(df_clean[ccy_cols].where(df_clean[ccy_cols] > 0, np.nan))
        df_logret = df_log.diff()

        df_direction = self._score_direction(df_clean, df_logret, ccy_cols, weights)
        df_vol = self._score_vol(df_clean, df_logret, ccy_cols, weights)

        out = (
            df_direction
            .merge(df_vol, on="date", how="outer")
            .sort_values("date")
            .reset_index(drop=True)
        )

        print(
            f"✅ LATAM FX scores computed — "
            f"direction={out[FX_COL_DIRECTION].notna().sum()} | "
            f"vol={out[FX_COL_VOL].notna().sum()} valid obs."
        )

        return out

    def _load(self) -> pd.DataFrame:
        path = Path(self.cfg.fx_file_path)
        suffix = path.suffix.lower()

        if not path.exists():
            raise FileNotFoundError(f"FX file not found: {path}")

        readers = {
            ".xlsx": lambda: pd.read_excel(
                path,
                sheet_name=self.cfg.fx_sheet_name,
                decimal=",",
            ),
            ".xls": lambda: pd.read_excel(
                path,
                sheet_name=self.cfg.fx_sheet_name,
                decimal=",",
            ),
            ".csv": lambda: pd.read_csv(path, decimal=","),
            ".parquet": lambda: pd.read_parquet(path),
        }

        if suffix not in readers:
            raise ValueError(f"Unsupported FX file format: {suffix}")

        df = readers[suffix]()
        print(f"✅ FX file loaded: {path.name} shape={df.shape}")
        return df

    def _clean(self, df: pd.DataFrame) -> pd.DataFrame:
        df = standardize_columns(df)

        date_col = next((c for c in df.columns if c in {"date", "dt", "dates"}), None)

        if date_col is None:
            raise KeyError("FX file must contain a date column.")

        df = df.rename(columns={date_col: "date"})
        df = parse_date_column(df, frame_name="FX file")

        configured = [
            to_snake_case(c)
            for c in self.cfg.latam_currencies
            if not (self.cfg.exclude_ars and to_snake_case(c) == "ars")
        ]

        available = [c for c in configured if c in df.columns]
        missing = set(configured) - set(available)

        if missing:
            print(f"⚠️  FX columns missing from file, skipped: {sorted(missing)}")

        if not available:
            raise ValueError("No LATAM currency columns found in FX file.")

        for col in available:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            df[col] = df[col].where(df[col] > 0, np.nan)

        return df[["date"] + available].copy()

    def _resolve_weights(self, df: pd.DataFrame) -> dict[str, float]:
        ccy_cols = [c for c in df.columns if c != "date"]
        gdp_map = {to_snake_case(k): v for k, v in self.cfg.gdp_weights_usd_bn.items()}

        known_gdps = [gdp_map[c] for c in ccy_cols if c in gdp_map]
        fallback = float(np.mean(known_gdps)) if known_gdps else 1.0

        raw = {c: gdp_map.get(c, fallback) for c in ccy_cols}
        return normalize_weights(raw)

    def _zscore_and_weight(
        self,
        signal: pd.DataFrame,
        ccy_cols: list[str],
        weights: dict[str, float],
        invert: bool = False,
    ) -> pd.Series:
        sign = -1.0 if invert else 1.0

        z_frame = pd.concat(
            [
                (
                    sign * rolling_zscore(
                        signal[col],
                        window=self.cfg.zscore_window,
                        min_periods=self.cfg.zscore_min_periods,
                    )
                ).rename(col)
                for col in ccy_cols
            ],
            axis=1,
        )

        return weighted_composite(z_frame, weights)

    def _finalize(self, composite: pd.Series) -> pd.Series:
        return expanding_standardize(composite, self.cfg.zscore_min_periods)

    def _score_direction(
        self,
        df_clean: pd.DataFrame,
        df_logret: pd.DataFrame,
        ccy_cols: list[str],
        weights: dict[str, float],
    ) -> pd.DataFrame:
        roll_mean = pd.concat(
            [
                df_logret[col]
                .rolling(
                    window=self.cfg.zscore_window,
                    min_periods=self.cfg.zscore_min_periods,
                )
                .mean()
                .rename(col)
                for col in ccy_cols
            ],
            axis=1,
        )

        composite = self._zscore_and_weight(
            roll_mean,
            ccy_cols,
            weights,
            invert=True,
        )

        return pd.DataFrame(
            {
                "date": df_clean["date"].values,
                FX_COL_DIRECTION: self._finalize(composite).values,
            }
        )

    def _score_vol(
        self,
        df_clean: pd.DataFrame,
        df_logret: pd.DataFrame,
        ccy_cols: list[str],
        weights: dict[str, float],
    ) -> pd.DataFrame:
        roll_vol = pd.concat(
            [
                (
                    df_logret[col]
                    .rolling(
                        window=self.cfg.zscore_window,
                        min_periods=self.cfg.zscore_min_periods,
                    )
                    .std()
                    .multiply(np.sqrt(252))
                ).rename(col)
                for col in ccy_cols
            ],
            axis=1,
        )

        composite = self._zscore_and_weight(
            roll_vol,
            ccy_cols,
            weights,
            invert=False,
        )

        return pd.DataFrame(
            {
                "date": df_clean["date"].values,
                FX_COL_VOL: self._finalize(composite).values,
            }
        )


# ==========================================================
# MAIN BOND FEATURE BUILDER
# ==========================================================

class BondFeatureBuilder:
    def __init__(self, config: Optional[FeatureBuilderConfig] = None) -> None:
        self.cfg = config or FeatureBuilderConfig()
        self.db = MasterDataset()

        self.df_bonds: Optional[pd.DataFrame] = None
        self.df_macro: Optional[pd.DataFrame] = None
        self.df_final: Optional[pd.DataFrame] = None

        self.credit_risk_cols: list[str] = []

    def run(self, output_path: Optional[str] = None) -> pd.DataFrame:
        self.load_data()
        self.engineer_macro_features()
        self.merge_macro_with_bonds()
        self.compute_bond_features()

        if output_path:
            self.export(output_path)

        print("🎯 Feature engineering pipeline completed.")
        return self.df_final.copy()

    def load_data(self) -> None:
        self.df_bonds = self._load_frame(self.db.em_bonds(), "bonds")
        self.df_macro = self._load_frame(self.db.macro(), "macro")

        print(f"✅ Loaded bonds : {self.df_bonds.shape}")
        print(f"✅ Loaded macro : {self.df_macro.shape}")

        self._inject_credit_risk()
        self._inject_fx_scores()
        self._inject_gpr()

    def engineer_macro_features(self) -> None:
        if self.df_macro is None:
            raise RuntimeError("Call load_data() first.")

        df = standardize_columns(self.df_macro.copy())

        credit_cols = self._active_credit_risk_cols()
        ordinary_macro_cols = (
            list(self.cfg.macro_columns)
            + self._active_fx_cols()
            + self._active_gpr_cols()
        )

        ordinary_macro_cols = list(dict.fromkeys([to_snake_case(c) for c in ordinary_macro_cols]))
        ordinary_available = [c for c in ordinary_macro_cols if c in df.columns]
        credit_available = [c for c in credit_cols if c in df.columns]

        if ordinary_available:
            df[ordinary_available] = df[ordinary_available].apply(pd.to_numeric, errors="coerce")

        if credit_available:
            df[credit_available] = df[credit_available].apply(pd.to_numeric, errors="coerce")

        keep_cols = ["date"] + ordinary_available + credit_available

        df = (
            df[keep_cols]
            .groupby("date", as_index=False)
            .mean(numeric_only=True)
            .sort_values("date")
            .reset_index(drop=True)
        )

        blocks: list[pd.DataFrame] = [df[["date"]].copy()]

        # Keep exactly two new credit-risk columns as pass-through features.
        # They are not rolled unless roll_credit_risk_features=True.
        if credit_available:
            credit_block = df[credit_available].copy()

            if self.cfg.fill_macro_features:
                credit_block = fill_numeric_frame(credit_block)

            blocks.append(credit_block)

        # Build one or more macro transformations.  The optimizer can vary both
        # the lookback and the transformation method without changing this code.
        if ordinary_available:
            for method in self.cfg.macro_methods:
                for w in self.cfg.macro_windows:
                    transformed = self._transform_macro_block(
                        df[ordinary_available], method=method, window=w
                    )
                    blocks.append(transformed)

        # Optional switch, default false, to avoid creating ma3_ versions
        # of the two new credit-risk composites.
        if self.cfg.roll_credit_risk_features and credit_available:
            for w in self.cfg.macro_windows:
                rolled_credit = (
                    df[credit_available]
                    .rolling(window=w, min_periods=min(max(1, self.cfg.macro_min_periods), w))
                    .mean()
                    .add_prefix(f"ma{w}_")
                )

                if self.cfg.fill_macro_features:
                    rolled_credit = fill_numeric_frame(rolled_credit)

                blocks.append(rolled_credit)

        self.df_macro = pd.concat(blocks, axis=1)
        self.df_macro = self.df_macro.loc[:, ~self.df_macro.columns.duplicated()].copy()

        print(f"✅ Macro features engineered: {self.df_macro.shape[1] - 1} columns.")

    def _transform_macro_block(
        self,
        frame: pd.DataFrame,
        *,
        method: str,
        window: int,
    ) -> pd.DataFrame:
        method = str(method).lower().strip()
        min_periods = min(max(1, int(self.cfg.macro_min_periods)), int(window))

        if method == "mean":
            out = frame.rolling(window=window, min_periods=min_periods).mean()
            prefix = f"ma{window}_"
        elif method == "median":
            out = frame.rolling(window=window, min_periods=min_periods).median()
            prefix = f"med{window}_"
        elif method == "ewm":
            out = frame.ewm(
                span=window, min_periods=min_periods, adjust=self.cfg.ewm_adjust
            ).mean()
            prefix = f"ewm{window}_"
        elif method == "zscore":
            mu = frame.rolling(window=window, min_periods=min_periods).mean()
            sigma = frame.rolling(window=window, min_periods=min_periods).std()
            out = (frame - mu) / sigma.replace(0.0, np.nan)
            prefix = f"zs{window}_"
        elif method == "diff":
            out = frame.diff(periods=window)
            prefix = f"diff{window}_"
        elif method == "pct_change":
            out = frame.pct_change(periods=window, fill_method=None)
            out = out.replace([np.inf, -np.inf], np.nan)
            prefix = f"pct{window}_"
        else:
            raise ValueError(
                f"Unsupported macro method {method!r}. "
                "Use mean, median, ewm, zscore, diff, or pct_change."
            )

        out = out.add_prefix(prefix)
        if self.cfg.fill_macro_features:
            if method in {"diff", "pct_change", "zscore"}:
                out = out.fillna(0.0)
            else:
                out = fill_numeric_frame(out)
        return out

    def merge_macro_with_bonds(self) -> None:
        if self.df_bonds is None or self.df_macro is None:
            raise RuntimeError("Call load_data() and engineer_macro_features() first.")

        self.df_bonds = pd.merge_asof(
            self.df_bonds.sort_values("date"),
            self.df_macro.sort_values("date"),
            on="date",
            direction="backward",
            allow_exact_matches=True,
        ).reset_index(drop=True)

        print(f"✅ Macro merged into bonds: {self.df_bonds.shape}")

    def compute_bond_features(self) -> None:
        if self.df_bonds is None:
            raise RuntimeError("Call merge_macro_with_bonds() first.")

        df = standardize_columns(self.df_bonds.copy())
        df = df.loc[:, ~df.columns.duplicated()].copy()

        self._coerce_dates(df, ["date", "maturity_dt", "issue_dt"])
        self._coerce_numerics(df)

        self._feat_time(df)
        self._feat_price(df)
        self._feat_liquidity(df)
        self._feat_size(df)
        self._feat_currency(df)
        self._feat_options(df)
        self._feat_seniority(df)

        sort_cols = ["date", "isin"] if "isin" in df.columns else ["date"]
        self.df_final = df.sort_values(sort_cols).reset_index(drop=True)

        print(f"✅ Bond features computed. Final shape: {self.df_final.shape}")

    def export(self, output_path: str) -> None:
        if self.df_final is None:
            raise RuntimeError("Call run() first.")

        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        suffix = path.suffix.lower()

        writers = {
            ".parquet": lambda: self.df_final.to_parquet(path, index=False),
            ".csv": lambda: self.df_final.to_csv(path, index=False),
            ".xlsx": lambda: self.df_final.to_excel(path, index=False),
            ".xls": lambda: self.df_final.to_excel(path, index=False),
        }

        if suffix not in writers:
            raise ValueError(
                f"Unsupported output format: {suffix}. "
                "Use .parquet, .csv, .xlsx or .xls."
            )

        writers[suffix]()
        print(f"📦 Exported to: {path}")

    def _load_frame(
        self,
        df: pd.DataFrame,
        name: str,
    ) -> pd.DataFrame:
        if df is None or df.empty:
            raise ValueError(f"{name} dataset is empty.")

        out = standardize_columns(df)

        if "date" not in out.columns:
            raise KeyError(f"{name} dataset must contain a date column.")

        return parse_date_column(out, frame_name=name)

    def _inject_credit_risk(self) -> None:
        credit_cfg = self.cfg.credit_risk_config

        if credit_cfg is None:
            print("ℹ️  No credit-risk config — LATAM credit-risk features skipped.")
            return

        if self.df_macro is None:
            raise RuntimeError("Macro dataframe not loaded.")

        df_credit = LatamCreditRiskCompositeBuilder(credit_cfg).build(self.df_macro)
        injected = [c for c in df_credit.columns if c != "date"]

        if not injected:
            print("ℹ️  No LATAM credit-risk features injected.")
            return

        self.df_macro = pd.merge_asof(
            self.df_macro.sort_values("date"),
            df_credit.sort_values("date"),
            on="date",
            direction="backward",
            allow_exact_matches=True,
        ).reset_index(drop=True)

        self.df_macro = self.df_macro.loc[:, ~self.df_macro.columns.duplicated()].copy()
        self.credit_risk_cols = injected

        print(f"✅ Credit-risk features injected into macro: {injected}")

    def _inject_fx_scores(self) -> None:
        fx_cfg = self.cfg.fx_score_config

        if fx_cfg is None or not fx_cfg.fx_file_path:
            print("ℹ️  No FX score config — LATAM FX scores skipped.")
            return

        if self.df_macro is None:
            raise RuntimeError("Macro dataframe not loaded.")

        df_fx = LatamFxScoreBuilder(fx_cfg).build()

        self.df_macro = pd.merge_asof(
            self.df_macro.sort_values("date"),
            df_fx.sort_values("date"),
            on="date",
            direction="backward",
            allow_exact_matches=True,
        ).reset_index(drop=True)

        injected = [c for c in df_fx.columns if c != "date"]
        print(f"✅ LATAM FX scores injected into macro: {injected}")

    def _inject_gpr(self) -> None:
        gpr_cfg = self.cfg.gpr_config

        if gpr_cfg is None or not gpr_cfg.gpr_file_path:
            print("ℹ️  No GPR config — geopolitical risk features skipped.")
            return

        if self.df_macro is None:
            raise RuntimeError("Macro dataframe not loaded.")

        df_gpr = GprFeatureBuilder(gpr_cfg).build()

        self.df_macro = pd.merge_asof(
            self.df_macro.sort_values("date"),
            df_gpr.sort_values("date"),
            on="date",
            direction="backward",
            allow_exact_matches=True,
        ).reset_index(drop=True)

        injected = [c for c in df_gpr.columns if c != "date"]
        print(f"✅ GPR features injected into macro: {len(injected)} columns")

    def _active_credit_risk_cols(self) -> list[str]:
        return [to_snake_case(c) for c in self.credit_risk_cols]

    def _active_fx_cols(self) -> list[str]:
        fx_cfg = self.cfg.fx_score_config
        return list(FX_SCORE_COLUMNS) if (fx_cfg and fx_cfg.fx_file_path) else []

    def _active_gpr_cols(self) -> list[str]:
        gpr_cfg = self.cfg.gpr_config

        if gpr_cfg is None or not gpr_cfg.gpr_file_path:
            return []

        cols = list(GPR_ENGINEERED_COLUMNS)

        for iso in GprFeatureBuilder._COL_TO_ISO.values():
            for suffix in GPR_COUNTRY_SUFFIXES:
                cols.append(f"gpr_{iso}_{suffix}")

        for suffix in GPR_COUNTRY_SUFFIXES:
            cols.append(f"gpr_cri_{suffix}")

        return cols

    def _coerce_dates(
        self,
        df: pd.DataFrame,
        cols: Iterable[str],
    ) -> None:
        for col in cols:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors="coerce")

    def _coerce_numerics(self, df: pd.DataFrame) -> None:
        candidates = [
            "ask_price",
            "bid_price",
            "mid_price",
            "px_ask",
            "px_bid",
            "px_mid",
            "cpn",
            "coupon",
            "par_val",
            "par_value",
            "amt_outstanding",
            "amount_outstanding",
            "issue_size",
            "size",
            "z_spread_bps",
            "z_spread_mid",
        ]

        for col in candidates:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

    def _feat_time(self, df: pd.DataFrame) -> None:
        if {"date", "maturity_dt"}.issubset(df.columns):
            df["ttm"] = (
                (df["maturity_dt"] - df["date"]).dt.days / 365.25
            ).clip(lower=0)

        if {"date", "issue_dt"}.issubset(df.columns):
            df["age_years"] = (
                (df["date"] - df["issue_dt"]).dt.days / 365.25
            ).clip(lower=0)

        if "issue_dt" in df.columns:
            df["issue_year"] = df["issue_dt"].dt.year

        if "maturity_dt" in df.columns:
            df["maturity_year"] = df["maturity_dt"].dt.year

        if "date" in df.columns:
            df["obs_year"] = df["date"].dt.year
            df["obs_month"] = df["date"].dt.month
            df["obs_week"] = df["date"].dt.isocalendar().week.astype(int)

    def _feat_price(self, df: pd.DataFrame) -> None:
        ask_col = first_existing_column(df, ["ask_price", "px_ask"])
        bid_col = first_existing_column(df, ["bid_price", "px_bid"])
        mid_col = first_existing_column(df, ["mid_price", "px_mid"])

        if ask_col and bid_col:
            ask = pd.to_numeric(df[ask_col], errors="coerce")
            bid = pd.to_numeric(df[bid_col], errors="coerce")
            mid_calc = 0.5 * (ask + bid)

            df["mid_price_calc"] = mid_calc
            df["ba_spread"] = ((ask - bid) / mid_calc).where(mid_calc > 0)

            if "mid_price" not in df.columns:
                df["mid_price"] = mid_calc

        elif mid_col and "mid_price" not in df.columns:
            df["mid_price"] = pd.to_numeric(df[mid_col], errors="coerce")

    def _feat_liquidity(self, df: pd.DataFrame) -> None:
        nan_cols = ["ret", "zero_ret_ind", "zr_proxy", "zr_obs_count"]

        if "isin" not in df.columns or "mid_price" not in df.columns:
            for col in nan_cols:
                df[col] = np.nan
            return

        df.sort_values(["isin", "date"], inplace=True)

        df["mid_price"] = pd.to_numeric(df["mid_price"], errors="coerce")
        df["ret"] = df.groupby("isin", sort=False)["mid_price"].pct_change()

        valid = df["ret"].notna()

        df["zero_ret_ind"] = np.where(
            valid & (df["ret"].abs() <= 1e-12),
            1.0,
            0.0,
        )
        df.loc[~valid, "zero_ret_ind"] = np.nan

        df["zr_proxy"] = (
            df.groupby("isin", sort=False)["zero_ret_ind"]
            .transform(
                lambda s: s.rolling(
                    window=self.cfg.zr_window,
                    min_periods=self.cfg.zr_min_periods,
                ).mean()
            )
        )

        df["zr_obs_count"] = (
            df.groupby("isin", sort=False)["zero_ret_ind"]
            .transform(
                lambda s: s.rolling(
                    window=self.cfg.zr_window,
                    min_periods=1,
                ).count()
            )
        )

    def _feat_size(self, df: pd.DataFrame) -> None:
        size_col = first_existing_column(
            df,
            [
                "size",
                "amt_outstanding",
                "amount_outstanding",
                "issue_size",
                "par_val",
                "par_value",
            ],
        )

        if size_col is None:
            df["size"] = np.nan
            df["log_size"] = np.nan
            return

        size = pd.to_numeric(df[size_col], errors="coerce")

        if size_col != "size":
            df["size"] = size

        df["log_size"] = np.log1p(size.clip(lower=0))

    def _feat_currency(self, df: pd.DataFrame) -> None:
        ccy_col = first_existing_column(df, ["ccy", "currency", "crncy"])

        if ccy_col is None:
            df["hard_ccy"] = np.nan
            return

        ccy = df[ccy_col].astype(str).str.lower().str.strip()
        df["hard_ccy"] = ccy.isin(self.cfg.hard_currencies).astype(float)

    def _feat_options(self, df: pd.DataFrame) -> None:
        for raw_col in ["callable", "putable", "sinkable"]:
            df[f"option_{raw_col}"] = (
                (normalize_yes_no(df[raw_col]) == "y").astype(int)
                if raw_col in df.columns
                else 0
            )

    def _feat_seniority(self, df: pd.DataFrame) -> None:
        rank = (
            df["payment_rank"].apply(normalize_text)
            if "payment_rank" in df.columns
            else pd.Series("", index=df.index)
        )

        def contains(pattern: str) -> pd.Series:
            return rank.str.contains(pattern, regex=False)

        first_lien = contains("1st lien") | contains("first lien")
        second_lien = contains("2nd lien") | contains("second lien")

        df["seniority_sr_unsecured"] = (
            contains("sr unsecured") | contains("senior unsecured")
        ).astype(int)

        df["seniority_subordinated"] = contains("subord").astype(int)
        df["seniority_1st_lien"] = first_lien.astype(int)
        df["seniority_2nd_lien"] = second_lien.astype(int)

        df["seniority_secured"] = (
            contains("secured") | first_lien | second_lien
        ).astype(int)

        df["seniority_unsecured"] = contains("unsecured").astype(int)


# ==========================================================
# PROGRAMMATIC ENTRY POINT
# ==========================================================

def make_default_feature_config(
    *,
    macro_windows: tuple[int, ...] = (3,),
    macro_methods: tuple[str, ...] = ("mean",),
    zr_window: int = 21,
    zr_min_periods: int = 5,
    roll_credit_risk_features: bool = False,
    credit_overrides: Optional[dict] = None,
    fx_overrides: Optional[dict] = None,
    gpr_overrides: Optional[dict] = None,
) -> FeatureBuilderConfig:
    """Create a complete feature-engineering configuration for scripts/optimizers."""
    credit_kwargs = dict(
        cds_raw_columns=LATAM_CDS_RAW_COLUMNS,
        jpm_spread_raw_columns=LATAM_JPM_SPREAD_RAW_COLUMNS,
        country_gdp_usd_bn=LATAM_CREDIT_RISK_GDP_USD_BN,
        zscore_window_weeks=52, zscore_min_periods=12,
        momentum_window_weeks=4, vol_window_weeks=12, max_stale_days=10,
        level_weight=0.60, momentum_weight=0.30, vol_weight=0.10,
    )
    credit_kwargs.update(credit_overrides or {})

    fx_kwargs = dict(
        fx_file_path=FX_LATAM, fx_sheet_name="Sheet1",
        latam_currencies=tuple(LATAM_GDP_USD_BN.keys()),
        zscore_window=252, zscore_min_periods=60, exclude_ars=False,
    )
    fx_kwargs.update(fx_overrides or {})

    gpr_kwargs = dict(
        gpr_file_path=GPR, gpr_sheet_name="Sheet1",
        zscore_window=36, zscore_min_periods=12,
        momentum_window=12, vol_window=12, decimal=",",
    )
    gpr_kwargs.update(gpr_overrides or {})

    return FeatureBuilderConfig(
        zr_window=zr_window, zr_min_periods=zr_min_periods,
        macro_windows=tuple(macro_windows), macro_methods=tuple(macro_methods),
        fill_macro_features=True,
        credit_risk_config=CreditRiskConfig(**credit_kwargs),
        fx_score_config=FxScoreConfig(**fx_kwargs),
        gpr_config=GprConfig(**gpr_kwargs),
        roll_credit_risk_features=roll_credit_risk_features,
    )


def run_feature_engineering(
    config: FeatureBuilderConfig,
    output_path: str | Path,
) -> pd.DataFrame:
    """Run feature engineering and return the generated modelling table."""
    return BondFeatureBuilder(config).run(output_path=str(output_path))


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":
    config = make_default_feature_config(
        macro_windows=(3,),
        macro_methods=("mean",),
        zr_window=21,
        zr_min_periods=5,
        roll_credit_risk_features=False,
    )
    run_feature_engineering(config, FEATURE_ENGINEERED)

# %%