# %% DATA CLEANING PIPELINE

#!/usr/bin/env python3
"""
Regime-aware risk decomposition pipeline for EM corporate bond Z-spreads.

Standalone script version of the thesis notebook.
All operational settings are in the __main__ block at the bottom.

Main empirical chain:
    1. optional bond-data cleaning and feature screening;
    2. baseline OLS block decomposition;
    3. residual PCA latent common factor;
    4. compact HMM regime identification;
    5. HMM-conditioned risk decomposition.

Important universe rule:
    - UNIVERSE_MODE = "LATAM": LATAM-specific inputs may be used.
    - UNIVERSE_MODE = "ALL_EM": LATAM-specific input variables are automatically excluded
      from selected model features and from HMM state identification.
"""

# BOND DATA CLEANING + SCREENING PIPELINE
# ==========================================================
# Author: Amin Tarbouch
#
# Purpose:
#   - Optional LATAM ex-Caribbean filter OR full-universe mode
#   - Optional Government-sector exclusion
#   - Fixed coupon filter
#   - Callable / putable / sinkable exclusion
#   - Bond, country-risk, currency, sector, seniority dummies
#   - Weekly / monthly panel deduplication
#   - Level / diff / pct-change model target
#   - Explicit feature taxonomy:
#       GLOBAL
#       EMERGING
#       BONDS
#   - Correlation screen
#   - VIF screen
#   - Export cleaned dataset + selected feature metadata
#
# Output layout:
#   OUTPUT_DIR/
#     MASTER_CLEAN.xlsx              ← main cleaned panel (input to decomposition)
#     output_for_latex/
#       selected_features.csv        ← screened feature list with block labels
#       input_dataset_audit_summary.csv
#       input_dataset_column_audit.csv
#       input_dataset_top_counts.csv
#       latam_rows_by_cntry_of_risk.csv
# ==========================================================

from __future__ import annotations

import sys
import os
import re
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import plotly.express as px

from sklearn.preprocessing import StandardScaler
from statsmodels.stats.outliers_influence import variance_inflation_factor

# ==========================================================
# Path resolution — single source of truth via path_config.py
# ==========================================================

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from path_config import (       # hard import — no silent fallback
    MASTER,                     # OUTPUT_DIR / "master_dataset_features_eng.xlsx"
    MASTER_clean,               # OUTPUT_DIR / "MASTER_clean.xlsx"
    OUTPUT_DIR,                 # base output folder (network drive)
    CLEAN_DATA,                 # OUTPUT_DIR / "dataset_cleanedReady.xlsx"
    SELECTED_FEATURES,          # OUTPUT_DIR / "selected_features.csv"
    DEFAULT_SHEET,              # "Worksheet"
)

# ── Output paths ──────────────────────────────────────────────────────────────
# Main cleaned panel — written directly to OUTPUT_DIR.
MASTER_CLEAN_PATH: Path = OUTPUT_DIR / "MASTER_CLEAN.xlsx"

# All auxiliary outputs (feature list, audit CSVs) go into this sub-folder.
LATEX_OUTPUT_DIR: Path  = OUTPUT_DIR / "output_for_latex"

# Convenience aliases used by the pipeline internals.
MASTER_DATA_PATH: Path  = MASTER

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ==========================================================
# Excel helper
# ==========================================================

def read_excel_sheet_safe(
    path: str | Path,
    sheet_name: int | str = 0,
    context: str = "Excel file",
) -> pd.DataFrame:
    """
    Read an Excel sheet safely, falling back to the first sheet when the
    requested sheet name is not found.
    """
    path = Path(path)
    try:
        return pd.read_excel(path, sheet_name=sheet_name)
    except ValueError as exc:
        msg = str(exc)
        if "Worksheet named" not in msg and "Worksheet index" not in msg:
            raise
        xls = pd.ExcelFile(path)
        print(f"Sheet {sheet_name!r} not found in {context}: {path}")
        print(f"Available sheet(s): {xls.sheet_names}")
        print("Falling back to the first sheet, sheet_name=0.")
        return pd.read_excel(path, sheet_name=0)


# ==========================================================
# Raw-column whitelist
# ==========================================================

ALLOWED_RAW_COLUMNS: tuple[str, ...] = (
    "DATE", "ISIN", "TICKER", "BBG_SECURITY", "MID_PRICE", "DIRTY_PRICE",
    "BID_PRICE", "ASK_PRICE", "Z_SPREAD_MID", "PAR_VALUE",
    "RATING_SP_IS_FALLBACK", "RATING_MOODY_IS_FALLBACK", "RATING_FITCH_IS_FALLBACK",
    "DESCRIPTION", "CCY", "PRICE", "MV", "ISSUE_DT", "MATURITY",
    "INDUSTRY_SECTOR", "COUNTRY", "COUNTRY_FULL_NAME", "ISSUER", "CNTRY_OF_RISK",
    "CURRENCY", "CPN_TYP", "CPN_FREQ", "COUPON", "PAYMENT_RANK", "CALLABLE",
    "PUTABLE", "SINKABLE", "EFF_START", "EFF_END", "LATAM_CDS_CREDIT_RISK",
    "LATAM_JPM_SPREAD_CREDIT_RISK", "MA3_VIX_INDEX", "MA3_UKX_INDEX",
    "MA3_MOVE_INDEX", "MA3_CDX_IG_CDSI_GEN_5Y_CORP",
    "MA3_ITRX_EUR_CDSI_GEN_5Y_CORP", "MA3_GDP_CQOQ_INDEX",
    "MA3_EUGNEMUQ_INDEX", "MA3_CPI_YOY_INDEX", "MA3_ECCPEMUY_INDEX",
    "MA3_BFCIUS_INDEX", "MA3_BFCIEU_INDEX", "MA3_STOXX600", "MA3_SP500",
    "MA3_MSCI_EM", "MA3_JPM_EMBI", "MA3_EPUCEMEC_INDEX", "MA3_CAFZUUEM_INDEX",
    "MA3_AONILS_INDEX", "MA3_GLCRPCR_INDEX", "MA3_GLCRCBV_INDEX",
    "MA3_GLCRNCB_INDEX", "MA3_GCILMANM_INDEX", "MA3_GCILNATL_INDEX",
    "MA3_CRPTBRAZ_INDEX", "MA3_CRPTCHIN_INDEX", "MA3_CRPTHOKO_INDEX",
    "MA3_CRPTMEXI_INDEX", "MA3_CRPTKORE_INDEX", "MA3_CRPTINDI_INDEX",
    "MA3_CRPTUNAE_INDEX", "MA3_HG1_COMDTY", "MA3_S_1_COMDTY",
    "MA3_GC1_COMDTY", "MA3_USGG10YR_INDEX", "MA3_FEDL01_INDEX",
    "MA3_BZSTSETA_INDEX", "MA3_MXONBR_INDEX",
    "MA3_LATAM_FX_DIRECTION", "MA3_LATAM_FX_VOL",
    "MA3_GPR_LEVEL", "MA3_GPR_MOMENTUM", "MA3_GPR_VOL", "MA3_GPR_ACTS_SHARE",
    "MA3_GPR_LATAM_LEVEL", "MA3_GPR_LATAM_MOMENTUM", "MA3_GPR_LATAM_VOL",
    "MA3_GPR_BRA_LEVEL", "MA3_GPR_BRA_MOMENTUM", "MA3_GPR_BRA_VOL",
    "MA3_GPR_CHL_LEVEL", "MA3_GPR_CHL_MOMENTUM", "MA3_GPR_CHL_VOL",
    "MA3_GPR_COL_LEVEL", "MA3_GPR_COL_MOMENTUM", "MA3_GPR_COL_VOL",
    "MA3_GPR_MEX_LEVEL", "MA3_GPR_MEX_MOMENTUM", "MA3_GPR_MEX_VOL",
    "MA3_GPR_PER_LEVEL", "MA3_GPR_PER_MOMENTUM", "MA3_GPR_PER_VOL",
    "MA3_GPR_CRI_LEVEL", "MA3_GPR_CRI_MOMENTUM", "MA3_GPR_CRI_VOL",
    "AGE_YEARS", "ISSUE_YEAR", "OBS_YEAR", "OBS_MONTH", "OBS_WEEK",
    "MID_PRICE_CALC", "BA_SPREAD", "HARD_CCY", "OPTION_CALLABLE", "OPTION_PUTABLE",
    "OPTION_SINKABLE", "SENIORITY_SR_UNSECURED", "SENIORITY_SUBORDINATED",
    "SENIORITY_1ST_LIEN", "SENIORITY_2ND_LIEN", "SENIORITY_SECURED",
    "SENIORITY_UNSECURED", "Z_SPREAD_BPS",
)

ALLOWED_RAW_COLUMN_SET: set[str] = set(ALLOWED_RAW_COLUMNS)

ALLOWED_INTERNAL_COLUMNS: set[str] = {
    "MODEL_TARGET", "MODEL_TARGET_LEVEL", "TARGET_LAG", "YEAR_WEEK", "YEAR_MONTH",
    "CNTRY_OF_RISK_FULL_NAME",
}

ALLOWED_DUMMY_PREFIXES: tuple[str, ...] = (
    "CNTRY_OF_RISK_",
    "CURRENCY_",
    "CCY_",
    "INDUSTRY_SECTOR_",
    "PAYMENT_RANK_",
)

DISALLOWED_DERIVED_MODEL_FEATURES: set[str] = {"TTM", "SIZE", "LOG_SIZE", "TIME_FE"}


def is_allowed_source_or_internal_column(column: str, keep_internal: bool = True) -> bool:
    name = str(column).upper().strip()
    if name in ALLOWED_RAW_COLUMN_SET:
        return True
    if keep_internal and name in ALLOWED_INTERNAL_COLUMNS:
        return True
    if name.startswith(ALLOWED_DUMMY_PREFIXES):
        return True
    return False


def is_allowed_model_input_feature(feature: str) -> bool:
    name = str(feature).upper().strip()
    if name in DISALLOWED_DERIVED_MODEL_FEATURES:
        return False
    return is_allowed_source_or_internal_column(name, keep_internal=False)


def restrict_dataframe_to_allowed_columns(
    df: pd.DataFrame,
    *,
    keep_internal: bool = True,
    context: str = "dataset",
) -> pd.DataFrame:
    keep_cols = [
        col for col in df.columns
        if is_allowed_source_or_internal_column(col, keep_internal=keep_internal)
    ]
    dropped = [col for col in df.columns if col not in keep_cols]
    if dropped:
        print(
            f"Column whitelist [{context}]: kept {len(keep_cols):,}/{len(df.columns):,} columns; "
            f"dropped {len(dropped):,} extra column(s)."
        )
        preview = dropped[:20]
        print("Dropped extra columns preview:", preview)
        if len(dropped) > len(preview):
            print(f"... plus {len(dropped) - len(preview):,} more.")
    return df.loc[:, keep_cols].copy()


# ==========================================================
# FEATURE TAXONOMY
# ==========================================================

class FeatureTaxonomy:
    GLOBAL:   str = "Global"
    EMERGING: str = "Emerging"
    BONDS:    str = "Bonds"
    UNKNOWN:  str = "Unknown"

    GLOBAL_FEATURES: set[str] = {
        "MA3_UKX_INDEX", "MA3_STOXX600", "MA3_SP500",
        "MA3_CDX_IG_CDSI_GEN_5Y_CORP", "MA3_ITRX_EUR_CDSI_GEN_5Y_CORP",
        "MA3_GDP_CQOQ_INDEX", "MA3_ECCPEMUY_INDEX", "MA3_EUGNEMUQ_INDEX",
        "MA3_CPI_YOY_INDEX", "MA3_BFCIUS_INDEX", "MA3_BFCIEU_INDEX",
        "MA3_VIX_INDEX", "MA3_MOVE_INDEX", "MA3_AONILS_INDEX",
        "MA3_GLCRPCR_INDEX", "MA3_GLCRCBV_INDEX", "MA3_GLCRNCB_INDEX",
        "MA3_GCILMANM_INDEX", "MA3_GCILNATL_INDEX", "MA3_GPR_LEVEL",
        "MA3_HG1_COMDTY", "MA3_S_1_COMDTY", "MA3_GC1_COMDTY",
        "MA3_USGG10YR_INDEX", "MA3_FEDL01_INDEX",
        "OBS_YEAR", "OBS_MONTH", "OBS_WEEK", "YEAR_WEEK", "YEAR_MONTH",
        "TIME_FE", "TIME_FE_2021", "TIME_FE_2022", "TIME_FE_2023",
        "TIME_FE_2024", "TIME_FE_2025", "TIME_FE_2026",
    }

    EMERGING_FEATURES: set[str] = {
        "CNTRY_OF_RISK",
        "CNTRY_OF_RISK_CL", "CNTRY_OF_RISK_CO", "CNTRY_OF_RISK_CR",
        "CNTRY_OF_RISK_GT", "CNTRY_OF_RISK_MX", "CNTRY_OF_RISK_PE",
        "MA3_JPM_EMBI", "MA3_MSCI_EM", "MA3_EPUCEMEC_INDEX", "MA3_CAFZUUEM_INDEX",
        "MA3_CRPTBRAZ_INDEX", "MA3_CRPTCHIN_INDEX", "MA3_CRPTHOKO_INDEX",
        "MA3_CRPTMEXI_INDEX", "MA3_CRPTKORE_INDEX", "MA3_CRPTINDI_INDEX",
        "MA3_CRPTUNAE_INDEX", "MA3_GPR_LATAM_MOMENTUM",
        "MA3_BZSTSETA_INDEX", "MA3_MXONBR_INDEX",
        "LATAM_CDS_CREDIT_RISK", "LATAM_JPM_SPREAD_CREDIT_RISK",
    }

    BOND_FEATURES: set[str] = {
        "CURRENCY", "CCY", "CPN_TYP", "CPN_FREQ", "PAYMENT_RANK",
        "CALLABLE", "PUTABLE", "SINKABLE", "EFF_START", "EFF_END",
        "ISSUE_YEAR", "MID_PRICE_CALC", "SIZE", "LOG_SIZE", "HARD_CCY",
        "MID_PRICE", "DIRTY_PRICE", "BID_PRICE", "ASK_PRICE", "BA_SPREAD",
        "OPTION_CALLABLE", "OPTION_PUTABLE", "OPTION_SINKABLE",
        "SENIORITY_SUBORDINATED", "SENIORITY_1ST_LIEN", "SENIORITY_2ND_LIEN",
        "SENIORITY_SECURED", "SENIORITY_UNSECURED", "SENIORITY_SR_UNSECURED",
        "Z_SPREAD_BPS", "Z_SPREAD_MID", "TARGET_LAG", "MODEL_TARGET",
        "COUPON", "PAR_VAL", "PAR_VALUE", "TTM", "AGE_YEARS",
        "PAYMENT_RANK_SUBORDINATED",
        "INDUSTRY_SECTOR_CONSUMER, CYCLICAL", "INDUSTRY_SECTOR_COMMUNICATIONS",
        "INDUSTRY_SECTOR_CONSUMER, NON_CYCLICAL", "INDUSTRY_SECTOR_ENERGY",
        "INDUSTRY_SECTOR_FINANCIAL", "INDUSTRY_SECTOR_INDUSTRIAL",
        "INDUSTRY_SECTOR_UTILITIES",
    }

    EMERGING_PREFIXES: tuple[str, ...] = (
        "CNTRY_OF_RISK_", "COUNTRY_", "COUNTRY_FULL_NAME_",
        "MA3_GPR_LATAM", "MA3_GPR_BRA", "MA3_GPR_BR",
        "MA3_GPR_CHL", "MA3_GPR_CL", "MA3_GPR_COL", "MA3_GPR_CO",
        "MA3_GPR_MEX", "MA3_GPR_MX", "MA3_GPR_PER", "MA3_GPR_PE",
        "MA3_GPR_CRI", "MA3_GPR_CR", "MA3_LATAM", "LATAM_",
        "LATAM_CDS_", "LATAM_JPM_", "LATAM_CREDIT_",
    )

    EMERGING_TOKENS: tuple[str, ...] = (
        "EMBI", "MSCI_EM", "EPUCEMEC", "CAFZUUEM", "LATAM",
        "CRPTBRAZ", "CRPTCHIN", "CRPTHOKO", "CRPTMEXI",
        "CRPTKORE", "CRPTINDI", "CRPTUNAE", "BZSTSETA", "MXONBR",
    )

    BOND_PREFIXES: tuple[str, ...] = (
        "CURRENCY_", "CCY_", "PAYMENT_RANK_", "INDUSTRY_SECTOR_",
        "SECTOR_LEVEL_2_", "MERRILL_SECTOR_3_", "SENIORITY_", "OPTION_",
    )

    GLOBAL_PREFIXES: tuple[str, ...] = ("TIME_FE_",)

    @classmethod
    def classify(cls, feature: str) -> str:
        name = str(feature).upper().strip()
        base = name[4:] if name.startswith("MA3_") else name
        if name in cls.EMERGING_FEATURES:               return cls.EMERGING
        if name in cls.GLOBAL_FEATURES:                 return cls.GLOBAL
        if name in cls.BOND_FEATURES:                   return cls.BONDS
        if name.startswith(cls.EMERGING_PREFIXES):      return cls.EMERGING
        if any(t in name for t in cls.EMERGING_TOKENS): return cls.EMERGING
        if name.startswith("MA3_GPR_") or base.startswith("GPR_"): return cls.GLOBAL
        if name.startswith(cls.BOND_PREFIXES):          return cls.BONDS
        if name.startswith(cls.GLOBAL_PREFIXES):        return cls.GLOBAL
        if name.startswith("MA3_"):                     return cls.GLOBAL
        return cls.BONDS

    @classmethod
    def is_global(cls, f: str) -> bool:   return cls.classify(f) == cls.GLOBAL
    @classmethod
    def is_emerging(cls, f: str) -> bool: return cls.classify(f) == cls.EMERGING
    @classmethod
    def is_bond(cls, f: str) -> bool:     return cls.classify(f) == cls.BONDS


# ==========================================================
# Feature block helpers
# ==========================================================

MACRO_PREFIXES: tuple[str, ...] = ("MA3_",)
MACRO_EXACT:    set[str]        = {"OBS_YEAR", "OBS_MONTH", "OBS_WEEK"}

EM_PREFIXES: tuple[str, ...] = (
    "CNTRY_OF_RISK_", "COUNTRY_", "COUNTRY_FULL_NAME_", "LATAM_",
)
EM_TOKENS: tuple[str, ...] = (
    "EMBI", "MSCI_EM", "CRPT", "GPR_LATAM", "EPUCEMEC", "CAFZUUEM",
    "CDS_CREDIT_RISK", "JPM_SPREAD_CREDIT_RISK", "BZSTSETA", "MXONBR",
)
BOND_PREFIXES_HELPER: tuple[str, ...] = (
    "CCY_", "CURRENCY_", "INDUSTRY_SECTOR_", "SECTOR_LEVEL_2_",
    "MERRILL_SECTOR_3_", "PAYMENT_RANK_", "TIME_FE_",
)
BOND_EXACT: set[str] = {
    "COUPON", "CPN_FREQ", "PAR_VAL", "PAR_VALUE", "MV",
    "TTM", "AGE_YEARS", "ISSUE_YEAR",
    "BA_SPREAD", "SIZE", "LOG_SIZE", "HARD_CCY",
    "MID_PRICE", "DIRTY_PRICE", "MID_PRICE_CALC",
    "SENIORITY_SR_UNSECURED", "SENIORITY_SUBORDINATED",
    "SENIORITY_1ST_LIEN", "SENIORITY_2ND_LIEN",
    "SENIORITY_SECURED", "SENIORITY_UNSECURED",
}


def fallback_classify_feature(feature: str) -> str:
    name = str(feature).upper().strip()
    if name.startswith("PC") or name.startswith("REGIME_"):
        return "Latent"
    if name in MACRO_EXACT or name.startswith(MACRO_PREFIXES):
        return "Emerging" if any(t in name for t in EM_TOKENS) else "Global"
    if name.startswith(EM_PREFIXES) or any(t in name for t in EM_TOKENS):
        return "Emerging"
    if name.startswith(BOND_PREFIXES_HELPER) or name in BOND_EXACT:
        return "Bonds"
    return "Bonds"


def normalize_feature_type(value: str) -> str:
    v = str(value).strip().lower()
    if v in {"global", "macro"}:                            return "Global"
    if v in {"emerging", "em", "country", "country-risk"}:  return "Emerging"
    if v in {"bonds", "bond", "issuer", "instrument"}:      return "Bonds"
    if v in {"latent", "pca", "hmm", "regime"}:             return "Latent"
    return "Unknown"


# ==========================================================
# Universe-specific feature filters
# ==========================================================

LATAM_SPECIFIC_TOKENS: tuple[str, ...] = (
    "LATAM", "GPR_LATAM", "LATAM_CDS", "LATAM_JPM", "LATAM_CREDIT",
    "GPR_BRA", "GPR_BR", "GPR_CHL", "GPR_CL", "GPR_COL", "GPR_CO",
    "GPR_MEX", "GPR_MX", "GPR_PER", "GPR_PE", "GPR_CRI", "GPR_CR",
    "GPR_ARG", "GPR_AR",
    "CRPTBRAZ", "CRPTMEXI", "CRPTCHIL", "CRPTCOLO",
    "CRPTPERU", "CRPTARG", "CRPTCOST", "BZSTSETA", "MXONBR",
)

LATAM_COUNTRY_DUMMY_NAMES: set[str] = {
    "CNTRY_OF_RISK_AR", "CNTRY_OF_RISK_BO", "CNTRY_OF_RISK_BR", "CNTRY_OF_RISK_CL",
    "CNTRY_OF_RISK_CO", "CNTRY_OF_RISK_CR", "CNTRY_OF_RISK_EC", "CNTRY_OF_RISK_SV",
    "CNTRY_OF_RISK_GT", "CNTRY_OF_RISK_HN", "CNTRY_OF_RISK_MX", "CNTRY_OF_RISK_NI",
    "CNTRY_OF_RISK_PA", "CNTRY_OF_RISK_PY", "CNTRY_OF_RISK_PE", "CNTRY_OF_RISK_UY",
    "CNTRY_OF_RISK_VE",
}


def is_latam_specific_feature(feature: str) -> bool:
    name = str(feature).upper().strip()
    return name.startswith("LATAM_") or any(t in name for t in LATAM_SPECIFIC_TOKENS)


def is_country_dummy_feature(feature: str) -> bool:
    name = str(feature).upper().strip()
    return (
        name.startswith("CNTRY_OF_RISK_")
        or name.startswith("COUNTRY_")
        or name.startswith("COUNTRY_FULL_NAME_")
    )


# ==========================================================
# Metric helpers
# ==========================================================

def _valid_metric_pair(y_true, y_pred):
    yt = pd.Series(y_true).astype(float)
    yp = pd.Series(y_pred).astype(float)
    if len(yp) != len(yt):
        yp.index = yt.index[:len(yp)]
    pair = pd.concat([yt.rename("y_true"), yp.rename("y_pred")], axis=1)
    pair = pair.replace([np.inf, -np.inf], np.nan).dropna()
    if pair.empty:
        raise ValueError("No valid finite observations for metric computation.")
    return pair["y_true"], pair["y_pred"]


def compute_rmse(y_true, y_pred) -> float:
    from sklearn.metrics import mean_squared_error
    yt, yp = _valid_metric_pair(y_true, y_pred)
    return float(np.sqrt(mean_squared_error(yt, yp)))


def compute_mae(y_true, y_pred) -> float:
    from sklearn.metrics import mean_absolute_error
    yt, yp = _valid_metric_pair(y_true, y_pred)
    return float(mean_absolute_error(yt, yp))


# ==========================================================
# CONFIG
# ==========================================================

@dataclass
class DataCleaningConfig:
    data_path: str
    sheet_name: int | str = 0

    # Main cleaned output — written directly to OUTPUT_DIR.
    output_dataset: str = str(MASTER_CLEAN_PATH)

    # Auxiliary outputs — written to LATEX_OUTPUT_DIR.
    output_features: str = str(LATEX_OUTPUT_DIR / "selected_features.csv")

    target_col: str        = "Z_SPREAD_MID"
    frequency: str         = "weekly"
    target_mode: str       = "weekly_diff"
    target_lag_periods: int= 1

    latam_ex_caribbean_only: bool = True
    fixed_coupon_only: bool       = True
    exclude_government: bool      = True
    drop_option_bonds: bool       = True

    dummy_columns: tuple[str, ...] = (
        "CNTRY_OF_RISK",
        "CURRENCY",
        "INDUSTRY_SECTOR",
        "PAYMENT_RANK",
    )
    max_dummy_levels: int = 40

    time_fixed_effect: str = "none"

    include_global_features: bool       = True
    include_emerging_features: bool     = True
    include_bond_features: bool         = True
    include_yield_price_features: bool  = False

    corr_threshold: float          = 0.80
    drop_high_corr_features: bool  = True
    max_corr_features: int         = 45

    vif_threshold: float           = 10.0
    drop_high_vif_features: bool   = True
    max_vif_features: int          = 120

    def __post_init__(self) -> None:
        if self.data_path is None:
            raise ValueError(
                "\n[DataCleaningConfig] data_path is None.\n"
                "Check that MASTER is correctly defined in path_config.py."
            )

        self.data_path      = str(self.data_path)
        self.output_dataset = str(self.output_dataset)
        self.output_features= str(self.output_features)
        self.target_col     = self.target_col.upper().strip()
        self.frequency      = self.frequency.lower().strip()
        self.target_mode    = self.target_mode.lower().strip()
        self.time_fixed_effect = self.time_fixed_effect.lower().strip()

        if self.target_col not in {"Z_SPREAD_BPS", "Z_SPREAD_MID"}:
            raise ValueError(f"target_col must be 'Z_SPREAD_BPS' or 'Z_SPREAD_MID'. Got: {self.target_col!r}")

        if self.frequency not in {"weekly", "monthly"}:
            raise ValueError(f"frequency must be 'weekly' or 'monthly'. Got: {self.frequency!r}")

        valid_modes = {
            "level", "monthly_diff", "monthly_pct_change",
            "weekly_diff", "weekly_pct_change",
        }
        if self.target_mode not in valid_modes:
            raise ValueError(f"target_mode must be one of {valid_modes}. Got: {self.target_mode!r}")

        if self.frequency == "monthly" and self.target_mode in {"weekly_diff", "weekly_pct_change"}:
            raise ValueError(f"target_mode={self.target_mode!r} requires frequency='weekly'.")
        if self.frequency == "weekly" and self.target_mode in {"monthly_diff", "monthly_pct_change"}:
            raise ValueError(f"target_mode={self.target_mode!r} requires frequency='monthly'.")

        valid_tfe = {"none", "year", "month", "year_month", "week"}
        if self.time_fixed_effect not in valid_tfe:
            raise ValueError(f"time_fixed_effect must be one of {valid_tfe}. Got: {self.time_fixed_effect!r}")

        if self.target_lag_periods < 1:
            raise ValueError("target_lag_periods must be >= 1.")

        if not any([self.include_global_features,
                    self.include_emerging_features,
                    self.include_bond_features]):
            raise ValueError("At least one feature block must be enabled.")

    @property
    def period_label(self) -> str:
        return "week" if self.frequency == "weekly" else "month"

    @property
    def period_col(self) -> str:
        return "YEAR_WEEK" if self.frequency == "weekly" else "YEAR_MONTH"

    @property
    def is_change_mode(self) -> bool:
        return self.target_mode in {
            "monthly_diff", "monthly_pct_change",
            "weekly_diff", "weekly_pct_change",
        }

    @property
    def is_diff_mode(self) -> bool:
        return self.target_mode in {"monthly_diff", "weekly_diff"}

    @property
    def is_pct_mode(self) -> bool:
        return self.target_mode in {"monthly_pct_change", "weekly_pct_change"}


# ==========================================================
# PIPELINE
# ==========================================================

class DataCleaningPipeline:
    """
    Full cleaning + feature-screening pipeline for bond data.

    Output layout
    -------------
    OUTPUT_DIR/
        MASTER_CLEAN.xlsx              ← main cleaned panel
        output_for_latex/
            selected_features.csv
            input_dataset_audit_summary.csv
            input_dataset_column_audit.csv
            input_dataset_top_counts.csv
            latam_rows_by_cntry_of_risk.csv
    """

    LATAM_EX_CARIBBEAN_COUNTRIES: set[str] = {
        "ARGENTINA", "BOLIVIA", "BRAZIL", "CHILE", "COLOMBIA",
        "COSTA RICA", "ECUADOR", "EL SALVADOR", "GUATEMALA", "HONDURAS",
        "MEXICO", "NICARAGUA", "PANAMA", "PARAGUAY", "PERU",
        "URUGUAY", "VENEZUELA",
    }

    LATAM_EX_CARIBBEAN_ISO2: set[str] = {
        "AR", "BO", "BR", "CL", "CO", "CR", "EC", "SV",
        "GT", "HN", "MX", "NI", "PA", "PY", "PE", "UY", "VE",
    }

    ISO2_COUNTRY_FULL_NAMES: dict[str, str] = {
        "AR": "ARGENTINA",  "BO": "BOLIVIA",      "BR": "BRAZIL",
        "CL": "CHILE",      "CO": "COLOMBIA",     "CR": "COSTA RICA",
        "EC": "ECUADOR",    "SV": "EL SALVADOR",  "GT": "GUATEMALA",
        "HN": "HONDURAS",   "MX": "MEXICO",       "NI": "NICARAGUA",
        "PA": "PANAMA",     "PY": "PARAGUAY",     "PE": "PERU",
        "UY": "URUGUAY",    "VE": "VENEZUELA",
    }

    HARD_CURRENCIES: set[str] = {
        "USD", "EUR", "GBP", "JPY", "CHF", "CAD",
        "AUD", "NZD", "SEK", "NOK", "DKK", "SGD", "HKD",
    }

    VALID_TARGET_COLUMNS: set[str] = {"Z_SPREAD_BPS", "Z_SPREAD_MID"}

    COLUMN_ALIASES: dict[str, tuple[str, ...]] = {
        "CURRENCY":     ("CCY", "CRNCY"),
        "PAR_VAL":      ("PAR_VALUE", "PAR_VALUE_REAL", "AMOUNT_OUTSTANDING"),
        "MATURITY_DT":  ("MATURITY", "MATURITY_DATE"),
        "ISSUE_DT":     ("ISSUE_DATE",),
        "CNTRY_OF_RISK":("COUNTRY_FULL_NAME", "COUNTRY", "COUNTRY_OF_RISK"),
    }

    def __init__(self, config: DataCleaningConfig) -> None:
        self.config = config
        self.target_col = config.target_col
        self.frequency  = config.frequency

        self.df: Optional[pd.DataFrame]          = None
        self.X_raw: Optional[pd.DataFrame]       = None
        self.X_screened: Optional[pd.DataFrame]  = None
        self.y: Optional[pd.Series]              = None

        self.numeric_features: list[str]  = []
        self.dummy_features: list[str]    = []
        self.selected_features: list[str] = []

        self.feature_metadata: Optional[pd.DataFrame] = None
        self.corr_table: Optional[pd.DataFrame]       = None
        self.vif_table: Optional[pd.DataFrame]        = None

    # ======================================================
    # PUBLIC RUNNER
    # ======================================================

    def run_all(self, show_plots: bool = True) -> None:
        print("\n" + "=" * 78)
        print("BOND DATA CLEANING + SCREENING PIPELINE")
        print("=" * 78)
        print(f"Frequency        : {self.frequency.upper()}")
        print(f"Target column    : {self.target_col}")
        print(f"Target mode      : {self.config.target_mode}")
        print(f"Target lag       : {self.config.target_lag_periods} {self.config.period_label}(s)")
        print(f"Region filter    : {'LATAM ex-Caribbean' if self.config.latam_ex_caribbean_only else 'All countries'}")
        print(f"Government bonds : {'Excluded' if self.config.exclude_government else 'Included'}")
        print(f"Feature blocks   : Global={self.config.include_global_features}, "
              f"Emerging={self.config.include_emerging_features}, "
              f"Bonds={self.config.include_bond_features}")
        print("=" * 78)

        self._load()
        self._standardize_columns()
        self._materialize_alias_columns()
        self._coerce_dates()
        self._coerce_numerics()
        self._compute_bond_features()
        self._ensure_option_dummies()
        self._ensure_seniority_dummies()
        self._add_country_risk_full_name()

        if self.config.latam_ex_caribbean_only:
            self._filter_latam()
        else:
            self._report_universe()

        if self.config.fixed_coupon_only:
            self._filter_fixed_coupon()

        if self.config.exclude_government:
            self._exclude_government()
        else:
            self._report_government_kept()

        if self.config.drop_option_bonds:
            self._drop_option_bonds()

        self._deduplicate_to_frequency()
        self._validate_target()
        self._build_model_target()
        self._add_time_fe()
        self._add_dummies()
        self._build_X_y()

        if show_plots:
            self._plot_correlation_matrix()

        if self.config.drop_high_corr_features:
            self._screen_corr()
        else:
            self.X_screened = self.X_raw.copy()

        if self.config.drop_high_vif_features:
            self._screen_vif()

        if show_plots:
            self._plot_vif()

        self._export()

        print("\n" + "=" * 78)
        print("PIPELINE COMPLETE")
        print("=" * 78)
        print(f"Rows              : {self.df.shape[0]:,}")
        print(f"Selected features : {len(self.selected_features):,}")
        print(f"Main output       : {self.config.output_dataset}")
        print(f"Feature list      : {self.config.output_features}")
        print("=" * 78)

    # ======================================================
    # STEP 1 — LOAD
    # ======================================================

    def _load(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 1 — LOAD")
        print("-" * 60)

        path   = Path(self.config.data_path)
        suffix = path.suffix.lower()

        if not path.exists():
            raise FileNotFoundError(
                f"Input file not found:\n  {path}\n"
                "Check that MASTER is correctly defined in path_config.py\n"
                "and that the network drive is reachable."
            )

        if suffix in {".xlsx", ".xls"}:
            self.df = read_excel_sheet_safe(
                path, sheet_name=self.config.sheet_name, context="raw input dataset"
            )
        elif suffix == ".csv":
            self.df = pd.read_csv(path)
        elif suffix == ".parquet":
            self.df = pd.read_parquet(path)
        else:
            raise ValueError(
                f"Unsupported file extension: {suffix!r}. "
                "Accepted: .xlsx, .xls, .csv, .parquet"
            )

        print(f"Loaded : {self.df.shape[0]:,} rows x {self.df.shape[1]:,} columns")
        print(f"Source : {path}")

    # ======================================================
    # STEP 2 — STANDARDIZE COLUMNS
    # ======================================================

    def _standardize_columns(self) -> None:
        if self.df is None:
            raise RuntimeError("Dataframe is not loaded.")
        self.df.columns = [str(c).upper().strip() for c in self.df.columns]
        self.df = self.df.loc[:, ~self.df.columns.duplicated()].copy()
        self.df = restrict_dataframe_to_allowed_columns(
            self.df, keep_internal=False, context="raw input"
        )

    def _materialize_alias_columns(self) -> None:
        if self.df is None:
            raise RuntimeError("Dataframe is not loaded.")
        for canonical, aliases in self.COLUMN_ALIASES.items():
            if canonical in self.df.columns:
                continue
            source = next((a for a in aliases if a in self.df.columns), None)
            if source is not None:
                self.df[canonical] = self.df[source]
                print(f"Alias created: {canonical} <- {source}")

    # ======================================================
    # STEP 3 — COERCE DATES
    # ======================================================

    def _coerce_dates(self) -> None:
        for col in ["DATE", "ISSUE_DT", "ISSUE_DATE", "MATURITY",
                    "MATURITY_DT", "MATURITY_DATE", "EFF_START", "EFF_END"]:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors="coerce")

    # ======================================================
    # STEP 4 — COERCE NUMERICS
    # ======================================================

    def _coerce_numerics(self) -> None:
        explicit = [
            "MID_PRICE", "DIRTY_PRICE", "BID_PRICE", "ASK_PRICE",
            "Z_SPREAD_MID", "Z_SPREAD_BPS", "PAR_VALUE", "PAR_VAL", "MV",
            "CPN_FREQ", "COUPON", "AGE_YEARS", "ISSUE_YEAR",
            "OBS_YEAR", "OBS_MONTH", "OBS_WEEK", "MID_PRICE_CALC",
            "BA_SPREAD", "SIZE", "LOG_SIZE", "HARD_CCY",
            "OPTION_CALLABLE", "OPTION_PUTABLE", "OPTION_SINKABLE",
            "SENIORITY_SR_UNSECURED", "SENIORITY_SUBORDINATED",
            "SENIORITY_1ST_LIEN", "SENIORITY_2ND_LIEN",
            "SENIORITY_SECURED", "SENIORITY_UNSECURED",
            "LATAM_CDS_CREDIT_RISK", "LATAM_JPM_SPREAD_CREDIT_RISK",
        ]
        for col in explicit + [c for c in self.df.columns if c.startswith("MA3_")]:
            if col in self.df.columns:
                self.df[col] = pd.to_numeric(self.df[col], errors="coerce")

    # ======================================================
    # STEP 5 — BOND FEATURES
    # ======================================================

    def _compute_bond_features(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 5 — COMPUTE BOND FEATURES")
        print("-" * 60)

        df      = self.df
        mat_col = self._first_col(["MATURITY_DT", "MATURITY", "MATURITY_DATE"])

        if "DATE" in df.columns and mat_col and "TTM" not in df.columns:
            df["TTM"] = ((df[mat_col] - df["DATE"]).dt.days / 365.25).clip(lower=0)
            print("Created: TTM")

        if "DATE" in df.columns and "ISSUE_DT" in df.columns and "AGE_YEARS" not in df.columns:
            df["AGE_YEARS"] = ((df["DATE"] - df["ISSUE_DT"]).dt.days / 365.25).clip(lower=0)
            print("Created: AGE_YEARS")

        if "ISSUE_DT" in df.columns and "ISSUE_YEAR" not in df.columns:
            df["ISSUE_YEAR"] = df["ISSUE_DT"].dt.year
            print("Created: ISSUE_YEAR")

        if "DATE" in df.columns:
            for col, fn in [
                ("OBS_YEAR",  lambda s: s.dt.year),
                ("OBS_MONTH", lambda s: s.dt.month),
                ("OBS_WEEK",  lambda s: s.dt.isocalendar().week.astype(int)),
            ]:
                if col not in df.columns:
                    df[col] = fn(df["DATE"])
                    print(f"Created: {col}")

        if "BID_PRICE" in df.columns and "ASK_PRICE" in df.columns and "BA_SPREAD" not in df.columns:
            mid = 0.5 * (df["BID_PRICE"] + df["ASK_PRICE"])
            df["BA_SPREAD"] = ((df["ASK_PRICE"] - df["BID_PRICE"]) / mid).where(mid > 0)
            print("Created: BA_SPREAD")

        if "SIZE" not in df.columns:
            size_col = self._first_col(["PAR_VAL", "PAR_VALUE", "MV"])
            if size_col:
                df["SIZE"] = pd.to_numeric(df[size_col], errors="coerce")
                print(f"Created: SIZE from {size_col}")

        if "LOG_SIZE" not in df.columns and "SIZE" in df.columns:
            df["LOG_SIZE"] = np.log1p(df["SIZE"].clip(lower=0))
            print("Created: LOG_SIZE")

        if "HARD_CCY" not in df.columns:
            ccy_col = self._first_col(["CURRENCY", "CCY"])
            if ccy_col:
                df["HARD_CCY"] = (
                    df[ccy_col].astype(str).str.upper().str.strip()
                    .isin(self.HARD_CURRENCIES).astype(int)
                )
                print("Created: HARD_CCY")

        self.df = df
        print("Bond feature computation done.")

    def _ensure_option_dummies(self) -> None:
        for raw_col, dummy_col in [
            ("CALLABLE", "OPTION_CALLABLE"),
            ("PUTABLE",  "OPTION_PUTABLE"),
            ("SINKABLE", "OPTION_SINKABLE"),
        ]:
            if dummy_col in self.df.columns:
                self.df[dummy_col] = (
                    pd.to_numeric(self.df[dummy_col], errors="coerce").fillna(0).astype(int)
                )
                continue
            if raw_col in self.df.columns:
                self.df[dummy_col] = self._norm_yes_no(self.df[raw_col]).eq("Y").astype(int)
                print(f"Created: {dummy_col} from {raw_col}")

    def _ensure_seniority_dummies(self) -> None:
        required = [
            "SENIORITY_SR_UNSECURED", "SENIORITY_SUBORDINATED",
            "SENIORITY_1ST_LIEN", "SENIORITY_2ND_LIEN",
            "SENIORITY_SECURED", "SENIORITY_UNSECURED",
        ]
        if all(c in self.df.columns for c in required):
            for col in required:
                self.df[col] = pd.to_numeric(self.df[col], errors="coerce").fillna(0).astype(int)
            return

        rank = (
            self.df["PAYMENT_RANK"].apply(self._norm_text)
            if "PAYMENT_RANK" in self.df.columns
            else pd.Series("", index=self.df.index)
        )
        first_lien  = rank.str.contains("1ST LIEN",   regex=False) | rank.str.contains("FIRST LIEN",  regex=False)
        second_lien = rank.str.contains("2ND LIEN",   regex=False) | rank.str.contains("SECOND LIEN", regex=False)

        self.df["SENIORITY_SR_UNSECURED"] = (
            rank.str.contains("SR UNSECURED",     regex=False)
            | rank.str.contains("SENIOR UNSECURED", regex=False)
        ).astype(int)
        self.df["SENIORITY_SUBORDINATED"] = rank.str.contains("SUBORD",   regex=False).astype(int)
        self.df["SENIORITY_1ST_LIEN"]     = first_lien.astype(int)
        self.df["SENIORITY_2ND_LIEN"]     = second_lien.astype(int)
        self.df["SENIORITY_SECURED"]      = (rank.str.contains("SECURED", regex=False) | first_lien | second_lien).astype(int)
        self.df["SENIORITY_UNSECURED"]    = rank.str.contains("UNSECURED", regex=False).astype(int)
        print("Created seniority dummies from PAYMENT_RANK.")

    def _add_country_risk_full_name(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 5b — COUNTRY RISK FULL NAME")
        print("-" * 60)

        risk_col = self._resolve_column("CNTRY_OF_RISK")
        if risk_col is None:
            print("CNTRY_OF_RISK not found. Skipped.")
            return

        raw = self.df[risk_col].astype(str).str.upper().str.strip()
        raw = raw.replace({"NAN": "", "NONE": "", "NULL": ""})

        self.df["CNTRY_OF_RISK_FULL_NAME"] = (
            raw.map(self.ISO2_COUNTRY_FULL_NAMES)
            .fillna(raw.apply(self._norm_country))
            .replace("", "UNKNOWN")
        )
        print(f"Created: CNTRY_OF_RISK_FULL_NAME from {risk_col}")
        counts = (
            self.df[["CNTRY_OF_RISK", "CNTRY_OF_RISK_FULL_NAME"]]
            .drop_duplicates()
            .sort_values(["CNTRY_OF_RISK", "CNTRY_OF_RISK_FULL_NAME"])
        )
        print("\nCountry-risk code mapping:")
        print(counts.to_string(index=False))

    # ======================================================
    # STEP 6 — FILTERS
    # ======================================================

    def _report_universe(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 6a — UNIVERSE REPORT")
        print("-" * 60)
        risk_col = (
            "CNTRY_OF_RISK"
            if "CNTRY_OF_RISK" in self.df.columns
            else self._first_col(["COUNTRY_FULL_NAME", "COUNTRY"])
        )
        if risk_col is None:
            print("No country column found. Skipped.")
            return
        counts = self.df[risk_col].astype(str).str.upper().str.strip().value_counts().sort_index()
        print(f"Full universe: {len(self.df):,} rows across {len(counts):,} country-risk values.")
        for country, n_obs in counts.items():
            print(f"  {country}: {n_obs:,}")

    def _filter_latam(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 6a — LATAM EX-CARIBBEAN FILTER")
        print("-" * 60)

        risk_col = "CNTRY_OF_RISK"
        if risk_col not in self.df.columns:
            raise KeyError("LATAM filtering requires CNTRY_OF_RISK.")

        before       = len(self.df)
        country_raw  = self.df[risk_col].astype(str).str.upper().str.strip().replace({"NAN": "", "NONE": "", "NULL": ""})
        country_eff  = country_raw.map(self.ISO2_COUNTRY_FULL_NAMES).fillna(country_raw.apply(self._norm_country))
        mask         = country_raw.isin(self.LATAM_EX_CARIBBEAN_ISO2) | country_eff.isin(self.LATAM_EX_CARIBBEAN_COUNTRIES)

        self.df      = self.df.loc[mask].copy()
        print(f"LATAM filter ({risk_col}): {before:,} -> {len(self.df):,} rows")

        counts = self.df[risk_col].astype(str).str.upper().str.strip().value_counts().sort_index()
        for country, n in counts.items():
            name = self.ISO2_COUNTRY_FULL_NAMES.get(str(country).upper(), "")
            print(f"  {country}{f' ({name})' if name else ''}: {n:,}")

    def _filter_fixed_coupon(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 6b — FIXED COUPON FILTER")
        print("-" * 60)
        if "CPN_TYP" not in self.df.columns:
            print("CPN_TYP not found. Skipped.")
            return
        before   = len(self.df)
        self.df  = self.df.loc[self.df["CPN_TYP"].astype(str).str.upper().str.strip().eq("FIXED")].copy()
        print(f"Fixed coupon filter: {before:,} -> {len(self.df):,} rows")

    def _exclude_government(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 6c — GOVERNMENT EXCLUSION")
        print("-" * 60)
        sector_cols = [c for c in ["INDUSTRY_SECTOR", "SECTOR_LEVEL_2", "MERRILL_SECTOR_3", "SECTOR"] if c in self.df.columns]
        if not sector_cols:
            print("No sector column found. Skipped.")
            return
        mask = pd.Series(False, index=self.df.index)
        for col in sector_cols:
            mask |= self.df[col].astype(str).str.upper().str.strip().eq("GOVERNMENT")
        before   = len(self.df)
        n_gov    = int(mask.sum())
        self.df  = self.df.loc[~mask].copy()
        print(f"Government exclusion: {before:,} -> {len(self.df):,} rows ({n_gov:,} removed)")

    def _report_government_kept(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 6c — GOVERNMENT INCLUDED")
        print("-" * 60)
        sector_cols = [c for c in ["INDUSTRY_SECTOR", "SECTOR_LEVEL_2", "MERRILL_SECTOR_3", "SECTOR"] if c in self.df.columns]
        if not sector_cols:
            print("No sector column found. Skipped.")
            return
        mask  = pd.Series(False, index=self.df.index)
        for col in sector_cols:
            mask |= self.df[col].astype(str).str.upper().str.strip().eq("GOVERNMENT")
        n_gov = int(mask.sum())
        print(f"Government bonds kept: {n_gov:,} rows ({100.0 * n_gov / max(len(self.df), 1):.1f}%).")

    def _drop_option_bonds(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 6d — OPTION BOND EXCLUSION")
        print("-" * 60)
        option_cols       = [c for c in ["CALLABLE", "PUTABLE", "SINKABLE"]                        if c in self.df.columns]
        option_dummy_cols = [c for c in ["OPTION_CALLABLE", "OPTION_PUTABLE", "OPTION_SINKABLE"]   if c in self.df.columns]
        if not option_cols and not option_dummy_cols:
            print("No option columns found. Skipped.")
            return
        mask = pd.Series(False, index=self.df.index)
        for col in option_cols:
            mask |= self._norm_yes_no(self.df[col]).eq("Y")
        for col in option_dummy_cols:
            mask |= pd.to_numeric(self.df[col], errors="coerce").fillna(0).eq(1)
        before   = len(self.df)
        n_opt    = int(mask.sum())
        self.df  = self.df.loc[~mask].copy()
        print(f"Option bond exclusion: {before:,} -> {len(self.df):,} rows ({n_opt:,} removed)")

    # ======================================================
    # STEP 7 — TEMPORAL DEDUPLICATION
    # ======================================================

    def _deduplicate_to_frequency(self) -> None:
        print("\n" + "-" * 60)
        print(f"STEP 7 — TEMPORAL DEDUPLICATION [{self.frequency.upper()}]")
        print("-" * 60)
        if "DATE" not in self.df.columns or "ISIN" not in self.df.columns:
            print("DATE or ISIN missing. Skipped.")
            return

        before     = len(self.df)
        period_col = self.config.period_col

        if self.frequency == "weekly":
            iso = self.df["DATE"].dt.isocalendar()
            self.df["YEAR_WEEK"] = (
                iso["year"].astype(str) + "-W" + iso["week"].astype(str).str.zfill(2)
            )
        else:
            self.df["YEAR_MONTH"] = self.df["DATE"].dt.to_period("M").astype(str)

        self.df = (
            self.df.sort_values(["ISIN", "DATE"])
            .groupby(["ISIN", period_col], as_index=False)
            .tail(1)
            .sort_values(["ISIN", "DATE"])
            .reset_index(drop=True)
        )

        after     = len(self.df)
        n_periods = self.df[period_col].nunique()
        n_isins   = self.df["ISIN"].nunique()
        coverage  = 100.0 * after / max(n_isins * n_periods, 1)

        print(f"Deduplicated : {before:,} -> {after:,} rows")
        print(f"ISINs        : {n_isins:,}")
        print(f"Periods      : {n_periods:,} ({period_col})")
        print(f"Coverage     : {coverage:.1f}% of ISIN × period cells")

    # ======================================================
    # STEP 8 — TARGET VALIDATION
    # ======================================================

    def _validate_target(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 8 — TARGET VALIDATION")
        print("-" * 60)
        if self.target_col not in self.df.columns:
            raise KeyError(
                f"Target column {self.target_col!r} not found.\n"
                f"Available: {self.df.columns.tolist()}"
            )
        self.df[self.target_col] = pd.to_numeric(self.df[self.target_col], errors="coerce")
        n_valid   = int(self.df[self.target_col].notna().sum())
        pct_valid = 100.0 * n_valid / max(len(self.df), 1)
        print(f"{self.target_col}: {n_valid:,} non-null rows ({pct_valid:.1f}%).")

        other = "Z_SPREAD_MID" if self.target_col == "Z_SPREAD_BPS" else "Z_SPREAD_BPS"
        if other in self.df.columns:
            n_other = int(pd.to_numeric(self.df[other], errors="coerce").notna().sum())
            print(f"{other}: {n_other:,} non-null rows ({100.0 * n_other / max(len(self.df),1):.1f}%).")

    # ======================================================
    # STEP 9 — MODEL TARGET
    # ======================================================

    def _build_model_target(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 9 — MODEL TARGET")
        print("-" * 60)

        self.df["MODEL_TARGET_LEVEL"] = self.df[self.target_col]

        if self.config.target_mode == "level":
            self.df["MODEL_TARGET"] = self.df[self.target_col]
            print(f"MODEL_TARGET = {self.target_col}")

        elif self.config.is_change_mode:
            missing = [c for c in ["DATE", "ISIN", self.target_col] if c not in self.df.columns]
            if missing:
                raise KeyError(f"Missing columns for target_mode={self.config.target_mode!r}: {missing}")

            self.df = self.df.dropna(subset=["DATE", "ISIN", self.target_col]).copy()
            self.df = self.df.sort_values(["ISIN", "DATE"]).reset_index(drop=True)
            self.df["TARGET_LAG"] = (
                self.df.groupby("ISIN", sort=False)[self.target_col]
                .shift(self.config.target_lag_periods)
            )

            if self.config.is_diff_mode:
                self.df["MODEL_TARGET"] = self.df[self.target_col] - self.df["TARGET_LAG"]
                print(f"MODEL_TARGET = {self.target_col} - TARGET_LAG (lag={self.config.target_lag_periods})")
            elif self.config.is_pct_mode:
                self.df["MODEL_TARGET"] = (
                    (self.df[self.target_col] / self.df["TARGET_LAG"]) - 1.0
                ).where(self.df["TARGET_LAG"] != 0)
                print(f"MODEL_TARGET = pct_change({self.target_col}) (lag={self.config.target_lag_periods})")
        else:
            raise ValueError(f"Unsupported target mode: {self.config.target_mode!r}")

        before   = len(self.df)
        self.df  = self.df.dropna(subset=["MODEL_TARGET"]).copy()
        after    = len(self.df)
        print(f"Drop missing MODEL_TARGET: {before:,} -> {after:,} rows")

        if self.df.empty:
            raise ValueError("No rows left after target construction.")

        t = self.df["MODEL_TARGET"]
        print(f"Target mean/std/abs : {t.mean():.6f} / {t.std():.6f} / {t.abs().mean():.6f}")
        print(f"Target min/max      : {t.min():.6f} / {t.max():.6f}")

    # ======================================================
    # STEP 10 — TIME FIXED EFFECTS
    # ======================================================

    def _add_time_fe(self) -> None:
        mode = self.config.time_fixed_effect
        if mode == "none":
            return
        if "DATE" not in self.df.columns:
            print("DATE missing. Time fixed effects skipped.")
            return

        self.df["DATE"] = pd.to_datetime(self.df["DATE"], errors="coerce")

        if   mode == "year":       self.df["TIME_FE"] = self.df["DATE"].dt.year.astype("Int64").astype(str)
        elif mode == "month":      self.df["TIME_FE"] = self.df["DATE"].dt.month.astype("Int64").astype(str)
        elif mode == "year_month": self.df["TIME_FE"] = self.df["DATE"].dt.to_period("M").astype(str)
        elif mode == "week":
            iso = self.df["DATE"].dt.isocalendar()
            self.df["TIME_FE"] = iso["year"].astype(str) + "-W" + iso["week"].astype(str).str.zfill(2)
        else:
            raise ValueError(f"Unsupported time_fixed_effect: {mode!r}")

        dummies  = pd.get_dummies(self.df["TIME_FE"].fillna("UNKNOWN"), prefix="TIME_FE", drop_first=True, dtype=int)
        self.df  = pd.concat([self.df, dummies], axis=1)
        self.df  = self.df.loc[:, ~self.df.columns.duplicated()].copy()
        print(f"Added time fixed effects: {mode}")

    # ======================================================
    # STEP 11 — CATEGORICAL DUMMIES
    # ======================================================

    def _add_dummies(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 10 — CATEGORICAL DUMMIES")
        print("-" * 60)
        for requested_col in self.config.dummy_columns:
            canonical = requested_col.upper().strip()
            source    = self._resolve_column(canonical)
            if source is None:
                print(f"Dummy source not found: {canonical}")
                continue
            cat        = self._clean_cat(self.df[source])
            top_levels = cat.value_counts(dropna=False).head(self.config.max_dummy_levels).index
            cat        = cat.where(cat.isin(top_levels), "OTHER")
            dummies    = pd.get_dummies(cat, prefix=canonical, drop_first=True, dtype=int)
            self.df    = pd.concat([self.df, dummies], axis=1)
            print(f"Added dummies for {canonical} from {source}: {dummies.shape[1]:,} columns")
        self.df = self.df.loc[:, ~self.df.columns.duplicated()].copy()

    # ======================================================
    # STEP 12 — BUILD X / y
    # ======================================================

    def _build_X_y(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 11 — BUILD FEATURE MATRIX")
        print("-" * 60)

        df       = self.df
        excluded = {self.target_col, "Z_SPREAD_BPS", "Z_SPREAD_MID", "MODEL_TARGET", "TARGET_LAG"}

        if not self.config.include_yield_price_features:
            excluded |= {"MID_PRICE", "DIRTY_PRICE", "BID_PRICE", "ASK_PRICE", "MID_PRICE_CALC"}

        candidate_cols = self._candidate_feature_columns(df=df, excluded=excluded)
        feature_cols: list[str] = []

        for col in candidate_cols:
            group = FeatureTaxonomy.classify(col)
            if group == FeatureTaxonomy.GLOBAL   and not self.config.include_global_features:   continue
            if group == FeatureTaxonomy.EMERGING  and not self.config.include_emerging_features: continue
            if group == FeatureTaxonomy.BONDS     and not self.config.include_bond_features:     continue
            if pd.api.types.is_numeric_dtype(df[col]):
                feature_cols.append(col)

        feature_cols = list(dict.fromkeys(feature_cols))
        if not feature_cols:
            raise ValueError("No usable numeric features found after feature-block filtering.")

        X              = df[feature_cols].copy().apply(pd.to_numeric, errors="coerce")
        dummy_features = [c for c in X.columns if self._is_dummy(c)]
        num_features   = [c for c in X.columns if c not in dummy_features]

        for col in dummy_features:
            X[col] = X[col].fillna(0).astype(float)
        for col in num_features:
            s = pd.to_numeric(X[col], errors="coerce")
            X[col] = s.fillna(s.median()).astype(float) if s.notna().any() else 0.0

        const_cols = [c for c in X.columns if X[c].nunique(dropna=False) <= 1]
        if const_cols:
            X = X.drop(columns=const_cols)
            print(f"Dropped {len(const_cols):,} constant feature(s).")

        y     = pd.to_numeric(df["MODEL_TARGET"], errors="coerce")
        valid = y.notna() & X.notna().all(axis=1)

        self.X_raw          = X.loc[valid].copy()
        self.y              = y.loc[valid].copy()
        self.df             = df.loc[valid].copy()
        self.numeric_features = [c for c in num_features   if c in self.X_raw.columns]
        self.dummy_features   = [c for c in dummy_features if c in self.X_raw.columns]
        self.feature_metadata = self._make_feature_metadata(self.X_raw.columns.tolist())

        counts = self.feature_metadata["FEATURE_TYPE"].value_counts().to_dict()
        print(f"Feature matrix : {self.X_raw.shape[0]:,} rows x {self.X_raw.shape[1]:,} features")
        print(f"  Numeric      : {len(self.numeric_features):,}")
        print(f"  Dummies      : {len(self.dummy_features):,}")
        print(f"  Global       : {counts.get(FeatureTaxonomy.GLOBAL, 0):,}")
        print(f"  Emerging     : {counts.get(FeatureTaxonomy.EMERGING, 0):,}")
        print(f"  Bonds        : {counts.get(FeatureTaxonomy.BONDS, 0):,}")

    def _candidate_feature_columns(self, df: pd.DataFrame, excluded: set[str]) -> list[str]:
        explicit = (
            FeatureTaxonomy.GLOBAL_FEATURES
            | FeatureTaxonomy.EMERGING_FEATURES
            | FeatureTaxonomy.BOND_FEATURES
        )
        computed_bond = {
            "COUPON", "CPN_FREQ", "PAR_VALUE", "AGE_YEARS", "ISSUE_YEAR",
            "BA_SPREAD", "HARD_CCY",
            "OPTION_CALLABLE", "OPTION_PUTABLE", "OPTION_SINKABLE",
            "SENIORITY_SR_UNSECURED", "SENIORITY_SUBORDINATED",
            "SENIORITY_1ST_LIEN", "SENIORITY_2ND_LIEN",
            "SENIORITY_SECURED", "SENIORITY_UNSECURED",
        }
        time_features = {"OBS_YEAR", "OBS_MONTH", "OBS_WEEK"}
        all_candidates: list[str] = []
        for col in df.columns:
            name = col.upper().strip()
            if name in excluded:                         continue
            if not is_allowed_model_input_feature(name): continue
            if name in explicit:                         all_candidates.append(col); continue
            if name in computed_bond:                    all_candidates.append(col); continue
            if name in time_features:                    all_candidates.append(col); continue
            if name.startswith("MA3_"):                  all_candidates.append(col); continue
            if self._is_dummy(name):                     all_candidates.append(col); continue
        return list(dict.fromkeys(all_candidates))

    # ======================================================
    # STEP 13 — CORRELATION SCREEN
    # ======================================================

    def _screen_corr(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 12 — CORRELATION SCREEN")
        print("-" * 60)
        if self.X_raw is None or self.y is None:
            raise RuntimeError("Feature matrix not built.")
        X = self.X_raw.copy()
        y = self.y.copy()
        if X.shape[1] < 2:
            self.X_screened = X
            return

        corr         = X.corr().replace([np.inf, -np.inf], np.nan).fillna(0.0)
        self.corr_table = corr.copy()
        upper        = corr.abs().where(np.triu(np.ones(corr.shape), k=1).astype(bool))
        target_corr  = X.corrwith(y).abs().replace([np.inf, -np.inf], np.nan).fillna(0.0)
        to_drop: set[str] = set()

        for col in upper.columns:
            for row in upper.index[upper[col] >= self.config.corr_threshold].tolist():
                if row in to_drop or col in to_drop:
                    continue
                if float(target_corr.get(row, 0.0)) >= float(target_corr.get(col, 0.0)):
                    to_drop.add(col)
                else:
                    to_drop.add(row)

        if to_drop:
            print(f"Dropped {len(to_drop):,} high-correlation feature(s):")
            for f in sorted(to_drop):
                print(f"  {f}")
            X = X.drop(columns=list(to_drop), errors="ignore")
        else:
            print("No features dropped by correlation screen.")

        self.X_screened = X
        print(f"Features remaining: {X.shape[1]:,}")

    # ======================================================
    # STEP 14 — VIF SCREEN
    # ======================================================

    def _screen_vif(self) -> None:
        print("\n" + "-" * 60)
        print("STEP 13 — VIF SCREEN")
        print("-" * 60)
        X = (self.X_screened if self.X_screened is not None else self.X_raw).copy()
        y = self.y.copy()
        if X.shape[1] < 2:
            self.X_screened = X
            return

        if X.shape[1] > self.config.max_vif_features:
            target_corr = X.corrwith(y).abs().replace([np.inf, -np.inf], np.nan).fillna(0.0).sort_values(ascending=False)
            keep        = target_corr.head(self.config.max_vif_features).index.tolist()
            n_removed   = X.shape[1] - len(keep)
            X           = X[keep].copy()
            print(f"Capped to top {self.config.max_vif_features:,} features ({n_removed:,} removed before VIF loop).")

        iteration = 0
        while X.shape[1] >= 2:
            iteration += 1
            vif_df     = self._compute_vif(X)
            self.vif_table = vif_df.copy()
            max_vif    = float(vif_df["VIF"].max())
            if max_vif <= self.config.vif_threshold:
                print(f"All VIFs <= {self.config.vif_threshold:.2f}. Done after {iteration-1:,} drop(s).")
                break
            worst = str(vif_df.iloc[0]["Feature"])
            print(f"[iter {iteration}] Drop {worst} | VIF = {float(vif_df.iloc[0]['VIF']):.2f}")
            X = X.drop(columns=[worst])

        self.vif_table  = self._compute_vif(X)
        self.X_screened = X
        print(f"Features remaining after VIF screen: {X.shape[1]:,}")

    def _compute_vif(self, X: pd.DataFrame) -> pd.DataFrame:
        if X.shape[1] < 2:
            return pd.DataFrame(columns=["Feature", "VIF"])
        X_clean = X.replace([np.inf, -np.inf], np.nan).fillna(0.0).astype(float)
        X_clean = X_clean[[c for c in X_clean.columns if X_clean[c].nunique(dropna=False) > 1]]
        if X_clean.shape[1] < 2:
            return pd.DataFrame(columns=["Feature", "VIF"])
        arr     = StandardScaler().fit_transform(X_clean)
        records = []
        for i, col in enumerate(X_clean.columns):
            try:
                vif_val = variance_inflation_factor(arr, i)
            except Exception:
                vif_val = np.inf
            records.append({"Feature": col, "VIF": float(vif_val), "FEATURE_TYPE": FeatureTaxonomy.classify(col)})
        return (
            pd.DataFrame(records)
            .replace([np.inf, -np.inf], np.nan)
            .fillna({"VIF": np.inf})
            .sort_values("VIF", ascending=False)
            .reset_index(drop=True)
        )

    # ======================================================
    # PLOTS
    # ======================================================

    def _plot_correlation_matrix(self) -> None:
        if self.X_raw is None or self.y is None:
            return
        non_dummy = [c for c in self.X_raw.columns if not self._is_dummy(c)]
        if not non_dummy:
            return
        df_corr = self.X_raw[non_dummy].copy()
        df_corr["MODEL_TARGET"] = self.y
        keep = (
            df_corr.corr()["MODEL_TARGET"].abs()
            .sort_values(ascending=False)
            .head(self.config.max_corr_features)
            .index.tolist()
        )
        corr = df_corr[keep].corr()
        fig  = px.imshow(
            corr, color_continuous_scale="RdBu_r", zmin=-1, zmax=1, text_auto=".2f",
            title=f"Correlation Matrix — Top {len(keep)} features [{self.frequency.upper()} | {self.config.target_mode}]",
        )
        fig.update_layout(template="plotly_white", width=1200, height=max(650, len(keep) * 25))
        fig.show()

    def _plot_vif(self) -> None:
        if self.vif_table is None or self.vif_table.empty:
            return
        df_plot = self.vif_table.sort_values("VIF", ascending=True)
        fig = px.bar(
            df_plot, x="VIF", y="Feature",
            color="FEATURE_TYPE" if "FEATURE_TYPE" in df_plot.columns else None,
            orientation="h",
            title=f"VIF Diagnostics — threshold={self.config.vif_threshold} [{self.frequency.upper()}]",
            template="plotly_white",
        )
        fig.add_vline(x=self.config.vif_threshold, line_dash="dash", line_color="red",
                      annotation_text=f"VIF = {self.config.vif_threshold}")
        fig.update_layout(width=1100, height=max(500, len(df_plot) * 22), yaxis_title="")
        fig.show()

    # ======================================================
    # EXPORT
    # ======================================================

    def _export(self) -> None:
        print("\n" + "-" * 60)
        print("EXPORT")
        print("-" * 60)

        X_final               = (self.X_screened if self.X_screened is not None else self.X_raw).copy()
        self.selected_features = X_final.columns.tolist()
        self.feature_metadata  = self._make_feature_metadata(self.selected_features)

        feature_set = set(self.selected_features)
        base_cols   = [c for c in self.df.columns if c not in feature_set]
        df_export   = pd.concat([self.df[base_cols].copy(), X_final.copy()], axis=1)

        # ── 1. MASTER_CLEAN.xlsx → directly in OUTPUT_DIR ─────────────────────
        out_data = Path(self.config.output_dataset)
        out_data.parent.mkdir(parents=True, exist_ok=True)

        suffix = out_data.suffix.lower()
        if suffix in {".xlsx", ".xls"}:
            df_export.to_excel(out_data, index=False)
        elif suffix == ".csv":
            df_export.to_csv(out_data, index=False)
        elif suffix == ".parquet":
            df_export.to_parquet(out_data, index=False)
        else:
            df_export.to_excel(out_data, index=False)

        print(f"MASTER_CLEAN saved  : {out_data}")
        print(f"  {df_export.shape[0]:,} rows x {df_export.shape[1]:,} columns")

        # ── 2. selected_features.csv → output_for_latex/ ──────────────────────
        out_features = Path(self.config.output_features)
        out_features.parent.mkdir(parents=True, exist_ok=True)

        self.feature_metadata.to_csv(out_features, index=False)
        print(f"Selected features   : {out_features}")
        print(f"  {len(self.selected_features):,} features")
        print("\nFeature block counts:")
        print(self.feature_metadata["FEATURE_TYPE"].value_counts().to_string())

    def _make_feature_metadata(self, features: list[str]) -> pd.DataFrame:
        records = []
        for feature in features:
            ft = FeatureTaxonomy.classify(feature)
            records.append({
                "FEATURE":     feature,
                "FEATURE_TYPE": ft,
                "IS_GLOBAL":   int(ft == FeatureTaxonomy.GLOBAL),
                "IS_EMERGING": int(ft == FeatureTaxonomy.EMERGING),
                "IS_BONDS":    int(ft == FeatureTaxonomy.BONDS),
                "IS_DUMMY":    int(self._is_dummy(feature)),
            })
        return pd.DataFrame(records)

    # ======================================================
    # HELPERS
    # ======================================================

    def _first_col(self, candidates: list[str]) -> Optional[str]:
        return next((c for c in candidates if c in self.df.columns), None)

    def _resolve_column(self, requested: str) -> Optional[str]:
        requested = requested.upper().strip()
        if requested in self.df.columns:
            return requested
        for alias in self.COLUMN_ALIASES.get(requested, ()):
            if alias in self.df.columns:
                return alias
        return None

    def _is_dummy(self, feature: str) -> bool:
        name = str(feature).upper().strip()
        dummy_prefixes = tuple(
            [c.upper().strip() + "_" for c in self.config.dummy_columns]
            + ["CCY_", "COUNTRY_", "COUNTRY_FULL_NAME_", "TIME_FE_",
               "SECTOR_LEVEL_2_", "MERRILL_SECTOR_3_", "SENIORITY_", "OPTION_"]
        )
        return name.startswith(dummy_prefixes)

    @staticmethod
    def _clean_cat(series: pd.Series) -> pd.Series:
        out = series.astype(str).str.upper().str.strip()
        out = out.replace({"NAN": "UNKNOWN", "NONE": "UNKNOWN", "NULL": "UNKNOWN", "": "UNKNOWN"})
        out = out.str.replace(r"\s+", " ", regex=True).str.replace("/", "_").str.replace("-", "_")
        return out

    @staticmethod
    def _norm_country(value: object) -> str:
        if pd.isna(value):
            return ""
        text    = str(value).upper().strip()
        text    = re.sub(r"[._\-/]", " ", text)
        text    = re.sub(r"\s+", " ", text).strip()
        aliases = {
            "ARGENTINA": "ARGENTINA", "BRAZIL": "BRAZIL", "BRASIL": "BRAZIL",
            "CHILE": "CHILE", "COLOMBIA": "COLOMBIA", "COSTA RICA": "COSTA RICA",
            "EL SALVADOR": "EL SALVADOR", "GUATEMALA": "GUATEMALA",
            "MEXICO": "MEXICO", "PANAMA": "PANAMA", "PERU": "PERU",
            "VENEZUELA": "VENEZUELA", "BOLIVIA": "BOLIVIA", "ECUADOR": "ECUADOR",
            "HONDURAS": "HONDURAS", "NICARAGUA": "NICARAGUA",
            "PARAGUAY": "PARAGUAY", "URUGUAY": "URUGUAY",
        }
        return aliases.get(text, text)

    @staticmethod
    def _norm_text(value: object) -> str:
        if pd.isna(value):
            return ""
        text = str(value).upper().strip()
        text = re.sub(r"[_\-/]", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    @staticmethod
    def _norm_yes_no(series: pd.Series) -> pd.Series:
        mapping = {
            "YES": "Y", "TRUE": "Y", "1": "Y", "Y": "Y",
            "NO": "N", "FALSE": "N", "0": "N", "N": "N",
            "NAN": "N", "NONE": "N", "NULL": "N", "": "N",
        }
        return series.astype(str).str.upper().str.strip().map(mapping).fillna("N")


# ==========================================================
# Audit helper
# ==========================================================

def audit_input_dataset(
    data_path: str | Path,
    sheet_name: int | str = 0,
    output_dir: str | Path = ".",
) -> dict:
    """
    Compact audit of the master input file.
    All CSV outputs are written to output_dir (output_for_latex/).
    """
    path       = Path(data_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not path.exists():
        raise FileNotFoundError(f"Input master dataset not found: {path}")

    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        df = read_excel_sheet_safe(path, sheet_name=sheet_name, context="input dataset audit")
    elif suffix == ".csv":
        df = pd.read_csv(path)
    elif suffix == ".parquet":
        df = pd.read_parquet(path)
    else:
        raise ValueError(f"Unsupported extension: {suffix!r}")

    df.columns = [str(c).upper().strip() for c in df.columns]
    df         = df.loc[:, ~df.columns.duplicated()].copy()

    allowed       = set(ALLOWED_RAW_COLUMNS)
    present       = [c for c in ALLOWED_RAW_COLUMNS if c in df.columns]
    missing       = [c for c in ALLOWED_RAW_COLUMNS if c not in df.columns]
    extra         = [c for c in df.columns if c not in allowed]
    date_min      = pd.to_datetime(df["DATE"], errors="coerce").min() if "DATE" in df.columns else pd.NaT
    date_max      = pd.to_datetime(df["DATE"], errors="coerce").max() if "DATE" in df.columns else pd.NaT

    latam_iso2    = DataCleaningPipeline.LATAM_EX_CARIBBEAN_ISO2
    latam_names   = DataCleaningPipeline.LATAM_EX_CARIBBEAN_COUNTRIES

    def _latam_count(col: str) -> Optional[int]:
        if col not in df.columns:
            return None
        raw  = df[col].astype(str).str.upper().str.strip().replace({"NAN": "", "NONE": "", "NULL": ""})
        norm = raw.apply(DataCleaningPipeline._norm_country)
        return int((raw.isin(latam_iso2) | norm.isin(latam_names)).sum())

    summary = {
        "Input file":                    str(path),
        "Sheet":                         str(sheet_name),
        "Rows":                          int(len(df)),
        "Columns":                       int(len(df.columns)),
        "Allowed columns present":       int(len(present)),
        "Allowed columns missing":       int(len(missing)),
        "Extra columns outside whitelist": int(len(extra)),
        "Unique ISINs":                  int(df["ISIN"].nunique()) if "ISIN" in df.columns else None,
        "Date min":                      str(date_min.date()) if pd.notna(date_min) else None,
        "Date max":                      str(date_max.date()) if pd.notna(date_max) else None,
        "LATAM rows by CNTRY_OF_RISK":   _latam_count("CNTRY_OF_RISK"),
        "LATAM rows by COUNTRY_FULL_NAME": _latam_count("COUNTRY_FULL_NAME"),
        "LATAM rows by COUNTRY":         _latam_count("COUNTRY"),
        "Z_SPREAD_MID non-null": int(df["Z_SPREAD_MID"].notna().sum()) if "Z_SPREAD_MID" in df.columns else None,
        "Z_SPREAD_BPS non-null": int(df["Z_SPREAD_BPS"].notna().sum()) if "Z_SPREAD_BPS" in df.columns else None,
    }

    pd.DataFrame([{"Metric": k, "Value": v} for k, v in summary.items()]).to_csv(
        output_dir / "input_dataset_audit_summary.csv", index=False
    )
    pd.DataFrame({
        "Column": sorted(allowed | set(df.columns)),
    }).assign(
        In_MASTER=lambda d: d["Column"].isin(df.columns),
        In_allowed_whitelist=lambda d: d["Column"].isin(allowed),
    ).to_csv(output_dir / "input_dataset_column_audit.csv", index=False)

    count_rows = []
    for col in ["CNTRY_OF_RISK", "COUNTRY_FULL_NAME", "INDUSTRY_SECTOR", "CPN_TYP", "CALLABLE", "PUTABLE", "SINKABLE"]:
        if col in df.columns:
            for level, count in df[col].astype(str).str.upper().str.strip().value_counts(dropna=False).head(15).items():
                count_rows.append({"Variable": col, "Level": level, "Rows": int(count), "Share": float(count / max(len(df), 1))})
    pd.DataFrame(count_rows).to_csv(output_dir / "input_dataset_top_counts.csv", index=False)

    if "CNTRY_OF_RISK" in df.columns:
        risk_raw  = df["CNTRY_OF_RISK"].astype(str).str.upper().str.strip().replace({"NAN": "", "NONE": "", "NULL": ""})
        risk_name = risk_raw.map(DataCleaningPipeline.ISO2_COUNTRY_FULL_NAMES).fillna(risk_raw.apply(DataCleaningPipeline._norm_country))
        latam_mask= risk_raw.isin(DataCleaningPipeline.LATAM_EX_CARIBBEAN_ISO2) | risk_name.isin(DataCleaningPipeline.LATAM_EX_CARIBBEAN_COUNTRIES)
        (
            pd.DataFrame({"CNTRY_OF_RISK": risk_raw.loc[latam_mask], "COUNTRY_RISK_NAME": risk_name.loc[latam_mask]})
            .value_counts(["CNTRY_OF_RISK", "COUNTRY_RISK_NAME"])
            .rename("Rows").reset_index()
            .sort_values(["CNTRY_OF_RISK", "COUNTRY_RISK_NAME"])
            .to_csv(output_dir / "latam_rows_by_cntry_of_risk.csv", index=False)
        )

    print("\n" + "=" * 78)
    print("INPUT MASTER DATASET AUDIT")
    print("=" * 78)
    for k, v in summary.items():
        print(f"{k:40s}: {v}")
    print(f"Audit files written to : {output_dir.resolve()}")
    print("=" * 78)
    return summary


def sanitize_selected_features_file(
    features_path: str | Path,
    use_latam_specific_inputs: bool,
    overwrite: bool = True,
) -> pd.DataFrame:
    path = Path(features_path)
    if not path.exists():
        raise FileNotFoundError(f"Selected-features file not found: {path}")

    features          = pd.read_csv(path)
    features.columns  = [str(c).upper().strip() for c in features.columns]
    if "FEATURE" not in features.columns:
        raise KeyError("selected_features.csv must contain a FEATURE column.")

    features["FEATURE"] = features["FEATURE"].astype(str).str.upper().str.strip()

    before       = len(features)
    allowed_mask = features["FEATURE"].map(is_allowed_model_input_feature)
    disallowed   = features.loc[~allowed_mask, "FEATURE"].tolist()
    features     = features.loc[allowed_mask].copy()
    if disallowed:
        print(f"Column whitelist: removed {before - len(features):,} feature(s) outside the allowed universe.")
        print("Preview:", disallowed[:20])

    if use_latam_specific_inputs:
        print("LATAM-specific input variables are allowed.")
        if overwrite:
            features.to_csv(path, index=False)
        return features

    before      = len(features)
    keep_mask   = ~features["FEATURE"].map(is_latam_specific_feature)
    filtered    = features.loc[keep_mask].copy()
    removed     = features.loc[~keep_mask, "FEATURE"].tolist()
    if overwrite:
        filtered.to_csv(path, index=False)
    print(f"ALL_EM mode: removed {before - len(filtered):,} LATAM-specific features.")
    for f in removed:
        print(f"  - {f}")
    return filtered


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":

    # ======================================================
    # USER SETTINGS — EDIT HERE
    # ======================================================
    USE_LATAM_EX_CARIBBEAN   = True
    EXCLUDE_GOVERNMENT_BONDS = True
    USE_FIXED_COUPON_ONLY    = True
    DROP_OPTION_BONDS        = False

    TARGET_SPREAD_COLUMN = "Z_SPREAD_MID"       # "Z_SPREAD_MID" | "Z_SPREAD_BPS"
    TARGET_MODE          = "weekly_pct_change"   # level | weekly_diff | weekly_pct_change
                                                 # monthly_diff | monthly_pct_change
    RAW_SHEET_NAME       = DEFAULT_SHEET         # from path_config.py ("Worksheet")

    SHOW_PLOTS              = True
    RUN_INPUT_DATASET_AUDIT = True

    # ======================================================
    # Verify input file exists
    # ======================================================
    if not MASTER_DATA_PATH.exists():
        raise FileNotFoundError(
            f"Input file not found:\n  {MASTER_DATA_PATH}\n\n"
            f"OUTPUT_DIR  : {OUTPUT_DIR}\n"
            "Check that:\n"
            "  1. path_config.py defines MASTER = OUTPUT_DIR / 'master_dataset_features_eng.xlsx'\n"
            "  2. The file exists in the Output folder.\n"
            "  3. The network drive is reachable (VPN if off-site)."
        )

    # ======================================================
    # Derived settings
    # ======================================================
    LATAM_EX_CARIBBEAN_ONLY   = bool(USE_LATAM_EX_CARIBBEAN)
    EXCLUDE_GOVERNMENT        = bool(EXCLUDE_GOVERNMENT_BONDS)
    FIXED_COUPON_ONLY         = bool(USE_FIXED_COUPON_ONLY)
    UNIVERSE_MODE             = "LATAM" if LATAM_EX_CARIBBEAN_ONLY else "ALL_EM"
    USE_LATAM_SPECIFIC_INPUTS = LATAM_EX_CARIBBEAN_ONLY

    TARGET_SPREAD_COLUMN = str(TARGET_SPREAD_COLUMN).upper().strip()
    if TARGET_SPREAD_COLUMN not in {"Z_SPREAD_MID", "Z_SPREAD_BPS"}:
        raise ValueError(f"Invalid TARGET_SPREAD_COLUMN={TARGET_SPREAD_COLUMN!r}.")

    TARGET_MODE = str(TARGET_MODE).lower().strip()
    if TARGET_MODE not in {"level", "weekly_diff", "weekly_pct_change", "monthly_diff", "monthly_pct_change"}:
        raise ValueError(f"Invalid TARGET_MODE={TARGET_MODE!r}.")

    FREQUENCY = "monthly" if TARGET_MODE.startswith("monthly_") else "weekly"

    # ── Ensure output directories exist ──────────────────────────────────────
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LATEX_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Output paths
    CLEAN_DATA_PATH       = str(MASTER_CLEAN_PATH)                                  # OUTPUT_DIR / MASTER_CLEAN.xlsx
    SELECTED_FEATURES_PATH= str(LATEX_OUTPUT_DIR / "selected_features.csv")         # output_for_latex/

    print("\n" + "=" * 78)
    print("MASTER-METHOD DATA CLEANING SCRIPT")
    print("=" * 78)
    print(f"Universe mode        : {UNIVERSE_MODE}")
    print(f"Input file           : {MASTER_DATA_PATH}")
    print(f"  Sheet              : {RAW_SHEET_NAME}")
    print(f"Target spread column : {TARGET_SPREAD_COLUMN}")
    print(f"Target mode          : {TARGET_MODE}")
    print(f"Frequency            : {FREQUENCY}")
    print(f"Output directory     : {OUTPUT_DIR}")
    print(f"  MASTER_CLEAN       : {MASTER_CLEAN_PATH}")
    print(f"  output_for_latex/  : {LATEX_OUTPUT_DIR}")
    print("=" * 78)

    if RUN_INPUT_DATASET_AUDIT:
        audit_input_dataset(
            data_path  = str(MASTER_DATA_PATH),
            sheet_name = RAW_SHEET_NAME,
            output_dir = str(LATEX_OUTPUT_DIR),      # ← audit CSVs go to output_for_latex/
        )

    cleaning_config = DataCleaningConfig(
        data_path        = str(MASTER_DATA_PATH),
        output_dataset   = CLEAN_DATA_PATH,           # OUTPUT_DIR / MASTER_CLEAN.xlsx
        output_features  = SELECTED_FEATURES_PATH,    # output_for_latex / selected_features.csv
        sheet_name       = RAW_SHEET_NAME,

        frequency          = FREQUENCY,
        target_col         = TARGET_SPREAD_COLUMN,
        target_mode        = TARGET_MODE,
        target_lag_periods = 1,

        latam_ex_caribbean_only = LATAM_EX_CARIBBEAN_ONLY,
        exclude_government      = EXCLUDE_GOVERNMENT,
        fixed_coupon_only       = FIXED_COUPON_ONLY,
        drop_option_bonds       = DROP_OPTION_BONDS,

        dummy_columns     = ("CNTRY_OF_RISK", "CURRENCY", "INDUSTRY_SECTOR", "PAYMENT_RANK"),
        max_dummy_levels  = 40,
        time_fixed_effect = "none",

        include_global_features      = True,
        include_emerging_features    = True,
        include_bond_features        = True,
        include_yield_price_features = False,

        corr_threshold          = 0.80,
        drop_high_corr_features = True,
        max_corr_features       = 45,

        vif_threshold           = 10.0,
        drop_high_vif_features  = True,
        max_vif_features        = 120,
    )

    cleaning_pipeline = DataCleaningPipeline(config=cleaning_config)
    cleaning_pipeline.run_all(show_plots=SHOW_PLOTS)

    sanitize_selected_features_file(
        SELECTED_FEATURES_PATH,
        use_latam_specific_inputs=USE_LATAM_SPECIFIC_INPUTS,
        overwrite=True,
    )

    print("\nCleaning complete.")
    print(f"\nOutputs:")
    print(f"  MASTER_CLEAN       : {MASTER_CLEAN_PATH.resolve()}")
    print(f"  output_for_latex/  : {LATEX_OUTPUT_DIR.resolve()}")
    print(f"    selected_features.csv")
    print(f"    input_dataset_audit_summary.csv")
    print(f"    input_dataset_column_audit.csv")
    print(f"    input_dataset_top_counts.csv")
    print(f"    latam_rows_by_cntry_of_risk.csv")

# %%