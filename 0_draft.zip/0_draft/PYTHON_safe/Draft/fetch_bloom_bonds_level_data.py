# %% BLOOMBERG BOND HISTORY EXTRACTOR (BOND LIFE AWARE, FULL UNIVERSE)

# ==========================================================
# Author: Amin Tarbouch
# ==========================================================

import os
from dataclasses import dataclass
from typing import Dict, List

import pandas as pd
from xbbg import blp


# ==========================================================
# CONFIGURATION
# ==========================================================

@dataclass
class BloombergRequestConfig:
    global_start: str
    global_end: str
    periodicity: str = "M"
    days: str = "A"
    fill: str = "C"
    chunk_size: int = 100


# ==========================================================
# UTILITIES
# ==========================================================

def load_benchmark_from_excel(
    path_excel: str,
    input_file: str,
    sheet_name: str,
    config: BloombergRequestConfig,
) -> pd.DataFrame:
    df = pd.read_excel(os.path.join(path_excel, input_file), sheet_name=sheet_name)
    df.columns = df.columns.str.strip().str.upper()

    required = ["ISIN", "ISSUE_DT", "MATURITY"]
    for c in required:
        if c not in df.columns:
            raise KeyError(f"Missing required column: {c}")

    df["ISSUE_DT"] = pd.to_datetime(df["ISSUE_DT"], errors="coerce")
    df["MATURITY"] = pd.to_datetime(df["MATURITY"], errors="coerce")

    global_start = pd.to_datetime(config.global_start)
    n_before_start = df.loc[df["ISSUE_DT"] < global_start, "ISIN"].nunique()
    total_bonds = df["ISIN"].nunique()

    print(
        f"✅ Benchmark loaded\n"
        f"   • Total bonds: {total_bonds:,}\n"
        f"   • Bonds issued before {global_start.date()}: {n_before_start:,} "
        f"({n_before_start / total_bonds:.1%} of total)"
    )

    return df.reset_index(drop=True)


def build_isin_to_bbg_mapping(isins: pd.Series) -> Dict[str, str]:
    return {isin: f"{isin} Corp" for isin in isins.dropna().unique()}  # Adding " Corp" to ISIN


# ==========================================================
# EXTRACTOR CLASS
# ==========================================================

class BondHistoryExtractor:
    """
    Bloomberg extraction strictly limited to each bond life:
    [max(ISSUE_DT, global_start), min(MATURITY, global_end)]

    BDH fields (time-series) and BDP fields (static) are passed
    explicitly at construction time from the __main__ selection block.

    Rating fallback logic:
    ─────────────────────
    Rating fields (RTG_SP, RTG_MOODY, RTG_FITCH, RTG_BB_COMPOSITE) are first attempted
    via BDH (time-varying). If BDH returns no data for those fields
    (e.g. due to license restrictions), the extractor automatically
    falls back to BDP to fetch the current snapshot rating and
    broadcasts it across all observation dates for the bond.
    """

    # Rating fields that support BDH → BDP fallback
    RATING_FIELDS = {"RTG_SP", "RTG_MOODY", "RTG_FITCH", "RTG_BB_COMPOSITE"}

    # Rename map for known Bloomberg field names
    FIELD_RENAME_MAP = {
        # Prices
        "PX_MID": "MID_PRICE",
        "PX_DIRTY_MID": "DIRTY_PRICE",
        "PX_BID": "BID_PRICE",
        "PX_ASK": "ASK_PRICE",
        # Spreads
        "Z_SPRD_MID": "Z_SPREAD_MID",
        "YAS_OAS_SPRD": "YAS_OAS_SPRD",
        "YAS_ISPRD": "I_SPREAD",
        "YAS_ASW_SPRD": "ASW_SPREAD",
        # Yield
        "YLD_YTM_MID": "YTM_MID",
        "YLD_YTM_BID": "YTM_BID",
        # Duration / Risk
        "DUR_MID": "DURATION_MID",
        "CONVEXITY_MID": "CONVEXITY_MID",
        "DV01": "DV01",
        # Ratings (BDH — time-varying, with BDP fallback)
        "RTG_SP": "RATING_SP",
        "RTG_MOODY": "RATING_MOODY",
        "RTG_FITCH": "RATING_FITCH",
        "RTG_BB_COMPOSITE": "RATING_BLOOMBERG_COMPOSITE",
        # Static (BDP)
        "PAR_AMT": "PAR_VALUE",
        "CPN": "COUPON",
        "CRNCY": "CURRENCY",
        "COUNTRY_ISO": "COUNTRY",
        "INDUSTRY_SECTOR": "INDUSTRY_SECTOR",
        "AMT_OUTSTANDING": "AMT_OUTSTANDING",
    }

    def __init__(
        self,
        benchmark: pd.DataFrame,
        isin_to_bbg: Dict[str, str],
        config: BloombergRequestConfig,
        bdh_fields: List[str],
        bdp_fields: List[str],
    ):
        self.benchmark = benchmark.copy()
        self.isin_to_bbg = isin_to_bbg
        self.config = config
        self.bdh_fields = bdh_fields
        self.bdp_fields = bdp_fields

        # Counters
        self.n_bdp_calls = 0
        self.n_bdh_calls = 0
        self.n_total_requests = 0

        # Optional expected counts
        self.expected_bdp_calls = 0
        self.expected_bdh_calls = 0
        self.expected_total_requests = 0

        # Identify which rating fields were requested via BDH
        # so we know what to fall back on if BDH returns nothing
        self._bdh_rating_fields = [
            f for f in self.bdh_fields if f.upper() in self.RATING_FIELDS
        ]

    def _count_chunks(self, n_items: int) -> int:
        if n_items <= 0:
            return 0
        return (n_items + self.config.chunk_size - 1) // self.config.chunk_size

    def _progress_text(self, current: int, total: int) -> str:
        return f"{current}/{total}" if total else str(current)

    # ----------------------------------------------------------
    # STATIC DATA — BDP
    # ----------------------------------------------------------

    def fetch_static_data(self, securities: List[str]) -> pd.DataFrame:
        """
        Fetch BDP fields + rating fallback fields in a single call.
        Rating fallback fields are appended temporarily; they will only
        be used to fill gaps left by BDH and are dropped from the
        static block afterwards so there is no column duplication.
        """
        # Union of explicitly requested BDP fields + rating fallback candidates
        fields_to_fetch = list(
            dict.fromkeys(self.bdp_fields + self._bdh_rating_fields)
        )

        if not securities or not fields_to_fetch:
            return pd.DataFrame()

        print(f"📋 Fetching static data {fields_to_fetch} for {len(securities)} bonds …")

        chunks = [
            securities[i: i + self.config.chunk_size]
            for i in range(0, len(securities), self.config.chunk_size)
        ]

        all_static = []
        total_chunks = len(chunks)

        for chunk_idx, chunk in enumerate(chunks, start=1):
            self.n_bdp_calls += 1
            self.n_total_requests += 1

            print(
                f"📡 BDP request {self._progress_text(self.n_bdp_calls, self.expected_bdp_calls)}"
                f" | total {self._progress_text(self.n_total_requests, self.expected_total_requests)}"
                f" | chunk {chunk_idx}/{total_chunks}"
                f" | securities: {len(chunk)}"
            )

            try:
                df_static = blp.bdp(tickers=chunk, flds=fields_to_fetch)
                df_static.index.name = "BBG_SECURITY"
                df_static = df_static.reset_index()
                all_static.append(df_static)

                print(f"   ✅ BDP chunk returned shape: {df_static.shape}")

            except Exception as e:
                print(f"⚠️  BDP error for chunk: {e}")

        if not all_static:
            return pd.DataFrame()

        result = pd.concat(all_static, ignore_index=True)
        result.columns = result.columns.str.strip().str.upper()
        result = result.rename(columns=self.FIELD_RENAME_MAP)

        print(f"✅ Static data fetched — shape: {result.shape}")
        return result

    # ----------------------------------------------------------
    # TIME-SERIES DATA — BDH
    # ----------------------------------------------------------

    def fetch_bdh(
        self,
        securities: List[str],
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        if not securities or not self.bdh_fields:
            return pd.DataFrame()

        self.n_bdh_calls += 1
        self.n_total_requests += 1

        print(
            f"🔍 BDH request {self._progress_text(self.n_bdh_calls, self.expected_bdh_calls)}"
            f" | total {self._progress_text(self.n_total_requests, self.expected_total_requests)}"
            f" | securities: {len(securities)}"
            f" | {start_date} -> {end_date}"
        )

        df = blp.bdh(
            tickers=securities,
            flds=self.bdh_fields,
            start_date=start_date,
            end_date=end_date,
            Per=self.config.periodicity,
            Days=self.config.days,
            Fill=self.config.fill,
        )

        print(f"✅ BDH returned shape: {df.shape}")
        return df

    # ----------------------------------------------------------
    # RATING FALLBACK — BDH → BDP
    # ----------------------------------------------------------

    def _apply_rating_fallback(
        self,
        panel: pd.DataFrame,
        static_df: pd.DataFrame,
    ) -> pd.DataFrame:
        """
        For each rating field requested via BDH, check whether the
        column exists and is fully null in the panel.  If so, broadcast
        the current (BDP) rating from static_df across all rows for
        that bond.

        This handles two scenarios gracefully:
          1. BDH returned the column but it is all-NaN  → fill from BDP
          2. BDH did not return the column at all        → create it from BDP
        """
        if not self._bdh_rating_fields or static_df.empty:
            return panel

        for raw_field in self._bdh_rating_fields:
            renamed = self.FIELD_RENAME_MAP.get(raw_field.upper(), raw_field.upper())

            # Check whether BDH actually populated this column
            bdh_has_data = (
                renamed in panel.columns
                and panel[renamed].notna().any()
            )

            if bdh_has_data:
                # BDH data is present — nothing to do
                continue

            # BDH data is absent or fully null → attempt BDP fallback
            if renamed not in static_df.columns:
                print(
                    f"⚠️  Rating fallback: '{renamed}' not available in BDP either — "
                    f"column will remain NaN."
                )
                if renamed not in panel.columns:
                    panel[renamed] = pd.NA
                continue

            print(
                f"⚠️  BDH returned no data for '{renamed}'. "
                f"Falling back to current BDP rating …"
            )

            # Build a lookup: BBG_SECURITY → current rating (from BDP)
            rating_lookup = static_df.set_index("BBG_SECURITY")[renamed].to_dict()

            # Broadcast the static rating to every row for that bond
            if renamed not in panel.columns:
                panel[renamed] = pd.NA

            panel[renamed] = panel[renamed].where(
                panel[renamed].notna(),
                panel["BBG_SECURITY"].map(rating_lookup),
            )

            # Tag rows that used the fallback for traceability
            fallback_flag_col = f"{renamed}_IS_FALLBACK"
            panel[fallback_flag_col] = panel["BBG_SECURITY"].map(
                lambda sec: rating_lookup.get(sec) is not None
                and pd.isna(panel.loc[panel["BBG_SECURITY"] == sec, renamed].iloc[0])
                if sec in rating_lookup else False
            )
            # Simpler and vectorised flag: True where we filled from BDP
            panel[fallback_flag_col] = (
                panel["BBG_SECURITY"].map(rating_lookup).notna()
            )

        return panel

    # ----------------------------------------------------------
    # MAIN BUILD
    # ----------------------------------------------------------

    def build_dataset(self) -> pd.DataFrame:

        df = self.benchmark.copy()
        df["BBG_SECURITY"] = df["ISIN"].map(self.isin_to_bbg)

        global_start = pd.to_datetime(self.config.global_start)
        global_end = pd.to_datetime(self.config.global_end)

        df["EFF_START"] = df["ISSUE_DT"].clip(lower=global_start)
        df["EFF_END"] = df["MATURITY"].clip(upper=global_end)
        df = df[df["EFF_START"] <= df["EFF_END"]]

        # Expected request counts
        all_securities = df["BBG_SECURITY"].dropna().unique().tolist()
        static_fields_to_fetch = list(dict.fromkeys(self.bdp_fields + self._bdh_rating_fields))

        self.expected_bdp_calls = (
            self._count_chunks(len(all_securities))
            if all_securities and static_fields_to_fetch else 0
        )

        self.expected_bdh_calls = (
            sum(
                self._count_chunks(group["BBG_SECURITY"].dropna().nunique())
                for _, group in df.groupby(["EFF_START", "EFF_END"])
            )
            if self.bdh_fields else 0
        )

        self.expected_total_requests = self.expected_bdp_calls + self.expected_bdh_calls

        print(
            f"\n📌 Expected Bloomberg requests:\n"
            f"   • BDP: {self.expected_bdp_calls}\n"
            f"   • BDH: {self.expected_bdh_calls}\n"
            f"   • Total: {self.expected_total_requests}"
        )

        # Step 1 — Static data (BDP) — also pre-fetches rating fallback values
        static_df = self.fetch_static_data(all_securities)

        # Step 2 — Time-series data (BDH)
        all_results = []

        for (start, end), group in df.groupby(["EFF_START", "EFF_END"]):

            securities = group["BBG_SECURITY"].dropna().unique().tolist()
            if not securities:
                continue

            for i in range(0, len(securities), self.config.chunk_size):
                chunk = securities[i: i + self.config.chunk_size]
                history = self.fetch_bdh(
                    securities=chunk,
                    start_date=start.strftime("%Y-%m-%d"),
                    end_date=end.strftime("%Y-%m-%d"),
                )

                if history.empty:
                    continue

                long_df = (
                    history
                    .stack(level=0, future_stack=True)
                    .reset_index()
                    .rename(columns={"level_0": "DATE", "level_1": "BBG_SECURITY"})
                )

                long_df["DATE"] = pd.to_datetime(long_df["DATE"])
                merged = long_df.merge(group, on="BBG_SECURITY", how="left")
                all_results.append(merged)

        print(
            f"\n📊 Bloomberg requests completed:\n"
            f"   • BDP calls made: {self.n_bdp_calls}\n"
            f"   • BDH calls made: {self.n_bdh_calls}\n"
            f"   • Total requests made: {self.n_total_requests}"
        )

        if not all_results:
            return pd.DataFrame()

        result = pd.concat(all_results, ignore_index=True)

        # Step 3 — Rename Bloomberg fields before fallback check
        result = result.rename(columns=self.FIELD_RENAME_MAP)

        # Step 4 — Apply rating fallback (BDH → BDP) where needed
        if not static_df.empty:
            result = self._apply_rating_fallback(result, static_df)

        # Step 5 — Join remaining static fields (non-rating BDP columns) onto panel
        if not static_df.empty:
            # Drop rating columns from static_df to avoid duplication
            # (they were already merged via fallback logic above)
            rating_renamed = [
                self.FIELD_RENAME_MAP.get(f.upper(), f.upper())
                for f in self._bdh_rating_fields
            ]
            static_to_join = static_df.drop(
                columns=[c for c in rating_renamed if c in static_df.columns],
                errors="ignore",
            )
            if not static_to_join.empty and len(static_to_join.columns) > 1:
                result = result.merge(static_to_join, on="BBG_SECURITY", how="left")

        # Step 6 — Reorder columns
        id_cols = ["DATE", "ISIN", "TICKER", "BBG_SECURITY"]

        # All renamed field names (BDH + BDP + fallback flags)
        all_requested_renamed = [
            self.FIELD_RENAME_MAP.get(f.upper(), f.upper())
            for f in (self.bdh_fields + self.bdp_fields)
        ]
        fallback_flag_cols = [
            f"{self.FIELD_RENAME_MAP.get(f.upper(), f.upper())}_IS_FALLBACK"
            for f in self._bdh_rating_fields
        ]

        ordered_cols = (
            id_cols
            + [c for c in all_requested_renamed if c in result.columns]
            + [c for c in fallback_flag_cols if c in result.columns]
        )
        remaining_cols = [c for c in result.columns if c not in ordered_cols]

        return (
            result[ordered_cols + remaining_cols]
            .sort_values(["ISIN", "DATE"])
            .reset_index(drop=True)
        )


# ==========================================================
# RUN
# ==========================================================

if __name__ == "__main__":

    # ----------------------------------------------------------
    # PATHS (loaded from config)
    # ----------------------------------------------------------
    config = get_script_config(__file__)
    PATH_EXCEL = config.get('PATH_EXCEL')
    INPUT_FILE = config.get('INPUT_FILE')
    OUTPUT_FILE = config.get('OUTPUT_FILE')
    SHEET_NAME = config.get('SHEET_NAME', 'Worksheet')

    # ----------------------------------------------------------
    # EXTRACTION WINDOW & PERIODICITY
    # ----------------------------------------------------------
    config = BloombergRequestConfig(
        global_start="2020-01-01",
        global_end="2026-06-01",
        periodicity="W",        # D=daily | W=weekly | M=monthly
        days="A",               # A=all calendar days | T=trading days
        fill="C",               # C=carry forward | B=blank
        chunk_size=100,
    )

    # ----------------------------------------------------------
    # METRICS SELECTION
    # ----------------------------------------------------------
    # BDH — time-series fields (one value per bond per date)
    # Bloomberg returns the value as it stood on each observation
    # date, so any change over time is automatically captured
    # (e.g. a rating downgrade will show up on the right date).
    #
    # ⚡ RATING FALLBACK: if BDH returns no data for RTG_* fields
    # (e.g. due to license restrictions), the extractor will
    # automatically fall back to current BDP ratings and broadcast
    # them across all dates. A companion *_IS_FALLBACK boolean column
    # will be added so you can identify which bonds used the fallback.

    BDH_FIELDS = [
        # --- Prices ---
        "PX_MID",
        "PX_DIRTY_MID",
        "PX_BID",
        "PX_ASK",
        # --- Spreads ---
        "Z_SPRD_MID",
        "YAS_OAS_SPRD",
        "YAS_ISPREAD_TO_GOVT",
        "YAS_ISPREAD",
        # --- Ratings (time-varying, BDP fallback if BDH unavailable) ---
        "RTG_SP",
        "RTG_MOODY",
        "RTG_FITCH",
        "RTG_BB_COMPOSITE",
        # --- Uncomment below to add more ---
        # "YAS_ISPRD",
        # "YAS_ASW_SPRD",
        # "YLD_YTM_MID",
        # "YLD_YTM_BID",
        # "DUR_MID",
        # "CONVEXITY_MID",
        # "DV01",
    ]

    # ----------------------------------------------------------
    # BDP — static / reference fields (fetched once per bond)
    # Use for fields that do NOT change over the bond's life.

    BDP_FIELDS = [
        "PAR_AMT",
        # "CPN",
        # "CRNCY",
        # "COUNTRY_ISO",
        # "INDUSTRY_SECTOR",
        # "AMT_OUTSTANDING",
    ]

    # ----------------------------------------------------------
    # LOAD & RUN
    # ----------------------------------------------------------
    benchmark = load_benchmark_from_excel(
        PATH_EXCEL,
        INPUT_FILE,
        SHEET_NAME,
        config=config,
    )

    isin_to_bbg = build_isin_to_bbg_mapping(benchmark["ISIN"])

    extractor = BondHistoryExtractor(
        benchmark=benchmark,
        isin_to_bbg=isin_to_bbg,
        config=config,
        bdh_fields=BDH_FIELDS,
        bdp_fields=BDP_FIELDS,
    )

    df_result = extractor.build_dataset()

    print("\n✅ FINAL DATASET READY")
    print(df_result.head(10))

    output_path = os.path.join(PATH_EXCEL, OUTPUT_FILE)
    df_result.to_excel(output_path, index=False)

    print(f"\n💾 Dataset saved → {output_path}")

# %%
