# %% REGRESSION ANALYSIS OBJECT (SINGLE EXCEL FILE: BOND + MACRO + Z-SPREAD)

import warnings

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import statsmodels.api as sm

from sklearn.compose import ColumnTransformer
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from statsmodels.stats.outliers_influence import variance_inflation_factor

warnings.filterwarnings("ignore", category=ConvergenceWarning)

from path_config import Z_SPREADS

class BondRiskRegressor:
    def __init__(
        self,
        data_path,
        target_col="Z_SPREAD_BPS",
        sheet_name=0,
        remove_collinear=False,
        corr_threshold=0.85,
        vif_threshold=10.0,
        group_feature_display=True,   # NEW
    ):
        self.data_path = data_path
        self.target_col = target_col
        self.sheet_name = sheet_name

        self.remove_collinear = remove_collinear
        self.corr_threshold = corr_threshold
        self.vif_threshold = vif_threshold
        self.group_feature_display = group_feature_display

        self.df = None
        self.X = None
        self.y = None
        self.results = {}
        self.models = {}
        self.preprocessor = None

        self.selected_features = None
        self.numeric_features_final = None
        self.categorical_features_final = None

        self.corr_matrix = None
        self.high_corr_pairs = None
        self.vif_table = None
        self.dropped_corr_features = []
        self.dropped_vif_features = []

        # Bonds level data features
        self.bond_feature_list = [
            "PAR_VAL",
            # "CPN",
            "TTM",
            "ISSUE_YEAR",
            "MATURITY_YEAR",
            "OBS_YEAR",
            "OBS_MONTH",
            "BA_SPREAD",
            "ZR_PROXY",
            "AGE_YEARS",
            "SIZE",
            "SENIOR_DUMMY",
        ]

        # Global level data features (MA(3))
        self.global_feature_list = [
            "MA3_VIX_INDEX",
            "MA3_UKX_INDEX",
            "MA3_MOVE_INDEX",
            "MA3_STOXX600",
            "MA3_SP500",
            "MA3_BFCIUS_INDEX",
            "MA3_BFCIEU_INDEX",
            "MA3_CDX_IG_CDSI_GEN_5Y_CORP",
            "MA3_ITRX_EUR_CDSI_GEN_5Y_CORP",
            "MA3_GDP_CQOQ_INDEX",
            "MA3_EUGNEMUQ_INDEX",
            "MA3_CPI_YOY_INDEX",
            "MA3_ECCPEMUY_INDEX",
        ]

        # Emerging level data features (MA(3))
        self.emerging_feature_list = [
            "MA3_MSCI_EM",
            "MA3_JPM_EMBI",
            "MA3_EPUCEMEC_INDEX",
            "MA3_CAFZUUEM_INDEX",
        ]

        # Alternative data features (MA(3))
        self.alternative_feature_list = [
            "MA3_AONILS_INDEX",

            # Global climate risk
            "MA3_GLCRPCR_INDEX",
            "MA3_GLCRCBV_INDEX",
            "MA3_GLCRNCB_INDEX",

            # Global country-level climate risk
            "MA3_GCILMANM_INDEX",
            "MA3_GCILNATL_INDEX",

            # # Country-specific political / climate risk
            # "MA3_CRPTBRAZ_INDEX",
            # "MA3_CRPTCHIN_INDEX",
            # "MA3_CRPTHOKO_INDEX",
            # "MA3_CRPTMEXI_INDEX",
            # "MA3_CRPTKORE_INDEX",
            # "MA3_CRPTINDI_INDEX",
            # "MA3_CRPTUNAE_INDEX",

            # # ILS
            # "ILS_RETURNS",
        ]

    # ==================================================
    # LOAD DATA
    # ==================================================
    def load_data(self):
        """Load the single Excel dataset containing bond + macro data."""
        self.df = pd.read_excel(self.data_path, sheet_name=self.sheet_name)
        self.df.columns = [str(c).strip().upper() for c in self.df.columns]

        date_cols = ["DATE", "ISSUE_DT", "MATURITY_DT", "EFF_START", "EFF_END"]
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors="coerce")

        print(
            f"✅ Data loaded successfully → "
            f"{self.df.shape[0]} rows, {self.df.shape[1]} columns"
        )

    # ==================================================
    # CLEAN NUMERIC
    # ==================================================
    def _clean_all_numeric(self, df):
        """Clean numeric-like object columns."""
        df = df.copy()

        for col in df.columns:
            if df[col].dtype == "object":
                cleaned = (
                    df[col]
                    .astype(str)
                    .str.replace(",", "", regex=False)
                    .str.replace(" ", "", regex=False)
                    .str.replace("N/A", "", regex=False)
                    .str.replace("#N/A N/A", "", regex=False)
                    .replace("nan", np.nan)
                    .replace("None", np.nan)
                    .replace("", np.nan)
                )
                try:
                    df[col] = pd.to_numeric(cleaned, errors="raise")
                except Exception:
                    df[col] = df[col]

        return df

    def _to_numeric_series(self, series):
        """Robust numeric conversion helper."""
        cleaned = (
            series.astype(str)
            .str.replace(",", "", regex=False)
            .str.replace(" ", "", regex=False)
            .str.replace("N/A", "", regex=False)
            .str.replace("#N/A N/A", "", regex=False)
            .replace("nan", np.nan)
            .replace("None", np.nan)
            .replace("", np.nan)
        )
        return pd.to_numeric(cleaned, errors="coerce")

    # ==================================================
    # NEW METRICS
    # ==================================================
    def quoted_bid_ask_spread(self):
        """
        Quoted bid-ask spread proxy:
            (ASK_PRICE - BID_PRICE) / MID_PRICE

        Falls back to denominator = (ASK_PRICE + BID_PRICE) / 2 if MID_PRICE is unavailable.
        Returns NaN where bid/ask is unavailable or denominator is invalid.
        """
        if self.df is None:
            raise ValueError("❌ Data must be loaded before computing BA_SPREAD.")

        df = self.df

        if "BID_PRICE" not in df.columns or "ASK_PRICE" not in df.columns:
            return pd.Series(np.nan, index=df.index, name="BA_SPREAD")

        bid = self._to_numeric_series(df["BID_PRICE"])
        ask = self._to_numeric_series(df["ASK_PRICE"])

        if "MID_PRICE" in df.columns:
            mid = self._to_numeric_series(df["MID_PRICE"])
        else:
            mid = (bid + ask) / 2.0

        spread = (ask - bid) / mid.replace(0, np.nan)
        spread = spread.replace([np.inf, -np.inf], np.nan)

        return spread.rename("BA_SPREAD")

    def zero_return_proxy(self):
        """
        Simple zero-return proxy:
        1 if price appears unchanged versus previous observation for same bond, else 0.

        Requires:
        - DATE
        - one bond identifier among: ISIN / BOND_ID / SECURITY_ID / ID / TICKER
        - MID_PRICE or DIRTY_PRICE or ASK/BID fallback

        If insufficient columns exist, returns NaN series.
        """
        if self.df is None:
            raise ValueError("❌ Data must be loaded before computing ZR_PROXY.")

        df = self.df.copy()

        id_candidates = ["ISIN", "BOND_ID", "SECURITY_ID", "ID", "TICKER"]
        bond_id_col = next((c for c in id_candidates if c in df.columns), None)

        if "MID_PRICE" in df.columns:
            price_col = "MID_PRICE"
        elif "DIRTY_PRICE" in df.columns:
            price_col = "DIRTY_PRICE"
        elif "BID_PRICE" in df.columns and "ASK_PRICE" in df.columns:
            df["_TMP_MID_PRICE"] = (
                self._to_numeric_series(df["BID_PRICE"]) +
                self._to_numeric_series(df["ASK_PRICE"])
            ) / 2.0
            price_col = "_TMP_MID_PRICE"
        else:
            return pd.Series(np.nan, index=df.index, name="ZR_PROXY")

        if bond_id_col is None or "DATE" not in df.columns:
            return pd.Series(np.nan, index=df.index, name="ZR_PROXY")

        df[price_col] = self._to_numeric_series(df[price_col])
        df = df.sort_values([bond_id_col, "DATE"]).copy()

        prev_price = df.groupby(bond_id_col)[price_col].shift(1)
        zr = (df[price_col] == prev_price).astype(float)
        zr[(df[price_col].isna()) | (prev_price.isna())] = np.nan

        zr = zr.reindex(self.df.index)
        return zr.rename("ZR_PROXY")

    def age_years(self):
        """
        Bond age in years:
            DATE - ISSUE_DT
        """
        if self.df is None:
            raise ValueError("❌ Data must be loaded before computing AGE_YEARS.")

        df = self.df

        if "DATE" not in df.columns or "ISSUE_DT" not in df.columns:
            return pd.Series(np.nan, index=df.index, name="AGE_YEARS")

        age = (df["DATE"] - df["ISSUE_DT"]).dt.days / 365.25
        age = age.where(age >= 0, np.nan)

        return age.rename("AGE_YEARS")

    def size_proxy(self):
        """
        Size proxy:
        - prefers log(PAR_VAL) if available and strictly positive
        - otherwise returns NaN for non-positive values
        """
        if self.df is None:
            raise ValueError("❌ Data must be loaded before computing SIZE.")

        df = self.df

        if "PAR_VAL" not in df.columns:
            return pd.Series(np.nan, index=df.index, name="SIZE")

        par_val = self._to_numeric_series(df["PAR_VAL"])
        size = np.where(par_val > 0, np.log(par_val), np.nan)

        return pd.Series(size, index=df.index, name="SIZE")

    def add_derived_features(self):
        """Create all derived metrics and append them to self.df."""
        if self.df is None:
            raise ValueError("❌ Load data before adding derived features.")

        self.df["BA_SPREAD"] = self.quoted_bid_ask_spread()
        self.df["ZR_PROXY"] = self.zero_return_proxy()
        self.df["AGE_YEARS"] = self.age_years()
        self.df["SIZE"] = self.size_proxy()

        print("\n✅ Derived features added:")
        print(
            self.df[["BA_SPREAD", "ZR_PROXY", "AGE_YEARS", "SIZE"]]
            .isna()
            .sum()
            .to_string()
        )

    # ==================================================
    # FEATURE DISPLAY HELPERS
    # ==================================================
    def _clean_feature_name(self, feature_name):
        """Remove sklearn prefixes and map raw names to readable labels."""
        if feature_name.startswith("num__"):
            feature_name = feature_name.replace("num__", "")
        if feature_name.startswith("cat__"):
            feature_name = feature_name.replace("cat__", "")

        rename_map = {

            # Bond level
            "PAR_VAL": "Par value",
            "CPN": "Coupon",
            "COUPON_RATE": "Coupon rate",
            "TTM": "Time to maturity",
            "YTM": "Yield to maturity",
            "DURATION_MAC": "Macaulay duration",
            "DURATION_MOD": "Modified duration",
            "CONVEXITY": "Convexity",
            "MID_PRICE": "Mid price",
            "DIRTY_PRICE": "Dirty price",
            "BID_PRICE": "Bid price",
            "ASK_PRICE": "Ask price",
            "ISSUE_YEAR": "Issue year",
            "MATURITY_YEAR": "Maturity year",
            "OBS_YEAR": "Observation year",
            "OBS_MONTH": "Observation month",
            "BA_SPREAD": "Bid-ask spread",
            "ZR_PROXY": "Zero-return proxy",
            "AGE_YEARS": "Age (years)",
            "SIZE": "Size proxy",
            "SENIOR_DUMMY": "Seniority (Senior = 1)",

            # ==============================
            # Global & Emerging macro (MA3)
            # ==============================
            "MA3_VIX_INDEX": "MA(3m) VIX",
            "MA3_UKX_INDEX": "MA(3m) UKX",
            "MA3_MOVE_INDEX": "MA(3m) MOVE",
            "MA3_STOXX600": "MA(3m) STOXX 600",
            "MA3_SP500": "MA(3m) S&P 500",

            "MA3_BFCIUS_INDEX": "MA(3m) US financial conditions",
            "MA3_BFCIEU_INDEX": "MA(3m) EU financial conditions",

            "MA3_CDX_IG_CDSI_GEN_5Y_CORP": "MA(3m) CDX IG 5Y",
            "MA3_ITRX_EUR_CDSI_GEN_5Y_CORP": "MA(3m) iTraxx EUR 5Y",

            "MA3_GDP_CQOQ_INDEX": "MA(3m) GDP qoq",
            "MA3_EUGNEMUQ_INDEX": "MA(3m) Euro area growth",
            "MA3_CPI_YOY_INDEX": "MA(3m) CPI yoy",
            "MA3_ECCPEMUY_INDEX": "MA(3m) Euro area CPI",

            "MA3_MSCI_EM": "MA(3m) MSCI EM",
            "MA3_JPM_EMBI": "MA(3m) JPM EMBI",
            "MA3_EPUCEMEC_INDEX": "MA(3m) EM policy uncertainty",
            "MA3_CAFZUUEM_INDEX": "MA(3m) EM financial conditions",

            # ==============================
            # Alternative / Climate / ILS
            # ==============================
            "MA3_AONILS_INDEX": "MA(3m) ILS returns",

            "MA3_GLCRPCR_INDEX": "MA(3m) Global climate risk (PCR)",
            "MA3_GLCRCBV_INDEX": "MA(3m) Global climate risk (CBV)",
            "MA3_GLCRNCB_INDEX": "MA(3m) Global climate risk (NCB)",

            "MA3_GCILMANM_INDEX": "MA(3m) Climate risk – Manufacturing",
            "MA3_GCILNATL_INDEX": "MA(3m) Climate risk – Natural capital",

            # "MA3_CRPTBRAZ_INDEX": "MA(3m) Risk – Brazil",
            # "MA3_CRPTCHIN_INDEX": "MA(3m) Risk – China",
            # "MA3_CRPTHOKO_INDEX": "MA(3m) Risk – Hong Kong",
            # "MA3_CRPTMEXI_INDEX": "MA(3m) Risk – Mexico",
            # "MA3_CRPTKORE_INDEX": "MA(3m) Risk – Korea",
            # "MA3_CRPTINDI_INDEX": "MA(3m) Risk – India",
            # "MA3_CRPTUNAE_INDEX": "MA(3m) Risk – UAE",
        }


        if feature_name.startswith("CCY_"):
            return feature_name.replace("CCY_", "Currency: ")

        return rename_map.get(feature_name, feature_name)

    def _feature_group(self, feature_name):
        """Return economic grouping for plotting."""
        raw = feature_name
        if raw.startswith("num__"):
            raw = raw.replace("num__", "")
        if raw.startswith("cat__"):
            raw = raw.replace("cat__", "")

        if raw.startswith("CCY_"):
            return "Currency level"
        if raw in self.bond_feature_list:
            return "Bond characteristics"
        if raw in self.global_feature_list:
            return "Global indicators"
        if raw in self.emerging_feature_list:
            return "Emerging indicators"
        if raw in self.alternative_feature_list:
            return "Alternative data"

        return "Other"

    def _aggregate_feature_display(self, df_features):
        """
        Aggregate displayed features so grouped variables appear under one label.
        Uses the lowest p-value representative inside each group.
        """
        df_plot = df_features.copy()
        df_plot["Feature"] = df_plot["Feature"].apply(self._clean_feature_name)
        df_plot["Feature_Group"] = df_plot["Feature_Raw"].apply(self._feature_group)

        df_plot = (
            df_plot.sort_values("P_value")
            .groupby("Feature", as_index=False)
            .first()
            .sort_values("P_value")
        )

        return df_plot

    def _prepare_feature_plot_df(self, df_features):
        """
        If group_feature_display=True:
            aggregate display labels
        else:
            keep all raw features and color by economic group
        """
        df_plot = df_features.copy()
        df_plot["Feature_Clean"] = df_plot["Feature"].apply(self._clean_feature_name)
        df_plot["Feature_Group"] = df_plot["Feature"].apply(self._feature_group)

        if self.group_feature_display:
            df_plot = df_plot.rename(columns={"Feature": "Feature_Raw"})
            df_plot["Feature"] = df_plot["Feature_Clean"]
            df_plot = self._aggregate_feature_display(df_plot)
        else:
            df_plot["Feature_Raw"] = df_plot["Feature"]
            df_plot["Feature"] = df_plot["Feature_Clean"]
            df_plot = df_plot.sort_values("P_value").reset_index(drop=True)

        df_plot["Significance"] = np.select(
            [
                df_plot["P_value"] <= 0.05,
                df_plot["P_value"] <= 0.10,
                df_plot["P_value"] <= 0.15,
            ],
            ["5%", "10%", "15%"],
            default="Not significant",
        )

        # pattern for significance
        df_plot["Pattern"] = np.where(
            df_plot["Significance"] == "Not significant", "/", ""
        )

        return df_plot

    # ==================================================
    # COLLINEARITY ANALYSIS
    # ==================================================
    def _compute_vif(self, df_numeric):
        """Compute VIF table on numeric explanatory variables."""
        X_vif = df_numeric.copy()

        valid_cols = [c for c in X_vif.columns if X_vif[c].std(skipna=True) > 1e-12]
        X_vif = X_vif[valid_cols]

        if X_vif.shape[1] == 0:
            return pd.DataFrame(columns=["Feature", "VIF"])

        vif_values = []
        for i, col in enumerate(X_vif.columns):
            try:
                vif_val = variance_inflation_factor(X_vif.values, i)
            except Exception:
                vif_val = np.nan
            vif_values.append({"Feature": col, "VIF": vif_val})

        return (
            pd.DataFrame(vif_values)
            .sort_values("VIF", ascending=False)
            .reset_index(drop=True)
        )

    def run_collinearity_analysis(self, df, numeric_features):
        """
        Run correlation analysis + VIF.
        If remove_collinear=True, remove variables automatically.
        """
        numeric_features = [c for c in numeric_features if c in df.columns]
        df_num = df[numeric_features].copy()

        for col in df_num.columns:
            df_num[col] = pd.to_numeric(df_num[col], errors="coerce")
            df_num[col] = df_num[col].fillna(df_num[col].mean())

        self.corr_matrix = df_num.corr()

        corr_pairs = []
        corr_abs = self.corr_matrix.abs()

        for i in range(len(corr_abs.columns)):
            for j in range(i + 1, len(corr_abs.columns)):
                c1 = corr_abs.columns[i]
                c2 = corr_abs.columns[j]
                val = corr_abs.iloc[i, j]
                if pd.notna(val) and val >= self.corr_threshold:
                    corr_pairs.append(
                        {
                            "Feature_1": c1,
                            "Feature_2": c2,
                            "Abs_Correlation": val,
                        }
                    )

        self.high_corr_pairs = (
            pd.DataFrame(corr_pairs)
            .sort_values("Abs_Correlation", ascending=False)
            .reset_index(drop=True)
            if corr_pairs
            else pd.DataFrame(columns=["Feature_1", "Feature_2", "Abs_Correlation"])
        )

        selected_numeric = numeric_features.copy()

        if self.remove_collinear and not self.high_corr_pairs.empty:
            corr_drop = set()
            y_abs_corr = df_num[selected_numeric].corrwith(self.y).abs()

            for _, row in self.high_corr_pairs.iterrows():
                f1 = row["Feature_1"]
                f2 = row["Feature_2"]

                if f1 in corr_drop or f2 in corr_drop:
                    continue
                if f1 not in selected_numeric or f2 not in selected_numeric:
                    continue

                c1 = y_abs_corr.get(f1, np.nan)
                c2 = y_abs_corr.get(f2, np.nan)

                if pd.isna(c1) and pd.isna(c2):
                    drop_feature = f2
                elif pd.isna(c1):
                    drop_feature = f1
                elif pd.isna(c2):
                    drop_feature = f2
                else:
                    drop_feature = f1 if c1 < c2 else f2

                corr_drop.add(drop_feature)

            self.dropped_corr_features = sorted(list(corr_drop))
            selected_numeric = [c for c in selected_numeric if c not in corr_drop]

        df_vif_work = df_num[selected_numeric].copy()

        if self.remove_collinear:
            dropped_vif = []

            while True:
                vif_df = self._compute_vif(df_vif_work)

                if vif_df.empty:
                    break

                max_row = vif_df.iloc[0]
                max_vif = max_row["VIF"]
                max_feature = max_row["Feature"]

                if (
                    pd.isna(max_vif)
                    or max_vif <= self.vif_threshold
                    or df_vif_work.shape[1] <= 1
                ):
                    break

                dropped_vif.append(max_feature)
                df_vif_work = df_vif_work.drop(columns=[max_feature])

            self.dropped_vif_features = dropped_vif
            self.vif_table = self._compute_vif(df_vif_work)
            selected_numeric = list(df_vif_work.columns)

        else:
            self.vif_table = self._compute_vif(df_vif_work)

        print("\n=== COLLINEARITY ANALYSIS ===")
        print(f"Correlation threshold: {self.corr_threshold}")
        print(f"VIF threshold: {self.vif_threshold}")
        print(f"Remove collinear variables: {self.remove_collinear}")

        if self.high_corr_pairs is not None and not self.high_corr_pairs.empty:
            print("\nTop highly correlated pairs:")
            print(self.high_corr_pairs.head(15).to_string(index=False))
        else:
            print("\nNo feature pairs above the correlation threshold.")

        if self.vif_table is not None and not self.vif_table.empty:
            print("\nTop VIF values:")
            print(self.vif_table.head(15).to_string(index=False))
        else:
            print("\nVIF table is empty.")

        if self.remove_collinear:
            print("\nDropped by correlation filter:")
            print(self.dropped_corr_features if self.dropped_corr_features else "None")

            print("\nDropped by VIF filter:")
            print(self.dropped_vif_features if self.dropped_vif_features else "None")

        return selected_numeric

    def plot_correlation_matrix(self):
        """Plot correlation heatmap for numeric explanatory variables."""
        if self.corr_matrix is None or self.corr_matrix.empty:
            print("⚠️ Correlation matrix not available.")
            return

        fig = px.imshow(
            self.corr_matrix,
            color_continuous_scale="RdBu_r",
            zmin=-1,
            zmax=1,
            title="Correlation Matrix of Numeric Explanatory Variables",
        )
        fig.update_layout(template="plotly_white", width=950, height=800)
        fig.show()

    # ==================================================
    # PREPROCESS
    # ==================================================
    def preprocess_data(self):
        """Prepare features and target for regression."""
        df = self.df.copy()

        # ==============================
        # SENIORITY DUMMY
        # ==============================
        if "SENIORITY" in df.columns:
            df["SENIORITY"] = df["SENIORITY"].astype(str).str.upper().str.strip()

            senior_set = {"SNPR", "SENR", "SECR"}

            df["SENIOR_DUMMY"] = np.where(
                df["SENIORITY"].isin(senior_set),
                1.0,
                0.0
            )

            # Optional: set missing / unknown as NaN
            df.loc[~df["SENIORITY"].isin(senior_set | {"T2", "SUB"}), "SENIOR_DUMMY"] = np.nan

            print(
                "\n✅ SENIOR_DUMMY created:"
                f"\n{df['SENIOR_DUMMY'].value_counts(dropna=False)}"
            )

        df = self._clean_all_numeric(df)

        if "ISSUE_DT" in df.columns:
            df["ISSUE_YEAR"] = df["ISSUE_DT"].dt.year
        if "MATURITY_DT" in df.columns:
            df["MATURITY_YEAR"] = df["MATURITY_DT"].dt.year
        if "DATE" in df.columns:
            df["OBS_YEAR"] = df["DATE"].dt.year
            df["OBS_MONTH"] = df["DATE"].dt.month

        self.df = df
        self.add_derived_features()
        df = self.df.copy()

        if self.target_col not in df.columns:
            raise ValueError(f"❌ Target column '{self.target_col}' not found in dataset.")

        df[self.target_col] = pd.to_numeric(df[self.target_col], errors="coerce")
        df = df.dropna(subset=[self.target_col])

        rows_before_ba = len(df)
        df = df.dropna(subset=["BA_SPREAD"])
        rows_after_ba = len(df)

        print(
            f"\n🧹 Dropped {rows_before_ba - rows_after_ba} rows with empty BA_SPREAD "
            f"({rows_after_ba} rows remain)"
        )

        bond_features = ["CCY"] + [c for c in self.bond_feature_list if c in df.columns]
        global_features = [c for c in self.global_feature_list if c in df.columns]
        emerging_features = [c for c in self.emerging_feature_list if c in df.columns]
        alternative_features = [c for c in self.alternative_feature_list if c in df.columns]

        features = bond_features + global_features + emerging_features + alternative_features
        features = list(dict.fromkeys(features))

        if not features:
            raise ValueError("❌ No usable feature columns found in dataset.")

        numeric_candidate_features = [c for c in features if c != "CCY"]

        for col in numeric_candidate_features:
            df[col] = pd.to_numeric(df[col], errors="coerce")
            df[col] = df[col].fillna(df[col].mean())

        if "CCY" in df.columns:
            df["CCY"] = df["CCY"].fillna("UNKNOWN")

        self.y = pd.to_numeric(df[self.target_col], errors="coerce").astype(float).copy()

        selected_numeric_features = self.run_collinearity_analysis(
            df, numeric_candidate_features
        )

        categorical_features = [c for c in ["CCY"] if c in df.columns]
        final_features = categorical_features + selected_numeric_features

        self.selected_features = final_features
        self.numeric_features_final = selected_numeric_features
        self.categorical_features_final = categorical_features

        self.X = df[final_features].copy()

        print(f"\n✅ After cleaning: {len(df)} rows remain")
        print(f"🔍 X shape: {self.X.shape}")
        print(f"🔍 y shape: {self.y.shape}")
        print(f"🔍 Final numeric features: {len(self.numeric_features_final)}")
        print(f"🔍 Final categorical features: {len(self.categorical_features_final)}")
        print(f"🔍 Group feature display: {self.group_feature_display}")

        transformers = []
        if self.numeric_features_final:
            transformers.append(("num", StandardScaler(), self.numeric_features_final))
        if self.categorical_features_final:
            transformers.append(
                (
                    "cat",
                    OneHotEncoder(drop="first", handle_unknown="ignore"),
                    self.categorical_features_final,
                )
            )

        self.preprocessor = ColumnTransformer(transformers=transformers)

        if self.X.empty or self.y.empty:
            raise ValueError("❌ No data available after preprocessing.")

    # ==================================================
    # LINEAR REGRESSION
    # ==================================================
    def run_linear_regression(self):
        """Run OLS regression using statsmodels for p-values."""
        X_train, X_test, y_train, y_test = train_test_split(
            self.X, self.y, test_size=0.2, random_state=42
        )

        X_train_proc = self.preprocessor.fit_transform(X_train)
        X_test_proc = self.preprocessor.transform(X_test)

        if hasattr(X_train_proc, "toarray"):
            X_train_proc = X_train_proc.toarray()
            X_test_proc = X_test_proc.toarray()

        X_train_sm = sm.add_constant(X_train_proc)
        X_test_sm = sm.add_constant(X_test_proc)

        model = sm.OLS(y_train, X_train_sm).fit()
        y_pred = model.predict(X_test_sm)

        self.models["Linear"] = (model, X_test, y_test, y_pred)
        self.results["Linear Regression"] = {
            "R2": r2_score(y_test, y_pred),
            "RMSE": np.sqrt(mean_squared_error(y_test, y_pred)),
        }

        print(model.summary())

    # ==================================================
    # LOGISTIC REGRESSION
    # ==================================================
    def run_logistic_regression(self):
        """Binary logistic: top Z-spread quartile vs others."""
        df_target = pd.DataFrame({self.target_col: self.y})
        df_target["Quartile"] = pd.qcut(
            df_target[self.target_col], 4, labels=False, duplicates="drop"
        )

        if df_target["Quartile"].nunique() < 2:
            raise ValueError(
                "❌ Not enough variation in target to build quartiles for logistic regression."
            )

        y_binary = (df_target["Quartile"] == df_target["Quartile"].max()).astype(int)

        X_train, X_test, y_train, y_test = train_test_split(
            self.X, y_binary, test_size=0.2, random_state=42
        )

        X_train = X_train.reset_index(drop=True)
        X_test = X_test.reset_index(drop=True)
        y_train = y_train.reset_index(drop=True)
        y_test = y_test.reset_index(drop=True)

        X_train_proc = self.preprocessor.fit_transform(X_train)
        X_test_proc = self.preprocessor.transform(X_test)

        feature_names = self.preprocessor.get_feature_names_out()

        if hasattr(X_train_proc, "toarray"):
            X_train_proc = X_train_proc.toarray()
            X_test_proc = X_test_proc.toarray()

        X_train_df = pd.DataFrame(X_train_proc, columns=feature_names)
        X_test_df = pd.DataFrame(X_test_proc, columns=feature_names)

        X_train_df = X_train_df.loc[:, X_train_df.std() > 1e-8]
        X_train_df = X_train_df.loc[:, ~X_train_df.columns.duplicated()]
        X_test_df = X_test_df[X_train_df.columns]

        X_train_sm = sm.add_constant(X_train_df, has_constant="add")
        X_test_sm = sm.add_constant(X_test_df, has_constant="add")

        try:
            model = sm.Logit(y_train, X_train_sm).fit(disp=False)
        except np.linalg.LinAlgError:
            print("⚠️ Singular matrix detected — applying regularized fit.")
            model = sm.Logit(y_train, X_train_sm).fit_regularized(
                method="l1", alpha=1e-4, disp=False
            )

        y_pred_prob = model.predict(X_test_sm)
        y_pred = (y_pred_prob >= 0.5).astype(int)

        self.models["Logistic"] = (model, X_test, y_test, y_pred)
        self.results["Logistic Regression"] = {
            "Accuracy": accuracy_score(y_test, y_pred),
            "Classification Report": classification_report(
                y_test, y_pred, output_dict=True
            ),
        }

        print(model.summary())

    # ==================================================
    # PLOTS
    # ==================================================
    def plot_results(self):
        """Plot regression results using Plotly."""
        if "Linear" in self.models:
            _, _, y_test, y_pred = self.models["Linear"]

            fig = go.Figure()
            fig.add_trace(
                go.Scatter(
                    x=y_test,
                    y=y_pred,
                    mode="markers",
                    marker=dict(size=6, opacity=0.7),
                    name="Fitted values",
                )
            )
            fig.add_trace(
                go.Scatter(
                    x=y_test,
                    y=y_test,
                    mode="lines",
                    name="45° line",
                )
            )
            fig.update_layout(
                title="Linear Regression: Fitted vs Observed Z-Spread",
                xaxis_title="Observed Z-Spread (bps)",
                yaxis_title="Fitted Z-Spread (bps)",
                template="plotly_white",
                width=800,
                height=500,
            )
            fig.show()

        if "Logistic" in self.models:
            _, _, y_test, y_pred = self.models["Logistic"]
            cm = confusion_matrix(y_test, y_pred)

            fig = px.imshow(
                cm,
                text_auto=True,
                color_continuous_scale="Blues",
                labels=dict(x="Estimated class", y="Observed class", color="Count"),
                title="Logistic Regression: Classification Matrix (Top Quartile Z-Spread vs Others)",
            )
            fig.update_layout(template="plotly_white", width=600, height=500)
            fig.show()

    # ==================================================
    # FEATURE SIGNIFICANCE PLOTS (with Alternative Data)
    # ==================================================
    def plot_feature_importance(self):
        """Plot feature significance with 2 levels inside the same figure, including Alternative Data."""
        significance_color_map = {
            "5%": "#003f88",
            "10%": "#1f77b4",
            "15%": "#7fb3d5",
            "Not significant": "#d62728",
        }

        # Add new color for Alternative Data
        feature_group_color_map = {
            "Bond characteristics": "#003f88",
            "Global indicators": "#1f77b4",
            "Emerging indicators": "#7fb3d5",
            "Alternative data": "#ff7f0e",
            "Currency level": "#6a4c93",
            "Other": "#999999",
        }

        def _split_dataframe_two_levels(df_plot):
            n = len(df_plot)
            if n <= 1:
                return df_plot.copy(), pd.DataFrame(columns=df_plot.columns)

            split_idx = int(np.ceil(n / 2))
            df_top = df_plot.iloc[:split_idx].copy()
            df_bottom = df_plot.iloc[split_idx:].copy()
            return df_top, df_bottom

        def _build_single_2level_figure(df_plot, title):
            df_top, df_bottom = _split_dataframe_two_levels(df_plot)

            fig = make_subplots(
                rows=2,
                cols=1,
                shared_yaxes=True,
                vertical_spacing=0.16,
                subplot_titles=("Level 1", "Level 2"),
            )

            # Choose color scheme
            if self.group_feature_display:
                color_col = "Significance"
                color_map = significance_color_map
            else:
                color_col = "Feature_Group"
                color_map = feature_group_color_map

            def _add_traces(df_chunk, row, showlegend):
                if df_chunk.empty:
                    return

                unique_colors = list(df_chunk[color_col].dropna().unique())
                pattern_values = ["", "/"]

                for color_value in unique_colors:
                    for pattern_value in pattern_values:
                        tmp = df_chunk[
                            (df_chunk[color_col] == color_value)
                            & (df_chunk["Pattern"] == pattern_value)
                        ].copy()

                        if tmp.empty:
                            continue

                        trace_name = (
                            f"{color_value} | Not significant"
                            if pattern_value == "/"
                            else str(color_value)
                        )

                        fig.add_trace(
                            go.Bar(
                                x=tmp["Feature"],
                                y=tmp["Coefficient"],
                                name=trace_name,
                                marker_color=color_map.get(color_value, "#999999"),
                                marker_pattern_shape=pattern_value,
                                showlegend=showlegend,
                                legendgroup=trace_name,
                                customdata=np.stack(
                                    [
                                        tmp["P_value"],
                                        tmp["Feature_Group"],
                                        tmp["Significance"],
                                    ],
                                    axis=-1,
                                ),
                                hovertemplate=(
                                    "Feature: %{x}<br>"
                                    "Coefficient: %{y:.4f}<br>"
                                    "P-value: %{customdata[0]:.4f}<br>"
                                    "Group: %{customdata[1]}<br>"
                                    "Significance: %{customdata[2]}<extra></extra>"
                                ),
                            ),
                            row=row,
                            col=1,
                        )

            _add_traces(df_top, row=1, showlegend=True)
            _add_traces(df_bottom, row=2, showlegend=False)

            fig.update_layout(
                template="plotly_white",
                title=title,
                height=950,
                width=1400,
                barmode="group",
            )

            fig.update_xaxes(title_text="Feature", tickangle=45, row=1, col=1)
            fig.update_xaxes(title_text="Feature", tickangle=45, row=2, col=1)
            fig.update_yaxes(title_text="Coefficient", row=1, col=1)
            fig.update_yaxes(title_text="Coefficient", row=2, col=1)

            fig.show()

        # ---------------- Linear ----------------
        if "Linear" in self.models:
            model = self.models["Linear"][0]
            features = self.preprocessor.get_feature_names_out()

            df_lin = pd.DataFrame({
                "Feature": features,
                "Coefficient": model.params[1:],
                "P_value": model.pvalues[1:],
            })

            df_lin = self._prepare_feature_plot_df(df_lin)
            _build_single_2level_figure(
                df_lin,
                "Feature Significance – Linear Regression (Including Alternative Data)"
            )

        # ---------------- Logistic ----------------
        if "Logistic" in self.models:
            model = self.models["Logistic"][0]

            df_log = pd.DataFrame({
                "Feature": model.params.index[1:],
                "Coefficient": model.params[1:],
                "P_value": model.pvalues[1:],
            })

            df_log = self._prepare_feature_plot_df(df_log)
            _build_single_2level_figure(
                df_log,
                "Feature Significance – Logistic Regression (Including Alternative Data)"
            )

    # ==================================================
    # RUN ALL
    # ==================================================
    def run_all(self, show_corr_plot=False):
        self.load_data()
        self.preprocess_data()

        if show_corr_plot:
            self.plot_correlation_matrix()

        self.run_linear_regression()
        self.run_logistic_regression()
        self.plot_results()
        self.plot_feature_importance()

        return pd.DataFrame(self.results).T


# ==================================================
# MAIN
# ==================================================
if __name__ == "__main__":
    regressor = BondRiskRegressor(
        data_path=Z_SPREADS,
        target_col="Z_SPREAD_BPS",
        sheet_name=0,
        remove_collinear=False,
        corr_threshold=0.85,
        vif_threshold=10.0,
        group_feature_display=False,   # True = grouped labels, False = raw features colored by group
    )

    df_results = regressor.run_all(show_corr_plot=True)

    print("\n=== Regression Results Summary ===")
    print(df_results)

    print("\n=== Final VIF Table ===")
    print(regressor.vif_table)

    print("\n=== Highly Correlated Pairs ===")
    print(regressor.high_corr_pairs.head(20))

# %%
