# %% LOADING DATABASE CLASS
# ==========================================================
# Author: Amin Tarbouch
# ==========================================================

from pathlib import Path
import pandas as pd
from sqlalchemy import create_engine, inspect, text
import os
from path_config import DATABASE


class MasterDataset:
    """
    Lightweight manager for the Master SQLite dataset.

    Features
    --------
    - Load any table or view from the SQLite database
    - List tables and views
    - Preview data stored in the DB
    - Convenience accessors for key datasets
    - Robust fallback to local copy if network path fails
    """

    def __init__(self, db_path: str | Path | None = None):
        # Preferred network path
        network_path = DATABASE

        # Local fallback path
        local_path = Path(os.environ["LOCALAPPDATA"]) / DATABASE.name

        # Determine which path to use
        if db_path:
            self.db_path = Path(db_path)
        elif network_path.exists():
            self.db_path = network_path
        elif local_path.exists():
            self.db_path = local_path
            print(f"⚠️ Network path not found. Using local copy: {local_path}")
        else:
            raise FileNotFoundError(
                f"❌ Database not found at either:\n{network_path}\n{local_path}"
            )

        # Try connecting to the database
        try:
            self.engine = create_engine(f"sqlite:///{self.db_path}", future=True)
            # Test connection
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            print(f"📦 Connected to DB: {self.db_path}")
        except Exception as e:
            raise ConnectionError(f"❌ Failed to connect to database: {e}")

    # --------------------------------------------------
    # Internal helpers
    # --------------------------------------------------
    def _inspector(self):
        return inspect(self.engine)

    def _object_exists(self, object_name: str) -> bool:
        inspector = self._inspector()
        tables = inspector.get_table_names()
        views = inspector.get_view_names()
        return object_name in tables or object_name in views

    def _validate_object(self, object_name: str) -> None:
        if not self._object_exists(object_name):
            available = self.list_db_objects()
            raise ValueError(
                f"Object '{object_name}' not found in database.\n\n"
                f"Available objects:\n{available.to_string(index=False)}"
            )

    # --------------------------------------------------
    # Core loaders
    # --------------------------------------------------
    def load_table(self, table_name: str, where: str | None = None) -> pd.DataFrame:
        """Load a full table/view or a filtered subset using a SQL WHERE clause."""
        self._validate_object(table_name)
        query = f'SELECT * FROM "{table_name}"'
        if where:
            query += f" WHERE {where}"
        return pd.read_sql(text(query), self.engine)

    def preview(self, object_name: str, limit: int = 5) -> pd.DataFrame:
        """Preview the first `limit` rows of a table/view."""
        self._validate_object(object_name)
        query = text(f'SELECT * FROM "{object_name}" LIMIT :limit')
        return pd.read_sql(query, self.engine, params={"limit": limit})

    def query(self, sql: str, params: dict | None = None) -> pd.DataFrame:
        """Run a custom SQL query."""
        return pd.read_sql(text(sql), self.engine, params=params or {})

    # --------------------------------------------------
    # DB structure / metadata
    # --------------------------------------------------
    def list_tables(self) -> pd.DataFrame:
        inspector = self._inspector()
        return pd.DataFrame({"name": inspector.get_table_names(), "type": "table"})

    def list_views(self) -> pd.DataFrame:
        inspector = self._inspector()
        return pd.DataFrame({"name": inspector.get_view_names(), "type": "view"})

    def list_db_objects(self) -> pd.DataFrame:
        df = pd.concat([self.list_tables(), self.list_views()], ignore_index=True)
        return df.sort_values(["type", "name"]).reset_index(drop=True)

    def schema(self, object_name: str) -> pd.DataFrame:
        self._validate_object(object_name)
        query = text(f'PRAGMA table_info("{object_name}")')
        return pd.read_sql(query, self.engine)

    def db_overview(self, preview_rows: int = 3) -> dict[str, pd.DataFrame]:
        """Return a dictionary with all objects and previews."""
        objects = self.list_db_objects()
        overview = {"objects": objects}
        for name in objects["name"]:
            try:
                overview[name] = self.preview(name, limit=preview_rows)
            except Exception as e:
                overview[name] = pd.DataFrame({"error": [str(e)]})
        return overview

    # --------------------------------------------------
    # Convenience accessors
    # --------------------------------------------------
    def em_bonds(self) -> pd.DataFrame:
        """Load the impact bonds dataset."""
        return self.load_table("em_bonds")

    def macro(self) -> pd.DataFrame:
        """Load the macro dataset."""
        df = self.load_table("macro")
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
            df = df.sort_values("date")
        return df

    def list_rfr_tables(self) -> pd.DataFrame:
        """List all RFR-related tables."""
        return pd.read_sql(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'rfr_%'",
            self.engine
        )

    def load_rfr_table(self, name: str) -> pd.DataFrame:
        """Load a specific RFR table by name."""
        df = self.load_table(name)
        if "date" in df.columns:
            df["date"] = pd.to_datetime(df["date"], errors="coerce")
            df = df.sort_values("date")
        return df


# ==========================================================
# USAGE
# ==========================================================
if __name__ == "__main__":

    db = MasterDataset()

    # 1) List all tables
    df_objects = db.list_db_objects()
    print("\n=== DATABASE OBJECTS ===")
    print(df_objects)

    # 2) Preview a specific object
    print("\n=== PREVIEW em_bonds ===")
    print(db.preview("em_bonds", limit=5))

    # 3) Load datasets
    df_bonds = db.em_bonds()
    df_macro = db.macro()

    print("\n=== em_bonds shape ===")
    print(df_bonds.shape)

    print("\n=== macro shape ===")
    print(df_macro.shape)

    # 4) List and preview RFR tables
    print("\n=== RFR TABLES ===")
    print(db.list_rfr_tables())

    # Example: load one RFR table
    rfr_tables = db.list_rfr_tables()["name"].tolist()
    if rfr_tables:
        df_rfr_sample = db.load_rfr_table(rfr_tables[0])
        print(f"\n=== PREVIEW {rfr_tables[0]} ===")
        print(df_rfr_sample.head())

# %%
