"""Single source of truth for project data paths and filenames."""

from __future__ import annotations

import os
from pathlib import Path


# Override this once with THESIS_DATA_DIR when the dataset moves.
DATA_DIR = Path(os.getenv(
    "THESIS_DATA_DIR",
    r"\\ad-its.credit-agricole.fr\dfs\HOMEDIRS\AMUNDI\tarbouch\Desktop\MASTER_THESIS\DATASET\thesis_dataset",
))
INPUT_DIR = DATA_DIR / "INPUT"
OUTPUT_DIR = DATA_DIR / "OUTPUT"

# Inputs
BBG_BONDS = INPUT_DIR / "DATASET_BBG_EMUSTRUU.xlsx"
MACRO = INPUT_DIR / "DATASET_MACRO.xlsx"
RFR = INPUT_DIR / "DATASET_RFR.xlsx"
FX_LATAM = INPUT_DIR / "DATASET_FX_RATES_LATAM.xlsx"
GPR = INPUT_DIR / "DATASET_GPR.xls"
DATABASE = INPUT_DIR / "master_dataset.db"

# Outputs
FX_RATES = OUTPUT_DIR / "DATASET_FX_RATES.xlsx"
FEATURE_ENGINEERED = OUTPUT_DIR / "model_master_dataset_features_engineering.xlsx"
SOFR_CURVE = OUTPUT_DIR / "sofr_zero_curve_timeseries.xlsx"
Z_SPREADS = OUTPUT_DIR / "bond_z_spreads.xlsx"
SELECTED_FEATURES = OUTPUT_DIR / "selected_features.csv"
MASTER = OUTPUT_DIR / "MASTER.xlsx"
MASTER_clean = OUTPUT_DIR / "MASTER_clean.xlsx"

DEFAULT_SHEET = "Worksheet"

DATABASE_EXCEL_CONFIG = {
    BBG_BONDS.name: {"mode": "first_sheet", "table_prefix": "em_bonds"},
    MACRO.name: {"mode": "first_sheet", "table_prefix": "macro"},
    RFR.name: {"mode": "all_sheets", "table_prefix": "rfr"},
}
