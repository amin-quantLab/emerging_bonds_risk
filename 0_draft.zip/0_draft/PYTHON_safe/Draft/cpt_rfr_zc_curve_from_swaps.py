# %% BUILD SOFR CURVE TIME SERIES (DB-INTEGRATED)
# ==========================================================
# Author: Amin Tarbouch
# ==========================================================

import datetime as dt
import pandas as pd
import QuantLib as ql
import plotly.graph_objects as go
from pathlib import Path
from reader_db_fct import MasterDataset
from path_config import SOFR_CURVE

class SOFRSwapCurveBuilder:
    """
    Bootstraps a risk-free discount curve from SOFR swap mid prices.
    """

    def __init__(self, valuation_date, swap_tenors, swap_rates):
        self.valuation_date = ql.Date(valuation_date.day, valuation_date.month, valuation_date.year)
        self.swap_tenors = swap_tenors
        self.swap_rates = swap_rates
        self.curve = None
        ql.Settings.instance().evaluationDate = self.valuation_date

    def build_curve(self):
        """Bootstraps the SOFR discount curve."""
        calendar = ql.UnitedStates(ql.UnitedStates.GovernmentBond)
        day_count = ql.Actual360()
        float_leg_index = ql.Sofr()

        helpers = []
        for tenor, rate in zip(self.swap_tenors, self.swap_rates):
            maturity = ql.Period(tenor)
            quote = ql.QuoteHandle(ql.SimpleQuote(rate / 100))
            helper = ql.OISRateHelper(2, maturity, quote, float_leg_index)
            helpers.append(helper)

        self.curve = ql.PiecewiseLogCubicDiscount(self.valuation_date, helpers, day_count)
        return self.curve

    def get_zero_rate(self, maturity_date):
        if self.curve is None:
            raise ValueError("Curve not built yet. Call build_curve() first.")
        return self.curve.zeroRate(maturity_date, ql.Actual365Fixed(), ql.Continuous).rate()


# ==========================================================
# MAIN PIPELINE (DB → CURVE TIME SERIES → EXCEL)
# ==========================================================
if __name__ == "__main__":

    # --- Step 1: Load SOFR swap data from DB
    db = MasterDataset()
    df_sofr = db.load_rfr_table("rfr_sofr_(daily)")  # ✅ correct table name

    print(f"✅ Loaded SOFR (daily) dataset: {df_sofr.shape}")

    # --- Step 2: Clean and prepare data
    df_sofr.columns = df_sofr.columns.str.strip().str.replace(" ", "_").str.lower()

    # Detect date column
    date_candidates = [c for c in df_sofr.columns if "date" in c]
    if not date_candidates:
        raise ValueError(f"❌ No date column found in SOFR dataset. Columns: {df_sofr.columns.tolist()}")
    date_col = date_candidates[0]
    df_sofr["date"] = pd.to_datetime(df_sofr[date_col], errors="coerce")

    # Map columns to tenors
    tenor_map = {
        "usosfra_curncy": "1M",
        "usosfrc_curncy": "3M",
        "usosfr1_curncy": "1Y",
        "usosfr2_curncy": "2Y",
        "usosfr3_curncy": "3Y",
        "usosfr5_curncy": "5Y",
        "usosfr10_curncy": "10Y",
    }
    tenor_map = {k: v for k, v in tenor_map.items() if k in df_sofr.columns}
    if not tenor_map:
        raise ValueError(f"❌ None of the expected SOFR columns found. Columns: {df_sofr.columns.tolist()}")

    # --- Step 3: Build curves for each date
    df_curve_records = []

    all_dates = sorted(df_sofr["date"].dropna().unique())
    print(f"📅 Found {len(all_dates)} valuation dates.")

    for valuation_date in all_dates:
        df_day = df_sofr[df_sofr["date"] == valuation_date].copy()
        if df_day.empty:
            continue

        # Extract rates for this date
        swap_tenors = list(tenor_map.values())
        swap_rates = [df_day[col].values[0] for col in tenor_map.keys()]

        # Skip if any rate is missing
        if any(pd.isna(swap_rates)):
            continue

        # Build curve
        builder = SOFRSwapCurveBuilder(valuation_date.date(), swap_tenors, swap_rates)
        curve = builder.build_curve()

        # Compute zero rates for each tenor
        for tenor in swap_tenors:
            maturity_date = ql.UnitedStates(ql.UnitedStates.GovernmentBond).advance(builder.valuation_date, ql.Period(tenor))
            years = ql.Actual365Fixed().yearFraction(builder.valuation_date, maturity_date)
            zero_rate = builder.get_zero_rate(maturity_date) * 100

            df_curve_records.append({
                "Date": valuation_date.date(),
                "Tenor": tenor,
                "Maturity (Years)": years,
                "Zero Rate (%)": zero_rate
            })

    # --- Step 4: Build final DataFrame
    df_curve = pd.DataFrame(df_curve_records)
    print(f"✅ Built curve time series with {len(df_curve)} rows.")

    # --- Step 5: Export to Excel
    output_path = SOFR_CURVE
    df_curve.to_excel(output_path, index=False)

    print(f"📦 Excel file created with SOFR curve time series: {output_path}")

    # --- Optional: Plot latest curve
    latest_date = df_curve["Date"].max()
    df_latest = df_curve[df_curve["Date"] == latest_date]

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df_latest["Maturity (Years)"],
        y=df_latest["Zero Rate (%)"],
        mode='lines+markers',
        line=dict(color='royalblue', width=2),
        marker=dict(size=6),
        name=f'SOFR Zero Curve ({latest_date})'
    ))

    fig.update_layout(
        title=f'SOFR Risk-Free Yield Curve ({latest_date})',
        xaxis_title='Maturity (Years)',
        yaxis_title='Zero Rate (%)',
        template='plotly_white',
        font=dict(size=12),
        width=800,
        height=500
    )

    fig.show()

# %%
