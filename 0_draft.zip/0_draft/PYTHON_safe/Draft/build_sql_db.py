# %% BUILD SQLITE DATABASE FROM MASTER EXCELS (OOP VERSION)
# ==========================================================
# Author: Amin Tarbouch
# ==========================================================

import os
import shutil
import pandas as pd
from pathlib import Path
from sqlalchemy import create_engine
from path_config import DATABASE, DATABASE_EXCEL_CONFIG, INPUT_DIR


class MasterDatasetSQLBuilder:
    """
    Builds a local SQLite database from multiple Excel master datasets.
    """

    def __init__(
        self,
        base_path: Path,
        db_filename: str = DATABASE.name,
        excel_config: dict = None,
        copy_back: bool = True,
    ):
        self.base_path = base_path
        self.db_path = Path(os.environ["LOCALAPPDATA"]) / db_filename
        self.copy_back = copy_back

        self.engine = create_engine(f"sqlite:///{self.db_path}")

        self.excel_config = excel_config or {}

        print(f"📦 SQLite DB location: {self.db_path}")

    # --------------------------------------------------
    # Column cleaning utility
    # --------------------------------------------------
    @staticmethod
    def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
        df.columns = (
            df.columns
            .astype(str)
            .str.strip()
            .str.lower()
            .str.replace(" ", "_")
            .str.replace(r"[^\w]", "", regex=True)
        )
        return df

    # --------------------------------------------------
    # Load one Excel file according to config
    # --------------------------------------------------
    def process_excel_file(self, excel_file: str, config: dict):
        file_path = self.base_path / excel_file
        print(f"\n📄 Processing {excel_file}")

        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if config["mode"] == "first_sheet":
            df = pd.read_excel(file_path, sheet_name=0)
            df = self.clean_columns(df)

            table_name = config["table_prefix"]
            df.to_sql(
                table_name,
                self.engine,
                if_exists="replace",
                index=False,
            )

            print(f"  ✅ Loaded table `{table_name}` ({len(df)} rows)")

        elif config["mode"] == "all_sheets":
            sheets = pd.read_excel(file_path, sheet_name=None)

            for sheet_name, df in sheets.items():
                df = self.clean_columns(df)
                table_name = f"{config['table_prefix']}_{sheet_name.lower().replace(' ', '_')}"

                df.to_sql(
                    table_name,
                    self.engine,
                    if_exists="replace",
                    index=False,
                )

                print(f"  ✅ Loaded table `{table_name}` ({len(df)} rows)")

        else:
            raise ValueError(f"Unknown mode: {config['mode']}")

    # --------------------------------------------------
    # Build database from all Excel files
    # --------------------------------------------------
    def build_database(self):
        for excel_file, config in self.excel_config.items():
            self.process_excel_file(excel_file, config)

        print("\n✅ SQLite database successfully created")

        if self.copy_back:
            self.copy_database_back()

    # --------------------------------------------------
    # Copy DB back to dataset folder
    # --------------------------------------------------
    def copy_database_back(self):
        target_path = self.base_path / self.db_path.name
        shutil.copy(self.db_path, target_path)

        print(f"📁 Database copied back to: {target_path}")


# ==========================================================
# USAGE
# ==========================================================

if __name__ == "__main__":

    builder = MasterDatasetSQLBuilder(
        base_path=INPUT_DIR,
        excel_config=DATABASE_EXCEL_CONFIG,
        copy_back=True,
    )

    builder.build_database()

# %%
