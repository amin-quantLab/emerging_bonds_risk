# %% ALGO ANALYSIS OPTIMIZER

#!/usr/bin/env python3
"""
algo_analysis_optimizer.py
Regime-share-aware randomised search over the hyperparameter space of the
regime-aware risk decomposition pipeline.

Composite score (weights sum to 1.0):
    w_r2           : HMM-conditioned R²
    w_adj          : HMM-conditioned Adj-R²
    w_sig          : % significant coefficients p < 0.05
    w_persist      : average HMM self-transition probability
    w_regime_share : Regime component share of total abs. contribution  ★

Per-iteration output: one metrics DataFrame showing results
with and without the regime layer.

Optimisation plots (3):
    1. Timeline — score + regime share convergence
    2. R² with vs without regime + regime share scatter
    3. Hyperparameter × metric Spearman heatmap

Analysis plots (from RegimeRiskDecompositionPipeline.plot_all) are only
shown in the best-run re-run, not during the search.
"""

# ==========================================================
# Author: Amin Tarbouch
# ==========================================================

from __future__ import annotations

import io
import sys
import time
import contextlib
import traceback
import warnings
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error

try:
    from hmmlearn.hmm import GaussianHMM
    HMM_AVAILABLE = True
except Exception as exc:
    HMM_AVAILABLE    = False
    HMM_IMPORT_ERROR = exc

# ==========================================================
# Path resolution
# ==========================================================

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from path_config import (
    MASTER_clean,
    OUTPUT_DIR,
    DEFAULT_SHEET,
)

MASTER_CLEAN_PATH      : Path = OUTPUT_DIR / "MASTER_CLEAN.xlsx"
LATEX_OUTPUT_DIR       : Path = OUTPUT_DIR / "output_for_latex"
SELECTED_FEATURES_PATH : Path = LATEX_OUTPUT_DIR / "selected_features.csv"
MODEL_RESULTS_DIR      : Path = OUTPUT_DIR / "model_results"
OPTIMIZER_OUTPUT_DIR   : Path = OUTPUT_DIR / "optimizer_results"

warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=UserWarning)

try:
    from IPython.display import display
except Exception:
    display = print

print(f"path_config loaded        : OK")
print(f"Input  MASTER_CLEAN       : {MASTER_CLEAN_PATH}")
print(f"Input  selected_features  : {SELECTED_FEATURES_PATH}")
print(f"Output optimizer_results/ : {OPTIMIZER_OUTPUT_DIR}")

# ==========================================================
# Import shared utilities
# ==========================================================

from master_thesis_analysis import (
    is_allowed_model_input_feature,
    is_latam_specific_feature,
    compute_rmse,
    compute_mae,
    RiskDecompositionConfig,
    RegimeRiskDecompositionPipeline,
)

# ==========================================================
# Search space
# ==========================================================

HMM_CANDIDATE_POOL_LATAM: list[str] = [
    "MA3_VIX_INDEX", "MA3_MOVE_INDEX", "MA3_JPM_EMBI", "MA3_MSCI_EM",
    "MA3_BFCIUS_INDEX", "MA3_BFCIEU_INDEX", "MA3_GPR_LEVEL",
    "LATAM_CDS_CREDIT_RISK", "LATAM_JPM_SPREAD_CREDIT_RISK",
    "MA3_GPR_LATAM_MOMENTUM", "MA3_CDX_IG_CDSI_GEN_5Y_CORP",
    "MA3_ITRX_EUR_CDSI_GEN_5Y_CORP", "MA3_STOXX600", "MA3_SP500",
    "MA3_EPUCEMEC_INDEX", "MA3_AONILS_INDEX",
]

HMM_CANDIDATE_POOL_ALL_EM: list[str] = [
    f for f in HMM_CANDIDATE_POOL_LATAM
    if not is_latam_specific_feature(f)
]

SEARCH_SPACE: dict[str, list[Any]] = {
    "hmm_covariance_type":  ["diag", "full", "tied", "spherical"],
    "hmm_n_starts":         [10, 20, 30, 50],
    "hmm_max_features":     [4, 5, 6, 7, 8],
    "n_pca_components":     [2, 3, 4],
    "min_isins_per_period": [3, 5, 7],
    "min_regime_duration":  [2, 3, 4, 5],
    "ols_cov_type":         ["HC3", "HC1", "HC0"],
    "winsorize_lower":      [0.005, 0.01, 0.02],
    "winsorize_upper":      [0.98, 0.99, 0.995],
    "standardize_features": [True, False],
    "hmm_include_pc1":      [True, False],
    "n_features_to_drop":   [0, 0, 0, 5, 10, 15, 20],
}


# ==========================================================
# Composite score
# ==========================================================

def composite_score(
    r2_hmm:              float,
    adj_r2_hmm:          float,
    pct_significant:     float,
    avg_self_transition: float,
    regime_share:        float,
    w_r2:           float = 0.30,
    w_adj:          float = 0.15,
    w_sig:          float = 0.20,
    w_persist:      float = 0.10,
    w_regime_share: float = 0.25,
) -> float:
    """
    Weighted composite in [0, 1].
    regime_share carries the joint-largest weight (0.25 default) alongside R²
    (0.30), directly rewarding configurations where the HMM regime layer
    dominates the final decomposition — the central thesis claim.
    """
    c = lambda x: float(np.clip(x, 0.0, 1.0))
    return (
        w_r2             * c(r2_hmm)
        + w_adj          * c(adj_r2_hmm)
        + w_sig          * c(pct_significant)
        + w_persist      * c(avg_self_transition)
        + w_regime_share * c(regime_share)
    )


# ==========================================================
# Single-trial runner
# ==========================================================

def _run_single_trial(
    trial_id:      int,
    params:        dict[str, Any],
    base_features: list[str],
    hmm_pool:      list[str],
    universe_mode: str,
    use_latam:     bool,
    data_path:     str,
    features_path: str,
    rng:           np.random.Generator,
    score_weights: dict,
) -> dict[str, Any]:
    """
    Run one full pipeline in silent mode. Returns a result dict with
    status='ok' or status='error'.
    """
    result: dict[str, Any] = {
        "trial_id":              trial_id,
        "status":                "error",
        "score":                 np.nan,
        # with regime
        "hmm_r2":                np.nan,
        "hmm_adj_r2":            np.nan,
        "hmm_rmse":              np.nan,
        "hmm_mae":               np.nan,
        "pct_significant_p05":   np.nan,
        "pct_significant_p10":   np.nan,
        "regime_share":          np.nan,
        "avg_self_transition":   np.nan,
        "n_regimes_identified":  np.nan,
        # without regime
        "baseline_r2":           np.nan,
        "baseline_rmse":         np.nan,
        "latent_aug_r2":         np.nan,
        # marginal
        "regime_r2_gain":        np.nan,
        # latent
        "pc1_variance_share":    np.nan,
        # config
        "n_features_used":       np.nan,
        "hmm_features_used":     "",
        "error_message":         "",
        **{k: str(v) for k, v in params.items()},
    }

    tmp_feat_path: Optional[Path] = None

    try:
        # ── 1. Feature subset ─────────────────────────────────────────────────
        n_drop   = int(params.get("n_features_to_drop", 0))
        features = list(base_features)
        if n_drop > 0 and n_drop < len(features):
            drop_idx = rng.choice(len(features), size=n_drop, replace=False)
            features = [f for i, f in enumerate(features) if i not in drop_idx]
        if not features:
            result["error_message"] = "Empty feature set."
            return result

        # ── 2. HMM feature subset ─────────────────────────────────────────────
        max_hmm   = int(params.get("hmm_max_features", 6))
        available = [f for f in hmm_pool if f in features or f not in base_features]
        n_hmm     = min(max_hmm, len(available))
        if n_hmm < 2:
            result["error_message"] = "Too few HMM features."
            return result
        hmm_features = [available[i] for i in sorted(
            rng.choice(len(available), size=n_hmm, replace=False)
        )]

        # ── 3. Temporary feature CSV ──────────────────────────────────────────
        tmp_feat_path = OPTIMIZER_OUTPUT_DIR / f"_tmp_features_{trial_id}.csv"
        feat_df       = pd.read_csv(features_path)
        feat_df.columns = [str(c).upper().strip() for c in feat_df.columns]
        feat_df["FEATURE"] = feat_df["FEATURE"].astype(str).str.upper().str.strip()
        feat_df.loc[feat_df["FEATURE"].isin(features)].to_csv(tmp_feat_path, index=False)

        # ── 4. Config ─────────────────────────────────────────────────────────
        config = RiskDecompositionConfig(
            data_path      = data_path,
            features_path  = str(tmp_feat_path),
            sheet_name     = 0,

            universe_mode             = universe_mode,
            use_latam_specific_inputs = use_latam,

            target_col        = "MODEL_TARGET_LEVEL",
            regime_target_col = "MODEL_TARGET",
            source_target_col = "Z_SPREAD_MID",
            target_mode_label = "weekly_pct_change",

            winsorize_target  = True,
            winsorize_lower   = float(params["winsorize_lower"]),
            winsorize_upper   = float(params["winsorize_upper"]),

            ols_cov_type         = str(params["ols_cov_type"]),
            standardize_features = bool(params["standardize_features"]),

            n_pca_components     = int(params["n_pca_components"]),
            min_isins_per_period = int(params["min_isins_per_period"]),

            n_regimes                = 3,
            hmm_covariance_type      = str(params["hmm_covariance_type"]),
            hmm_n_iter               = 300,
            hmm_tol                  = 1e-4,
            hmm_n_starts             = int(params["hmm_n_starts"]),
            hmm_random_state         = trial_id % 100_000,
            hmm_include_pc1          = bool(params["hmm_include_pc1"]),
            hmm_features             = hmm_features,
            hmm_auto_select_features = False,
            hmm_max_features         = max_hmm,

            smooth_regime_states = True,
            min_regime_duration  = int(params["min_regime_duration"]),

            output_dir = str(OPTIMIZER_OUTPUT_DIR / "_tmp"),
        )

        # ── 5. Silent run ─────────────────────────────────────────────────────
        pipeline = RegimeRiskDecompositionPipeline(config)
        pipeline.print_key_tables = lambda: None

        with contextlib.redirect_stdout(io.StringIO()):
            pipeline.load_data()
            pipeline.prepare_model_matrix()
            pipeline.fit_baseline_regression()
            pipeline.run_residual_pca()
            pipeline.fit_compact_hmm()
            pipeline.fit_hmm_conditioned_decomposition()
            pipeline.build_model_comparison()

        # ── 6. Extract metrics ────────────────────────────────────────────────
        mc = pipeline.model_comparison
        if mc is None or mc.empty:
            result["error_message"] = "model_comparison empty."
            return result

        def _get(col: str, kw: str) -> float:
            row = mc.loc[mc["Model"].str.contains(kw, case=False, na=False)]
            return float(row.iloc[-1][col]) if not row.empty else np.nan

        baseline_r2    = _get("R2",     "Baseline")
        baseline_rmse  = _get("RMSE",   "Baseline")
        latent_r2      = _get("R2",     "latent")
        hmm_r2         = _get("R2",     "HMM")
        hmm_adj        = _get("Adj_R2", "HMM")
        hmm_rmse       = _get("RMSE",   "HMM")
        hmm_mae        = _get("MAE",    "HMM")

        regime_r2_gain = (
            max(0.0, hmm_r2 - latent_r2)
            if pd.notna(hmm_r2) and pd.notna(latent_r2) else np.nan
        )

        pct_sig_05 = pct_sig_10 = np.nan
        if pipeline.hmm_decomp_model is not None:
            pvals = pipeline.hmm_decomp_model.pvalues.drop("const", errors="ignore")
            if len(pvals) > 0:
                pct_sig_05 = float((pvals < 0.05).mean())
                pct_sig_10 = float((pvals < 0.10).mean())

        regime_share = np.nan
        if pipeline.hmm_component_shares is not None:
            rs = pipeline.hmm_component_shares.loc[
                pipeline.hmm_component_shares["Risk_component"].eq("Regime"),
                "Share_of_abs_contribution",
            ]
            if not rs.empty:
                regime_share = float(rs.iloc[0])

        avg_self = np.nan
        if pipeline.regime_transition_matrix is not None:
            tm   = pipeline.regime_transition_matrix
            diag = [float(tm.loc[r, r]) for r in ["Calm", "Transitional", "Stress"]
                    if r in tm.index and r in tm.columns]
            if diag:
                avg_self = float(np.mean(diag))

        pc1_var = np.nan
        if pipeline.pca_variance_table is not None:
            r = pipeline.pca_variance_table.loc[
                pipeline.pca_variance_table["Component"].eq("PC1"),
                "Explained_variance_ratio",
            ]
            if not r.empty:
                pc1_var = float(r.iloc[0])

        n_reg = np.nan
        if pipeline.regime_states is not None:
            n_reg = int((pipeline.regime_states.value_counts(normalize=True) > 0.05).sum())

        score = composite_score(
            r2_hmm              = hmm_r2       if pd.notna(hmm_r2)       else 0.0,
            adj_r2_hmm          = hmm_adj      if pd.notna(hmm_adj)      else 0.0,
            pct_significant     = pct_sig_05   if pd.notna(pct_sig_05)   else 0.0,
            avg_self_transition = avg_self     if pd.notna(avg_self)     else 0.0,
            regime_share        = regime_share if pd.notna(regime_share) else 0.0,
            **score_weights,
        )

        def _r(x, d=4):
            return round(x, d) if pd.notna(x) else np.nan

        result.update({
            "status":               "ok",
            "score":                _r(score, 6),
            "hmm_r2":               _r(hmm_r2,       6),
            "hmm_adj_r2":           _r(hmm_adj,      6),
            "hmm_rmse":             _r(hmm_rmse,     6),
            "hmm_mae":              _r(hmm_mae,      6),
            "pct_significant_p05":  _r(pct_sig_05,   4),
            "pct_significant_p10":  _r(pct_sig_10,   4),
            "regime_share":         _r(regime_share, 4),
            "avg_self_transition":  _r(avg_self,     4),
            "n_regimes_identified": int(n_reg) if pd.notna(n_reg) else np.nan,
            "baseline_r2":          _r(baseline_r2,  6),
            "baseline_rmse":        _r(baseline_rmse,6),
            "latent_aug_r2":        _r(latent_r2,    6),
            "regime_r2_gain":       _r(regime_r2_gain, 6),
            "pc1_variance_share":   _r(pc1_var,      4),
            "n_features_used":      int(pipeline.X.shape[1]) if pipeline.X is not None else np.nan,
            "hmm_features_used":    " | ".join(pipeline.hmm_features_used),
        })

    except Exception:
        result["error_message"] = traceback.format_exc(limit=3)
    finally:
        if tmp_feat_path is not None:
            try:
                tmp_feat_path.unlink(missing_ok=True)
            except Exception:
                pass

    return result


# ==========================================================
# Optimizer
# ==========================================================

class PipelineOptimizer:
    """
    Regime-share-aware randomised search for RegimeRiskDecompositionPipeline.

    Per-iteration output: one DataFrame showing metrics with and without
    the regime layer — no other prints during the search.

    Optimisation plots (3):
        1. Timeline convergence
        2. R² with vs without regime + regime share scatter
        3. Hyperparameter × metric Spearman heatmap

    Analysis plots only shown in the full best-run re-run.
    """

    LEADERBOARD_COLS = [
        "rank", "trial_id", "status", "score",
        "hmm_r2", "hmm_adj_r2", "hmm_rmse", "hmm_mae",
        "pct_significant_p05", "pct_significant_p10",
        "regime_share", "avg_self_transition", "n_regimes_identified",
        "baseline_r2", "baseline_rmse", "latent_aug_r2",
        "regime_r2_gain",
        "pc1_variance_share",
        "n_features_used", "hmm_features_used",
        "hmm_covariance_type", "hmm_n_starts", "hmm_max_features",
        "n_pca_components", "min_isins_per_period", "min_regime_duration",
        "ols_cov_type", "winsorize_lower", "winsorize_upper",
        "standardize_features", "hmm_include_pc1", "n_features_to_drop",
    ]

    def __init__(
        self,
        n_iterations:  int,
        universe_mode: str            = "LATAM",
        random_seed:   int            = 42,
        score_weights: Optional[dict] = None,
    ) -> None:
        if n_iterations < 1:
            raise ValueError("n_iterations must be >= 1.")

        self.n_iterations  = n_iterations
        self.universe_mode = str(universe_mode).upper().strip()
        self.random_seed   = random_seed
        self.score_weights = score_weights or {}

        self.use_latam = (self.universe_mode == "LATAM")
        self.hmm_pool  = (
            HMM_CANDIDATE_POOL_LATAM if self.use_latam
            else HMM_CANDIDATE_POOL_ALL_EM
        )

        self.results:     list[dict]             = []
        self.leaderboard: Optional[pd.DataFrame] = None
        self.best_params: Optional[dict]         = None
        self.best_result: Optional[dict]         = None
        self.best_score:  float                  = -np.inf

        OPTIMIZER_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        (OPTIMIZER_OUTPUT_DIR / "_tmp").mkdir(parents=True, exist_ok=True)

    # ----------------------------------------------------------
    # Run
    # ----------------------------------------------------------

    def run(self) -> pd.DataFrame:
        ew = self._effective_weights()
        print("\n" + "=" * 78)
        print("PIPELINE OPTIMIZER — REGIME-SHARE AWARE")
        print("=" * 78)
        print(f"Iterations     : {self.n_iterations}  |  "
              f"Universe : {self.universe_mode}  |  "
              f"Seed : {self.random_seed}")
        print(f"Weights  R²={ew['w_r2']}  Adj={ew['w_adj']}  "
              f"Sig={ew['w_sig']}  Persist={ew['w_persist']}  "
              f"RegimeShare={ew['w_regime_share']} ★")
        print("=" * 78 + "\n")

        base_features = self._load_base_features()
        rng = np.random.default_rng(self.random_seed)
        t0  = time.time()

        for i in range(1, self.n_iterations + 1):
            params  = self._sample_params(rng)
            elapsed = time.time() - t0
            eta     = (elapsed / i) * (self.n_iterations - i) if i > 1 else 0.0

            result = _run_single_trial(
                trial_id      = i,
                params        = params,
                base_features = base_features,
                hmm_pool      = self.hmm_pool,
                universe_mode = self.universe_mode,
                use_latam     = self.use_latam,
                data_path     = str(MASTER_CLEAN_PATH),
                features_path = str(SELECTED_FEATURES_PATH),
                rng           = rng,
                score_weights = self.score_weights,
            )

            self.results.append(result)

            if result["status"] == "ok":
                sc      = float(result["score"])
                is_best = sc > self.best_score
                if is_best:
                    self.best_score  = sc
                    self.best_params = {
                        **params,
                        "hmm_features_used": result["hmm_features_used"],
                        "trial_id":          i,
                    }
                    self.best_result = result

                def _v(key, fmt=".4f"):
                    v = result.get(key)
                    return f"{float(v):{fmt}}" if pd.notna(v) else "n/a"

                metrics_df = pd.DataFrame([
                    {"Group": "Without regime", "Metric": "R²  (baseline only)",     "Value": _v("baseline_r2")},
                    {"Group": "Without regime", "Metric": "R²  (+ latent PCs)",       "Value": _v("latent_aug_r2")},
                    {"Group": "Without regime", "Metric": "RMSE (baseline)",           "Value": _v("baseline_rmse")},
                    {"Group": "With regime",    "Metric": "R²  (+ regime HMM)",       "Value": _v("hmm_r2")},
                    {"Group": "With regime",    "Metric": "Adj-R² (HMM)",             "Value": _v("hmm_adj_r2")},
                    {"Group": "With regime",    "Metric": "RMSE (HMM)",               "Value": _v("hmm_rmse")},
                    {"Group": "With regime",    "Metric": "MAE  (HMM)",               "Value": _v("hmm_mae")},
                    {"Group": "With regime",    "Metric": "% significant p<0.05",     "Value": _v("pct_significant_p05")},
                    {"Group": "Regime impact",  "Metric": "Regime R² gain ★",         "Value": _v("regime_r2_gain")},
                    {"Group": "Regime impact",  "Metric": "Regime component share ★", "Value": _v("regime_share")},
                    {"Group": "Regime impact",  "Metric": "Avg self-transition",       "Value": _v("avg_self_transition")},
                    {"Group": "Regime impact",  "Metric": "N regimes identified",      "Value": _v("n_regimes_identified", ".0f")},
                    {"Group": "Composite",      "Metric": "Score",                     "Value": _v("score")},
                ]).set_index(["Group", "Metric"])

                star = "  ★ NEW BEST" if is_best else ""
                print(f"{'─'*50}  Trial {i}/{self.n_iterations}"
                      f"  |  ETA {eta/60:.0f}min{star}")
                display(metrics_df)

            else:
                msg = str(result.get("error_message", ""))[:80]
                print(f"Trial {i}/{self.n_iterations}  ERROR — {msg}")

            if i % 10 == 0 or i == self.n_iterations:
                self._save_leaderboard()

        self._save_leaderboard()
        self._print_summary()
        return self.leaderboard

    # ----------------------------------------------------------
    # Best re-run
    # ----------------------------------------------------------

    def rerun_best(self, show_plots: bool = True) -> RegimeRiskDecompositionPipeline:
        if self.best_params is None:
            raise RuntimeError("No successful trial found.")

        print("\n" + "=" * 78)
        print("RE-RUNNING BEST CONFIGURATION")
        print("=" * 78)

        if self.best_result:
            br = self.best_result

            def _v(key, fmt=".4f"):
                v = br.get(key)
                return f"{float(v):{fmt}}" if pd.notna(v) else "n/a"

            summary_df = pd.DataFrame([
                {"Group": "Without regime", "Metric": "R²  (baseline only)",     "Value": _v("baseline_r2")},
                {"Group": "Without regime", "Metric": "R²  (+ latent PCs)",       "Value": _v("latent_aug_r2")},
                {"Group": "Without regime", "Metric": "RMSE (baseline)",           "Value": _v("baseline_rmse")},
                {"Group": "With regime",    "Metric": "R²  (+ regime HMM)",       "Value": _v("hmm_r2")},
                {"Group": "With regime",    "Metric": "Adj-R² (HMM)",             "Value": _v("hmm_adj_r2")},
                {"Group": "With regime",    "Metric": "RMSE (HMM)",               "Value": _v("hmm_rmse")},
                {"Group": "With regime",    "Metric": "MAE  (HMM)",               "Value": _v("hmm_mae")},
                {"Group": "With regime",    "Metric": "% significant p<0.05",     "Value": _v("pct_significant_p05")},
                {"Group": "Regime impact",  "Metric": "Regime R² gain ★",         "Value": _v("regime_r2_gain")},
                {"Group": "Regime impact",  "Metric": "Regime component share ★", "Value": _v("regime_share")},
                {"Group": "Regime impact",  "Metric": "Avg self-transition",       "Value": _v("avg_self_transition")},
                {"Group": "Regime impact",  "Metric": "N regimes identified",      "Value": _v("n_regimes_identified", ".0f")},
                {"Group": "Composite",      "Metric": "Score",                     "Value": _v("score")},
            ]).set_index(["Group", "Metric"])

            print("Best configuration metrics:")
            display(summary_df)

        print("\nHyperparameters:")
        for k, v in self.best_params.items():
            if k not in {"hmm_features_used", "trial_id"}:
                print(f"  {k:<30} : {v}")
        print("=" * 78)

        # Reconstruct feature list
        base_features = self._load_base_features()
        n_drop        = int(self.best_params.get("n_features_to_drop", 0))
        best_trial_id = int(self.best_params["trial_id"])

        rng = np.random.default_rng(self.random_seed)
        for _ in range(best_trial_id - 1):
            self._sample_params(rng)
        _ = self._sample_params(rng)

        features = list(base_features)
        if n_drop > 0 and n_drop < len(features):
            drop_idx = rng.choice(len(features), size=n_drop, replace=False)
            features = [f for j, f in enumerate(features) if j not in drop_idx]

        hmm_features = [
            f.strip()
            for f in str(self.best_params.get("hmm_features_used", "")).split("|")
            if f.strip() and not f.strip().startswith("PC")
        ]

        feat_df          = pd.read_csv(SELECTED_FEATURES_PATH)
        feat_df.columns  = [str(c).upper().strip() for c in feat_df.columns]
        feat_df["FEATURE"] = feat_df["FEATURE"].astype(str).str.upper().str.strip()
        best_feat_path   = OPTIMIZER_OUTPUT_DIR / "best_selected_features.csv"
        feat_df.loc[feat_df["FEATURE"].isin(features)].to_csv(best_feat_path, index=False)

        best_output_dir = OPTIMIZER_OUTPUT_DIR / "best_run"
        best_output_dir.mkdir(parents=True, exist_ok=True)

        config = RiskDecompositionConfig(
            data_path      = str(MASTER_CLEAN_PATH),
            features_path  = str(best_feat_path),
            sheet_name     = 0,

            universe_mode             = self.universe_mode,
            use_latam_specific_inputs = self.use_latam,

            target_col        = "MODEL_TARGET_LEVEL",
            regime_target_col = "MODEL_TARGET",
            source_target_col = "Z_SPREAD_MID",
            target_mode_label = "weekly_pct_change",

            winsorize_target  = True,
            winsorize_lower   = float(self.best_params["winsorize_lower"]),
            winsorize_upper   = float(self.best_params["winsorize_upper"]),

            ols_cov_type         = str(self.best_params["ols_cov_type"]),
            standardize_features = bool(self.best_params["standardize_features"]),

            n_pca_components     = int(self.best_params["n_pca_components"]),
            min_isins_per_period = int(self.best_params["min_isins_per_period"]),

            n_regimes                = 3,
            hmm_covariance_type      = str(self.best_params["hmm_covariance_type"]),
            hmm_n_iter               = 500,
            hmm_tol                  = 1e-4,
            hmm_n_starts             = int(self.best_params["hmm_n_starts"]),
            hmm_random_state         = best_trial_id % 100_000,
            hmm_include_pc1          = bool(self.best_params["hmm_include_pc1"]),
            hmm_features             = hmm_features,
            hmm_auto_select_features = False,
            hmm_max_features         = int(self.best_params["hmm_max_features"]),

            smooth_regime_states = True,
            min_regime_duration  = int(self.best_params["min_regime_duration"]),

            output_dir = str(best_output_dir),
        )

        pipeline = RegimeRiskDecompositionPipeline(config)
        pipeline.run_all(show_plots=show_plots)
        pipeline.export_tables(str(best_output_dir))
        pipeline.plot_monitoring_summary_table(
            output_dir=str(best_output_dir),
            show=show_plots,
            export_csv=True,
        )

        if self.best_result:
            br = self.best_result
            pd.DataFrame([
                {"Metric": "Score",             "Value": round(self.best_score, 6)},
                {"Metric": "R² baseline",       "Value": br.get("baseline_r2")},
                {"Metric": "R² + latent PCs",   "Value": br.get("latent_aug_r2")},
                {"Metric": "R² + regime HMM",   "Value": br.get("hmm_r2")},
                {"Metric": "Regime R² gain",    "Value": br.get("regime_r2_gain")},
                {"Metric": "RMSE baseline",     "Value": br.get("baseline_rmse")},
                {"Metric": "RMSE HMM",          "Value": br.get("hmm_rmse")},
                {"Metric": "MAE HMM",           "Value": br.get("hmm_mae")},
                {"Metric": "Regime share",      "Value": br.get("regime_share")},
                {"Metric": "% sig p<0.05",      "Value": br.get("pct_significant_p05")},
                {"Metric": "Avg self-trans",    "Value": br.get("avg_self_transition")},
                {"Metric": "PC1 var share",     "Value": br.get("pc1_variance_share")},
                {"Metric": "N regimes",         "Value": br.get("n_regimes_identified")},
            ]).to_csv(best_output_dir / "best_run_summary_card.csv", index=False)

        print(f"\nBest-run outputs: {best_output_dir.resolve()}")
        return pipeline

    # ----------------------------------------------------------
    # Optimisation plots (3 only)
    # ----------------------------------------------------------

    def plot_optimization(self) -> None:
        """
        Three focused optimisation plots.

        Plot 1 — Timeline convergence
            Score (left axis) and regime share + R² gain (right axis)
            over trial number, with running-best lines and best-trial star.

        Plot 2 — R² with vs without regime + regime share histogram
            Scatter: R²(Baseline+PCs) vs R²(HMM), bubbles sized by regime
            share, coloured by HMM covariance type.
            Sidebar: regime share histogram.

        Plot 3 — Hyperparameter × metric Spearman heatmap
            Shows which settings are associated with high regime share,
            R² gain, significance, and composite score.
        """
        if self.leaderboard is None or self.leaderboard.empty:
            print("No results to plot.")
            return

        ok = self.leaderboard.loc[self.leaderboard["status"].eq("ok")].copy()
        if ok.empty:
            print("No successful trials to plot.")
            return

        for col in [
            "score", "hmm_r2", "hmm_adj_r2", "hmm_rmse", "hmm_mae",
            "baseline_r2", "baseline_rmse", "latent_aug_r2",
            "regime_share", "regime_r2_gain",
            "pct_significant_p05", "avg_self_transition",
            "n_pca_components", "min_regime_duration", "hmm_n_starts",
            "hmm_max_features", "min_isins_per_period", "n_features_to_drop",
        ]:
            if col in ok.columns:
                ok[col] = pd.to_numeric(ok[col], errors="coerce")

        COV_PALETTE = {
            "diag":       "#457b9d",
            "full":       "#e63946",
            "tied":       "#2a9d8f",
            "spherical":  "#f4a261",
        }
        best_tid = int(self.best_params["trial_id"]) if self.best_params else -1

        # ══════════════════════════════════════════════════════════════════════
        # PLOT 1 — Timeline convergence
        # ══════════════════════════════════════════════════════════════════════
        ok_s = ok.sort_values("trial_id").copy()
        ok_s["run_best_score"]  = ok_s["score"].cummax()
        ok_s["run_best_regime"] = ok_s["regime_share"].cummax()
        ok_s["run_best_gain"]   = ok_s["regime_r2_gain"].cummax()

        fig1 = go.Figure()
        fig1.add_trace(go.Scatter(
            x=ok_s["trial_id"], y=ok_s["score"],
            mode="markers", name="Score (trial)",
            opacity=0.40, marker=dict(size=5, color="#457b9d"),
        ))
        fig1.add_trace(go.Scatter(
            x=ok_s["trial_id"], y=ok_s["run_best_score"],
            mode="lines", name="Best score",
            line=dict(color="#e63946", width=2),
        ))
        fig1.add_trace(go.Scatter(
            x=ok_s["trial_id"], y=ok_s["regime_share"],
            mode="markers", name="Regime share (trial)",
            opacity=0.35, marker=dict(size=5, color="#2a9d8f"),
            yaxis="y2",
        ))
        fig1.add_trace(go.Scatter(
            x=ok_s["trial_id"], y=ok_s["run_best_regime"],
            mode="lines", name="Best regime share",
            line=dict(color="#2a9d8f", width=2, dash="dash"),
            yaxis="y2",
        ))
        fig1.add_trace(go.Scatter(
            x=ok_s["trial_id"], y=ok_s["run_best_gain"],
            mode="lines", name="Best R² gain (regime)",
            line=dict(color="#f4a261", width=2, dash="dot"),
            yaxis="y2",
        ))
        if self.best_result:
            fig1.add_trace(go.Scatter(
                x=[best_tid], y=[self.best_score],
                mode="markers+text", name="Best trial",
                text=["★"], textposition="top center",
                marker=dict(symbol="star", size=22, color="#e63946",
                            line=dict(color="white", width=1)),
            ))
        fig1.update_layout(
            title="Optimisation timeline — score (left) · regime share & R² gain (right)",
            xaxis_title="Trial",
            yaxis =dict(title="Composite score"),
            yaxis2=dict(title="Regime share / R² gain",
                        overlaying="y", side="right", showgrid=False),
            legend=dict(orientation="h", yanchor="bottom", y=1.02),
            template="plotly_white", height=500,
        )
        fig1.show()

        # ══════════════════════════════════════════════════════════════════════
        # PLOT 2 — R² with vs without regime + regime share histogram
        # ══════════════════════════════════════════════════════════════════════
        ok_p = ok.copy()
        ok_p["_size"] = (
            8 + 40 * (
                (ok_p["regime_share"] - ok_p["regime_share"].min())
                / ((ok_p["regime_share"].max() - ok_p["regime_share"].min()) + 1e-9)
            )
        ).clip(lower=6, upper=48)

        fig2 = make_subplots(
            rows=1, cols=2,
            subplot_titles=[
                "R² without regime vs R²  with regime  (bubble = regime share)",
                "Regime share distribution",
            ],
            column_widths=[0.65, 0.35],
        )

        for cov, grp in ok_p.groupby("hmm_covariance_type", dropna=False):
            colour = COV_PALETTE.get(str(cov), "#888888")
            fig2.add_trace(go.Scatter(
                x=grp["latent_aug_r2"], y=grp["hmm_r2"],
                mode="markers",
                name=str(cov),
                marker=dict(
                    size=grp["_size"].tolist(), color=colour,
                    opacity=0.65, line=dict(color="white", width=0.5),
                ),
                customdata=grp[["trial_id", "score", "regime_share",
                                "pct_significant_p05", "regime_r2_gain"]].values,
                hovertemplate=(
                    "Trial %{customdata[0]}<br>"
                    "R² (+ latent PCs): %{x:.4f}<br>"
                    "R² (+ regime HMM): %{y:.4f}<br>"
                    "Score: %{customdata[1]:.4f}<br>"
                    "Regime share: %{customdata[2]:.4f}<br>"
                    "% sig p<0.05: %{customdata[3]:.3f}<br>"
                    "R² gain: %{customdata[4]:.4f}"
                    "<extra></extra>"
                ),
            ), row=1, col=1)

        lo = float(min(ok_p["latent_aug_r2"].min(), ok_p["hmm_r2"].min()) * 0.95)
        hi = float(max(ok_p["latent_aug_r2"].max(), ok_p["hmm_r2"].max()) * 1.05)
        fig2.add_trace(go.Scatter(
            x=[lo, hi], y=[lo, hi], mode="lines",
            name="No gain", showlegend=True,
            line=dict(color="grey", dash="dot", width=1),
        ), row=1, col=1)

        fig2.add_trace(go.Histogram(
            x=ok_p["regime_share"].dropna(), nbinsx=25,
            name="Regime share", marker_color="#2a9d8f",
            opacity=0.75, showlegend=False,
        ), row=1, col=2)
        fig2.add_vline(
            x=float(ok_p["regime_share"].median()),
            line_dash="dash", line_color="#e63946",
            annotation_text="median", row=1, col=2,
        )

        fig2.update_xaxes(title_text="R² (Baseline + latent PCs)", row=1, col=1)
        fig2.update_yaxes(title_text="R² (+ regime HMM)",          row=1, col=1)
        fig2.update_xaxes(title_text="Regime share",                row=1, col=2)
        fig2.update_yaxes(title_text="Count",                       row=1, col=2)
        fig2.update_layout(
            title="R² with vs without regime  |  Points above diagonal = regime adds value",
            template="plotly_white", height=500,
            legend=dict(orientation="v", x=0.68, y=0.98, font=dict(size=10)),
        )
        fig2.show()

        # ══════════════════════════════════════════════════════════════════════
        # PLOT 3 — Hyperparameter × metric Spearman heatmap
        # ══════════════════════════════════════════════════════════════════════
        HYPERPARAM_COLS = [
            "n_pca_components", "min_regime_duration", "hmm_n_starts",
            "hmm_max_features", "min_isins_per_period", "n_features_to_drop",
            "hmm_covariance_type", "ols_cov_type",
            "standardize_features", "hmm_include_pc1",
        ]
        METRIC_COLS = [
            "regime_share", "regime_r2_gain", "hmm_r2",
            "pct_significant_p05", "avg_self_transition", "score",
        ]
        LABELS = {
            "regime_share":          "Regime share ★",
            "regime_r2_gain":        "R² gain (regime)",
            "hmm_r2":                "HMM R²",
            "pct_significant_p05":   "% sig p<0.05",
            "avg_self_transition":   "HMM persist.",
            "score":                 "Score",
            "n_pca_components":      "PCA comps",
            "min_regime_duration":   "Min dur.",
            "hmm_n_starts":          "HMM restarts",
            "hmm_max_features":      "HMM feats",
            "min_isins_per_period":  "Min ISINs",
            "n_features_to_drop":    "Feats dropped",
            "hmm_covariance_type":   "Cov. type",
            "ols_cov_type":          "OLS cov.",
            "standardize_features":  "Standardize",
            "hmm_include_pc1":       "HMM + PC1",
        }

        ok_enc = ok.copy()
        for col in ["hmm_covariance_type", "ols_cov_type",
                    "standardize_features", "hmm_include_pc1"]:
            if col in ok_enc.columns:
                ok_enc[col] = pd.Categorical(ok_enc[col]).codes.astype(float)

        all_hp  = [c for c in HYPERPARAM_COLS if c in ok_enc.columns]
        all_met = [c for c in METRIC_COLS      if c in ok_enc.columns]

        corr_mat = []
        for hp in all_hp:
            row_v = []
            for met in all_met:
                try:
                    r = float(
                        ok_enc[[hp, met]].dropna()
                        .corr(method="spearman").loc[hp, met]
                    )
                except Exception:
                    r = 0.0
                row_v.append(r)
            corr_mat.append(row_v)

        corr_df = pd.DataFrame(
            corr_mat,
            index   = [LABELS.get(c, c) for c in all_hp],
            columns = [LABELS.get(c, c) for c in all_met],
        )

        fig3 = px.imshow(
            corr_df,
            color_continuous_scale="RdBu_r",
            zmin=-1, zmax=1,
            text_auto=".2f",
            title="Spearman ρ — hyperparameters vs metrics  |  "
                  "Red = positively drives regime share / R² gain",
            aspect="auto",
        )
        fig3.update_layout(
            height=max(400, 38 * len(all_hp) + 120),
            template="plotly_white",
            xaxis_title="Metric",
            yaxis_title="Hyperparameter",
            coloraxis_colorbar_title="ρ",
        )
        fig3.show()

    # ----------------------------------------------------------
    # Internal helpers
    # ----------------------------------------------------------

    def _load_base_features(self) -> list[str]:
        feat_df          = pd.read_csv(SELECTED_FEATURES_PATH)
        feat_df.columns  = [str(c).upper().strip() for c in feat_df.columns]
        feat_df["FEATURE"] = feat_df["FEATURE"].astype(str).str.upper().str.strip()
        return [
            f for f in feat_df["FEATURE"].tolist()
            if is_allowed_model_input_feature(f)
            and (self.use_latam or not is_latam_specific_feature(f))
        ]

    def _sample_params(self, rng: np.random.Generator) -> dict[str, Any]:
        out = {}
        for k, v in SEARCH_SPACE.items():
            choice = rng.choice(v)
            out[k]  = choice.item() if isinstance(choice, np.generic) else choice
        return out

    def _effective_weights(self) -> dict:
        defaults = dict(
            w_r2=0.30, w_adj=0.15, w_sig=0.20,
            w_persist=0.10, w_regime_share=0.25,
        )
        return {**defaults, **self.score_weights}

    def _save_leaderboard(self) -> None:
        if not self.results:
            return
        df  = pd.DataFrame(self.results)
        ok  = df.loc[df["status"].eq("ok")].sort_values(
            ["score", "regime_share"], ascending=False
        ).copy()
        ok.insert(0, "rank", range(1, len(ok) + 1))
        err = df.loc[df["status"].ne("ok")].copy()
        err.insert(0, "rank", np.nan)
        self.leaderboard = pd.concat([ok, err], ignore_index=True)

        avail = [c for c in self.LEADERBOARD_COLS if c in self.leaderboard.columns]
        extra = [c for c in self.leaderboard.columns if c not in avail]
        self.leaderboard = self.leaderboard[avail + extra].copy()
        self.leaderboard.to_csv(
            OPTIMIZER_OUTPUT_DIR / "optimizer_leaderboard.csv", index=False
        )

    def _print_summary(self) -> None:
        ok = [r for r in self.results if r["status"] == "ok"]
        print("\n" + "=" * 78)
        print("OPTIMIZER COMPLETE")
        print("=" * 78)
        print(f"Total / OK / Failed : "
              f"{self.n_iterations} / {len(ok)} / {self.n_iterations - len(ok)}")

        if ok and self.best_result:
            br = self.best_result

            def _v(key, fmt=".4f"):
                v = br.get(key)
                return f"{float(v):{fmt}}" if pd.notna(v) else "n/a"

            summary_df = pd.DataFrame([
                {"Group": "Without regime", "Metric": "R²  (baseline only)",     "Value": _v("baseline_r2")},
                {"Group": "Without regime", "Metric": "R²  (+ latent PCs)",       "Value": _v("latent_aug_r2")},
                {"Group": "Without regime", "Metric": "RMSE (baseline)",           "Value": _v("baseline_rmse")},
                {"Group": "With regime",    "Metric": "R²  (+ regime HMM)",       "Value": _v("hmm_r2")},
                {"Group": "With regime",    "Metric": "Adj-R² (HMM)",             "Value": _v("hmm_adj_r2")},
                {"Group": "With regime",    "Metric": "RMSE (HMM)",               "Value": _v("hmm_rmse")},
                {"Group": "With regime",    "Metric": "MAE  (HMM)",               "Value": _v("hmm_mae")},
                {"Group": "With regime",    "Metric": "% significant p<0.05",     "Value": _v("pct_significant_p05")},
                {"Group": "Regime impact",  "Metric": "Regime R² gain ★",         "Value": _v("regime_r2_gain")},
                {"Group": "Regime impact",  "Metric": "Regime component share ★", "Value": _v("regime_share")},
                {"Group": "Regime impact",  "Metric": "Avg self-transition",       "Value": _v("avg_self_transition")},
                {"Group": "Regime impact",  "Metric": "N regimes identified",      "Value": _v("n_regimes_identified", ".0f")},
                {"Group": "Composite",      "Metric": "Score",                     "Value": _v("score")},
            ]).set_index(["Group", "Metric"])

            print("\nBest configuration — final metrics:")
            display(summary_df)

        print(f"\nLeaderboard : {OPTIMIZER_OUTPUT_DIR / 'optimizer_leaderboard.csv'}")
        print("=" * 78)


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":

    if not MASTER_CLEAN_PATH.exists():
        raise FileNotFoundError(
            f"MASTER_CLEAN.xlsx not found:\n  {MASTER_CLEAN_PATH}\n"
            "Run data_cleaning.py first."
        )
    if not SELECTED_FEATURES_PATH.exists():
        raise FileNotFoundError(
            f"selected_features.csv not found:\n  {SELECTED_FEATURES_PATH}\n"
            "Run data_cleaning.py first."
        )

    # ======================================================
    # USER SETTINGS — EDIT HERE
    # ======================================================

    N_ITERATIONS: int = 30
    # 20  → quick check  (~10 min)
    # 50  → exploration  (~25 min)
    # 200 → thorough     (~90 min)

    UNIVERSE_MODE: str = "LATAM"    # "LATAM" | "ALL_EM"
    RANDOM_SEED:   int = 42

    RERUN_BEST: bool = True
    SHOW_PLOTS: bool = True

    # Weights must sum to 1.0.
    # Increase w_regime_share to push harder toward large regime components.
    SCORE_WEIGHTS: dict = dict(
        w_r2           = 0.30,   # HMM R²
        w_adj          = 0.15,   # HMM Adj-R²
        w_sig          = 0.20,   # % significant p<0.05
        w_persist      = 0.10,   # HMM self-transition
        w_regime_share = 0.25,   # ★ Regime component share
    )
    # Aggressive regime-first alternative:
    # SCORE_WEIGHTS = dict(w_r2=0.20, w_adj=0.10, w_sig=0.15,
    #                      w_persist=0.05, w_regime_share=0.50)

    # ======================================================
    # Run
    # ======================================================
    OPTIMIZER_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    optimizer = PipelineOptimizer(
        n_iterations  = N_ITERATIONS,
        universe_mode = UNIVERSE_MODE,
        random_seed   = RANDOM_SEED,
        score_weights = SCORE_WEIGHTS,
    )

    leaderboard = optimizer.run()

    optimizer.plot_optimization()

    if RERUN_BEST:
        best_pipeline = optimizer.rerun_best(show_plots=SHOW_PLOTS)

    print("\nOptimizer complete.")
    print(f"Leaderboard : {OPTIMIZER_OUTPUT_DIR / 'optimizer_leaderboard.csv'}")
    if RERUN_BEST:
        print(f"Best run    : {OPTIMIZER_OUTPUT_DIR / 'best_run/'}")

# %%
