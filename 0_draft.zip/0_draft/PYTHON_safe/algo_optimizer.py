# %% ALGO ANALYSIS OPTIMIZER

#!/usr/bin/env python3
"""
algo_analysis_optimizer.py
Randomised search over the hyperparameter space of the regime-aware
risk decomposition pipeline.

For each iteration the optimizer:
    1. Samples a random configuration (feature subset, HMM settings,
       winsorization bounds, PCA components, OLS covariance type …).
    2. Runs the full RegimeRiskDecompositionPipeline in silent mode.
    3. Records R², Adj-R², RMSE, MAE, % significant coefficients,
       mean HMM regime persistence, and the feature/HMM set used.
    4. Keeps the best configuration by a composite score
       (R² + significance share).
    5. Writes a full leaderboard CSV and re-runs the best configuration
       in verbose mode with plots.

User-editable settings are in the __main__ block at the bottom.
The number of iterations is the only mandatory user choice.
"""

# ==========================================================
# Author: Amin Tarbouch
# ==========================================================

from __future__ import annotations

import sys
import copy
import time
import random
import traceback
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

import statsmodels.api as sm
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error

try:
    from hmmlearn.hmm import GaussianHMM
    HMM_AVAILABLE = True
except Exception as exc:
    HMM_AVAILABLE    = False
    HMM_IMPORT_ERROR = exc

# ==========================================================
# Path resolution
# ==========================================================

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from path_config import (
    MASTER_clean,
    OUTPUT_DIR,
    DEFAULT_SHEET,
)

MASTER_CLEAN_PATH      : Path = OUTPUT_DIR / "MASTER_CLEAN.xlsx"
LATEX_OUTPUT_DIR       : Path = OUTPUT_DIR / "output_for_latex"
SELECTED_FEATURES_PATH : Path = LATEX_OUTPUT_DIR / "selected_features.csv"
MODEL_RESULTS_DIR      : Path = OUTPUT_DIR / "model_results"
OPTIMIZER_OUTPUT_DIR   : Path = OUTPUT_DIR / "optimizer_results"

warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=UserWarning)

try:
    from IPython.display import display
except Exception:
    display = print

# ==========================================================
# Import shared utilities from master_thesis_analysis.py
# ==========================================================
# We import all shared helpers, classes and constants directly from the
# main analysis script so there is a single source of truth.

from master_thesis_analysis import (
    # Column whitelists
    ALLOWED_RAW_COLUMNS,
    ALLOWED_RAW_COLUMN_SET,
    ALLOWED_INTERNAL_COLUMNS,
    ALLOWED_DUMMY_PREFIXES,
    DISALLOWED_DERIVED_MODEL_FEATURES,
    # Helper functions
    read_excel_sheet_safe,
    is_allowed_source_or_internal_column,
    is_allowed_model_input_feature,
    restrict_dataframe_to_allowed_columns,
    fallback_classify_feature,
    normalize_feature_type,
    is_latam_specific_feature,
    is_country_dummy_feature,
    compute_rmse,
    compute_mae,
    # Classes
    FeatureTaxonomy,
    RiskDecompositionConfig,
    RegimeRiskDecompositionPipeline,
    # Universe tokens
    LATAM_SPECIFIC_TOKENS,
)

# ==========================================================
# Search-space definition
# ==========================================================

# All candidate HMM state features the optimizer may pick from.
HMM_CANDIDATE_POOL_LATAM: list[str] = [
    "MA3_VIX_INDEX", "MA3_MOVE_INDEX", "MA3_JPM_EMBI", "MA3_MSCI_EM",
    "MA3_BFCIUS_INDEX", "MA3_BFCIEU_INDEX", "MA3_GPR_LEVEL",
    "LATAM_CDS_CREDIT_RISK", "LATAM_JPM_SPREAD_CREDIT_RISK",
    "MA3_GPR_LATAM_MOMENTUM", "MA3_CDX_IG_CDSI_GEN_5Y_CORP",
    "MA3_ITRX_EUR_CDSI_GEN_5Y_CORP", "MA3_STOXX600", "MA3_SP500",
    "MA3_EPUCEMEC_INDEX", "MA3_AONILS_INDEX",
]

HMM_CANDIDATE_POOL_ALL_EM: list[str] = [
    f for f in HMM_CANDIDATE_POOL_LATAM
    if not is_latam_specific_feature(f)
]

# Discrete choices for each dimension of the search space.
SEARCH_SPACE: dict[str, list[Any]] = {
    "hmm_covariance_type":  ["diag", "full", "tied", "spherical"],
    "hmm_n_starts":         [10, 20, 30, 50],
    "hmm_max_features":     [4, 5, 6, 7, 8],
    "n_pca_components":     [2, 3, 4],
    "min_isins_per_period": [3, 5, 7],
    "min_regime_duration":  [2, 3, 4, 5],
    "ols_cov_type":         ["HC3", "HC1", "HC0"],
    "winsorize_lower":      [0.005, 0.01, 0.02],
    "winsorize_upper":      [0.98, 0.99, 0.995],
    "standardize_features": [True, False],
    "hmm_include_pc1":      [True, False],
    # Number of features to randomly drop from the full selected set
    # (0 = use all; higher = more aggressive feature subset sampling).
    "n_features_to_drop":   [0, 0, 0, 5, 10, 15, 20],
}


# ==========================================================
# Scoring function
# ==========================================================

def composite_score(
    r2_hmm: float,
    adj_r2_hmm: float,
    pct_significant: float,
    avg_self_transition: float,
    w_r2: float = 0.40,
    w_adj: float = 0.20,
    w_sig: float = 0.25,
    w_persist: float = 0.15,
) -> float:
    """
    Weighted composite score combining:
        - HMM-conditioned R²                (explanatory power)
        - HMM-conditioned Adj-R²            (penalises over-parameterisation)
        - % significant coefficients (p<0.05) in the final OLS
        - Average HMM self-transition prob  (regime stability / identifiability)

    All inputs are expected in [0, 1]. Returns a scalar in [0, 1].
    """
    def _clip(x: float) -> float:
        return float(np.clip(x, 0.0, 1.0))

    return (
        w_r2      * _clip(r2_hmm)
        + w_adj   * _clip(adj_r2_hmm)
        + w_sig   * _clip(pct_significant)
        + w_persist * _clip(avg_self_transition)
    )


# ==========================================================
# Single-trial runner
# ==========================================================

def _run_single_trial(
    trial_id: int,
    params: dict[str, Any],
    base_features: list[str],
    hmm_pool: list[str],
    universe_mode: str,
    use_latam: bool,
    data_path: str,
    features_path: str,
    rng: np.random.Generator,
) -> dict[str, Any]:
    """
    Execute one full pipeline run with `params` and return a result dict.
    Returns a result dict with status='error' on any exception.
    """
    result: dict[str, Any] = {
        "trial_id":              trial_id,
        "status":                "error",
        "score":                 np.nan,
        "baseline_r2":           np.nan,
        "baseline_adj_r2":       np.nan,
        "hmm_r2":                np.nan,
        "hmm_adj_r2":            np.nan,
        "rmse":                  np.nan,
        "mae":                   np.nan,
        "pct_significant_p05":   np.nan,
        "pct_significant_p10":   np.nan,
        "avg_self_transition":   np.nan,
        "n_features_used":       np.nan,
        "hmm_features_used":     "",
        "n_regimes_identified":  np.nan,
        "pc1_variance_share":    np.nan,
        "error_message":         "",
        **{k: str(v) for k, v in params.items()},
    }

    try:
        # ── 1. Sample feature subset ───────────────────────────────────────────
        n_drop    = int(params.get("n_features_to_drop", 0))
        features  = list(base_features)
        if n_drop > 0 and n_drop < len(features):
            drop_idx = rng.choice(len(features), size=n_drop, replace=False)
            features = [f for i, f in enumerate(features) if i not in drop_idx]

        if not features:
            result["error_message"] = "Empty feature set after dropping."
            return result

        # ── 2. Sample HMM feature subset ──────────────────────────────────────
        max_hmm   = int(params.get("hmm_max_features", 6))
        available = [f for f in hmm_pool if f in features
                     or f not in base_features]   # allow pool features not in base
        n_hmm     = min(max_hmm, len(available))
        if n_hmm < 2:
            result["error_message"] = "Too few HMM features available."
            return result
        hmm_feat_idx  = rng.choice(len(available), size=n_hmm, replace=False)
        hmm_features  = [available[i] for i in sorted(hmm_feat_idx)]

        # ── 3. Write a temporary selected_features.csv ────────────────────────
        tmp_feat_path = OPTIMIZER_OUTPUT_DIR / f"_tmp_features_{trial_id}.csv"
        feat_df = pd.read_csv(features_path)
        feat_df.columns = [str(c).upper().strip() for c in feat_df.columns]
        feat_df["FEATURE"] = feat_df["FEATURE"].astype(str).str.upper().str.strip()
        feat_df_filtered = feat_df.loc[feat_df["FEATURE"].isin(features)].copy()
        feat_df_filtered.to_csv(tmp_feat_path, index=False)

        # ── 4. Build config ────────────────────────────────────────────────────
        config = RiskDecompositionConfig(
            data_path      = data_path,
            features_path  = str(tmp_feat_path),
            sheet_name     = 0,

            universe_mode             = universe_mode,
            use_latam_specific_inputs = use_latam,

            target_col        = "MODEL_TARGET_LEVEL",
            regime_target_col = "MODEL_TARGET",
            source_target_col = "Z_SPREAD_MID",
            target_mode_label = "weekly_pct_change",

            winsorize_target  = True,
            winsorize_lower   = float(params["winsorize_lower"]),
            winsorize_upper   = float(params["winsorize_upper"]),

            ols_cov_type         = str(params["ols_cov_type"]),
            standardize_features = bool(params["standardize_features"]),

            n_pca_components     = int(params["n_pca_components"]),
            min_isins_per_period = int(params["min_isins_per_period"]),

            n_regimes                = 3,
            hmm_covariance_type      = str(params["hmm_covariance_type"]),
            hmm_n_iter               = 300,
            hmm_tol                  = 1e-4,
            hmm_n_starts             = int(params["hmm_n_starts"]),
            hmm_random_state         = trial_id % 100_000,
            hmm_include_pc1          = bool(params["hmm_include_pc1"]),
            hmm_features             = hmm_features,
            hmm_auto_select_features = False,
            hmm_max_features         = max_hmm,

            smooth_regime_states = True,
            min_regime_duration  = int(params["min_regime_duration"]),

            output_dir = str(OPTIMIZER_OUTPUT_DIR / "_tmp"),
        )

        # ── 5. Run pipeline in fully silent mode ───────────────────────────────
        _orig_print = __builtins__["print"] if isinstance(__builtins__, dict) else print

        import io, contextlib
        buf = io.StringIO()

        pipeline = RegimeRiskDecompositionPipeline(config)

        def _noop(*a, **k): pass
        pipeline.print_key_tables = _noop

        # Silence all stdout during the run
        with contextlib.redirect_stdout(buf):
            pipeline.load_data()
            pipeline.prepare_model_matrix()
            pipeline.fit_baseline_regression()
            pipeline.run_residual_pca()
            pipeline.fit_compact_hmm()
            pipeline.fit_hmm_conditioned_decomposition()
            pipeline.build_model_comparison()

        # ── 6. Extract metrics ─────────────────────────────────────────────────
        mc = pipeline.model_comparison
        if mc is None or mc.empty:
            result["error_message"] = "model_comparison is empty."
            return result

        b_row = mc.loc[mc["Model"].str.contains("Baseline", case=False, na=False)]
        h_row = mc.loc[mc["Model"].str.contains("HMM",      case=False, na=False)]

        baseline_r2    = float(b_row.iloc[0]["R2"])     if not b_row.empty else np.nan
        baseline_adj   = float(b_row.iloc[0]["Adj_R2"]) if not b_row.empty else np.nan
        hmm_r2         = float(h_row.iloc[-1]["R2"])     if not h_row.empty else np.nan
        hmm_adj        = float(h_row.iloc[-1]["Adj_R2"]) if not h_row.empty else np.nan
        hmm_rmse       = float(h_row.iloc[-1]["RMSE"])   if not h_row.empty else np.nan
        hmm_mae        = float(h_row.iloc[-1]["MAE"])    if not h_row.empty else np.nan

        # % significant coefficients in the final HMM-conditioned OLS
        pct_sig_05 = np.nan
        pct_sig_10 = np.nan
        if pipeline.hmm_decomp_model is not None:
            pvals = pipeline.hmm_decomp_model.pvalues.drop("const", errors="ignore")
            if len(pvals) > 0:
                pct_sig_05 = float((pvals < 0.05).mean())
                pct_sig_10 = float((pvals < 0.10).mean())

        # Average HMM self-transition probability
        avg_self = np.nan
        if pipeline.regime_transition_matrix is not None:
            tm   = pipeline.regime_transition_matrix
            diag = [float(tm.loc[r, r]) for r in ["Calm", "Transitional", "Stress"]
                    if r in tm.index and r in tm.columns]
            if diag:
                avg_self = float(np.mean(diag))

        # PC1 variance share
        pc1_var = np.nan
        if pipeline.pca_variance_table is not None:
            pc1_row = pipeline.pca_variance_table.loc[
                pipeline.pca_variance_table["Component"].eq("PC1"),
                "Explained_variance_ratio"
            ]
            if not pc1_row.empty:
                pc1_var = float(pc1_row.iloc[0])

        # Number of distinct regimes actually observed
        n_reg = (pipeline.regime_states.nunique()
                 if pipeline.regime_states is not None else np.nan)

        score = composite_score(
            r2_hmm            = hmm_r2  if pd.notna(hmm_r2)  else 0.0,
            adj_r2_hmm        = hmm_adj if pd.notna(hmm_adj) else 0.0,
            pct_significant   = pct_sig_05 if pd.notna(pct_sig_05) else 0.0,
            avg_self_transition = avg_self if pd.notna(avg_self) else 0.0,
        )

        result.update({
            "status":               "ok",
            "score":                round(score, 6),
            "baseline_r2":          round(baseline_r2, 6),
            "baseline_adj_r2":      round(baseline_adj, 6),
            "hmm_r2":               round(hmm_r2,  6),
            "hmm_adj_r2":           round(hmm_adj, 6),
            "rmse":                 round(hmm_rmse, 6),
            "mae":                  round(hmm_mae,  6),
            "pct_significant_p05":  round(pct_sig_05, 4) if pd.notna(pct_sig_05) else np.nan,
            "pct_significant_p10":  round(pct_sig_10, 4) if pd.notna(pct_sig_10) else np.nan,
            "avg_self_transition":  round(avg_self,  4) if pd.notna(avg_self)  else np.nan,
            "n_features_used":      int(pipeline.X.shape[1]) if pipeline.X is not None else np.nan,
            "hmm_features_used":    " | ".join(pipeline.hmm_features_used),
            "n_regimes_identified": int(n_reg) if pd.notna(n_reg) else np.nan,
            "pc1_variance_share":   round(pc1_var, 4) if pd.notna(pc1_var) else np.nan,
        })

    except Exception:
        result["error_message"] = traceback.format_exc(limit=3)
    finally:
        # Clean up temporary feature CSV
        try:
            if "tmp_feat_path" in dir() and tmp_feat_path.exists():
                tmp_feat_path.unlink()
        except Exception:
            pass

    return result


# ==========================================================
# Optimizer
# ==========================================================

class PipelineOptimizer:
    """
    Randomised search optimizer for RegimeRiskDecompositionPipeline.

    Parameters
    ----------
    n_iterations : int
        Number of random configurations to evaluate.
    universe_mode : str
        "LATAM" or "ALL_EM".
    random_seed : int
        Master seed for reproducibility.
    score_weights : dict
        Optional override for composite_score weights.
    """

    LEADERBOARD_COLS = [
        "rank", "trial_id", "status", "score",
        "hmm_r2", "hmm_adj_r2", "baseline_r2",
        "pct_significant_p05", "pct_significant_p10",
        "avg_self_transition", "pc1_variance_share",
        "n_features_used", "n_regimes_identified",
        "rmse", "mae",
        "hmm_features_used",
        # hyperparameters
        "hmm_covariance_type", "hmm_n_starts", "hmm_max_features",
        "n_pca_components", "min_isins_per_period", "min_regime_duration",
        "ols_cov_type", "winsorize_lower", "winsorize_upper",
        "standardize_features", "hmm_include_pc1", "n_features_to_drop",
    ]

    def __init__(
        self,
        n_iterations: int,
        universe_mode: str      = "LATAM",
        random_seed: int        = 42,
        score_weights: Optional[dict] = None,
    ) -> None:
        if n_iterations < 1:
            raise ValueError("n_iterations must be >= 1.")
        self.n_iterations  = n_iterations
        self.universe_mode = str(universe_mode).upper().strip()
        self.random_seed   = random_seed
        self.score_weights = score_weights or {}

        self.use_latam = (self.universe_mode == "LATAM")
        self.hmm_pool  = (
            HMM_CANDIDATE_POOL_LATAM if self.use_latam
            else HMM_CANDIDATE_POOL_ALL_EM
        )

        self.results:     list[dict] = []
        self.leaderboard: Optional[pd.DataFrame] = None
        self.best_params: Optional[dict] = None
        self.best_score:  float = -np.inf

        OPTIMIZER_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        (OPTIMIZER_OUTPUT_DIR / "_tmp").mkdir(parents=True, exist_ok=True)

    # ----------------------------------------------------------
    # Run
    # ----------------------------------------------------------

    def run(self) -> pd.DataFrame:
        print("\n" + "=" * 78)
        print("PIPELINE OPTIMIZER — RANDOMISED SEARCH")
        print("=" * 78)
        print(f"Iterations     : {self.n_iterations}")
        print(f"Universe       : {self.universe_mode}")
        print(f"Random seed    : {self.random_seed}")
        print(f"Output dir     : {OPTIMIZER_OUTPUT_DIR}")
        print("=" * 78)

        # Load base features once
        base_features = self._load_base_features()
        print(f"Base features available : {len(base_features):,}")

        rng = np.random.default_rng(self.random_seed)
        t0  = time.time()

        for i in range(1, self.n_iterations + 1):
            params  = self._sample_params(rng)
            elapsed = time.time() - t0
            eta     = (elapsed / i) * (self.n_iterations - i) if i > 1 else 0.0

            print(
                f"\n[{i:>4}/{self.n_iterations}] "
                f"cov={params['hmm_covariance_type']:<10} "
                f"pca={params['n_pca_components']} "
                f"dur={params['min_regime_duration']} "
                f"ols={params['ols_cov_type']:<4} "
                f"drop={params['n_features_to_drop']} "
                f"| ETA {eta/60:.1f} min",
                end="  ",
            )

            result = _run_single_trial(
                trial_id      = i,
                params        = params,
                base_features = base_features,
                hmm_pool      = self.hmm_pool,
                universe_mode = self.universe_mode,
                use_latam     = self.use_latam,
                data_path     = str(MASTER_CLEAN_PATH),
                features_path = str(SELECTED_FEATURES_PATH),
                rng           = rng,
            )

            self.results.append(result)

            if result["status"] == "ok":
                sc = float(result["score"])
                print(
                    f"score={sc:.4f}  R²={result['hmm_r2']:.4f}  "
                    f"sig%={result['pct_significant_p05']:.2f}  "
                    f"persist={result['avg_self_transition']:.2f}"
                )
                if sc > self.best_score:
                    self.best_score  = sc
                    self.best_params = {**params,
                                        "hmm_features_used": result["hmm_features_used"]}
                    print(f"  ★ New best score: {sc:.4f}")
            else:
                msg = str(result.get("error_message", ""))[:120]
                print(f"ERROR — {msg}")

            # Auto-save leaderboard every 10 trials
            if i % 10 == 0 or i == self.n_iterations:
                self._save_leaderboard()

        self._save_leaderboard()
        self._print_summary()
        return self.leaderboard

    # ----------------------------------------------------------
    # Best re-run
    # ----------------------------------------------------------

    def rerun_best(self, show_plots: bool = True) -> RegimeRiskDecompositionPipeline:
        """
        Re-run the best configuration found during the search in full
        verbose mode with plots and export all tables to optimizer_results/.
        """
        if self.best_params is None:
            raise RuntimeError("No successful trial found. Cannot re-run best.")

        print("\n" + "=" * 78)
        print("RE-RUNNING BEST CONFIGURATION")
        print("=" * 78)
        print(f"Best score     : {self.best_score:.4f}")
        for k, v in self.best_params.items():
            print(f"  {k:<30} : {v}")
        print("=" * 78)

        # Reconstruct features used in best trial
        base_features = self._load_base_features()
        n_drop        = int(self.best_params.get("n_features_to_drop", 0))
        rng           = np.random.default_rng(self.random_seed)
        # Reproduce the same drop by replaying the search up to best trial rank
        best_rank     = int(
            self.leaderboard.loc[self.leaderboard["score"].eq(self.best_score), "trial_id"].iloc[0]
        )
        for i in range(1, best_rank):
            self._sample_params(rng)   # advance RNG state
        _ = self._sample_params(rng)   # this is the best trial's params draw

        features = list(base_features)
        if n_drop > 0 and n_drop < len(features):
            drop_idx = rng.choice(len(features), size=n_drop, replace=False)
            features = [f for j, f in enumerate(features) if j not in drop_idx]

        # Write permanent selected_features for this run
        feat_df          = pd.read_csv(SELECTED_FEATURES_PATH)
        feat_df.columns  = [str(c).upper().strip() for c in feat_df.columns]
        feat_df["FEATURE"] = feat_df["FEATURE"].astype(str).str.upper().str.strip()
        feat_df_best     = feat_df.loc[feat_df["FEATURE"].isin(features)].copy()
        best_feat_path   = OPTIMIZER_OUTPUT_DIR / "best_selected_features.csv"
        feat_df_best.to_csv(best_feat_path, index=False)

        # Recover HMM features
        hmm_features_str = str(self.best_params.get("hmm_features_used", ""))
        hmm_features     = [f.strip() for f in hmm_features_str.split("|") if f.strip()
                            and not f.strip().startswith("PC")]

        best_output_dir = OPTIMIZER_OUTPUT_DIR / "best_run"
        best_output_dir.mkdir(parents=True, exist_ok=True)

        config = RiskDecompositionConfig(
            data_path      = str(MASTER_CLEAN_PATH),
            features_path  = str(best_feat_path),
            sheet_name     = 0,

            universe_mode             = self.universe_mode,
            use_latam_specific_inputs = self.use_latam,

            target_col        = "MODEL_TARGET_LEVEL",
            regime_target_col = "MODEL_TARGET",
            source_target_col = "Z_SPREAD_MID",
            target_mode_label = "weekly_pct_change",

            winsorize_target  = True,
            winsorize_lower   = float(self.best_params["winsorize_lower"]),
            winsorize_upper   = float(self.best_params["winsorize_upper"]),

            ols_cov_type         = str(self.best_params["ols_cov_type"]),
            standardize_features = bool(self.best_params["standardize_features"]),

            n_pca_components     = int(self.best_params["n_pca_components"]),
            min_isins_per_period = int(self.best_params["min_isins_per_period"]),

            n_regimes                = 3,
            hmm_covariance_type      = str(self.best_params["hmm_covariance_type"]),
            hmm_n_iter               = 500,
            hmm_tol                  = 1e-4,
            hmm_n_starts             = int(self.best_params["hmm_n_starts"]),
            hmm_random_state         = best_rank % 100_000,
            hmm_include_pc1          = bool(self.best_params["hmm_include_pc1"]),
            hmm_features             = hmm_features,
            hmm_auto_select_features = False,
            hmm_max_features         = int(self.best_params["hmm_max_features"]),

            smooth_regime_states = True,
            min_regime_duration  = int(self.best_params["min_regime_duration"]),

            output_dir = str(best_output_dir),
        )

        pipeline = RegimeRiskDecompositionPipeline(config)
        pipeline.run_all(show_plots=show_plots)
        pipeline.export_tables(str(best_output_dir))
        pipeline.plot_monitoring_summary_table(
            output_dir = str(best_output_dir),
            show       = show_plots,
            export_csv = True,
        )

        print(f"\nBest-run outputs saved to: {best_output_dir.resolve()}")
        return pipeline

    # ----------------------------------------------------------
    # Visualisation
    # ----------------------------------------------------------

    def plot_leaderboard(self) -> None:
        if self.leaderboard is None or self.leaderboard.empty:
            print("No results to plot.")
            return

        ok = self.leaderboard.loc[self.leaderboard["status"].eq("ok")].copy()
        if ok.empty:
            print("No successful trials to plot.")
            return

        # ── 1. Score distribution ──────────────────────────────────────────────
        fig1 = px.histogram(
            ok, x="score", nbins=30,
            title="Composite score distribution across trials",
            labels={"score": "Composite score"},
            template="plotly_white",
        )
        fig1.add_vline(
            x=float(ok["score"].max()), line_dash="dash", line_color="red",
            annotation_text="Best", annotation_position="top right",
        )
        fig1.show()

        # ── 2. R² vs % significant ─────────────────────────────────────────────
        fig2 = px.scatter(
            ok, x="hmm_r2", y="pct_significant_p05",
            color="hmm_covariance_type", size="score",
            hover_data=["trial_id", "score", "n_features_used", "hmm_features_used"],
            title="HMM R² vs fraction of significant coefficients (p < 0.05)",
            labels={"hmm_r2": "HMM R²", "pct_significant_p05": "% significant (p<0.05)"},
            template="plotly_white",
        )
        fig2.show()

        # ── 3. Score by hyperparameter ─────────────────────────────────────────
        for dim in ["hmm_covariance_type", "ols_cov_type", "n_pca_components",
                    "min_regime_duration", "hmm_include_pc1", "standardize_features"]:
            if dim not in ok.columns:
                continue
            fig = px.box(
                ok, x=dim, y="score", points="all",
                title=f"Score distribution by {dim}",
                template="plotly_white",
            )
            fig.show()

        # ── 4. Score convergence over trials ──────────────────────────────────
        ok_sorted = ok.sort_values("trial_id")
        ok_sorted["running_best"] = ok_sorted["score"].cummax()
        fig4 = px.line(
            ok_sorted, x="trial_id", y=["score", "running_best"],
            title="Composite score per trial and running best",
            labels={"trial_id": "Trial", "value": "Score"},
            template="plotly_white",
        )
        fig4.show()

        # ── 5. Top-10 leaderboard table ────────────────────────────────────────
        top10 = ok.head(10)[
            ["rank", "score", "hmm_r2", "pct_significant_p05",
             "avg_self_transition", "n_features_used",
             "hmm_covariance_type", "ols_cov_type",
             "n_pca_components", "min_regime_duration"]
        ].round(4)

        fig5 = go.Figure(data=[go.Table(
            header=dict(
                values=[f"<b>{c}</b>" for c in top10.columns],
                fill_color="#1f2937",
                font=dict(color="white", size=11),
                align="center", height=28,
            ),
            cells=dict(
                values=[top10[c].tolist() for c in top10.columns],
                fill_color=["#f8fafc" if i % 2 == 0 else "#ffffff"
                            for i in range(len(top10.columns))],
                align="center", height=25, font=dict(size=11),
            ),
        )])
        fig5.update_layout(
            title="Top-10 trials leaderboard",
            width=1300,
            height=max(380, 60 + 28 * len(top10)),
            margin=dict(l=10, r=10, t=60, b=10),
        )
        fig5.show()

    # ----------------------------------------------------------
    # Internal helpers
    # ----------------------------------------------------------

    def _load_base_features(self) -> list[str]:
        feat_df          = pd.read_csv(SELECTED_FEATURES_PATH)
        feat_df.columns  = [str(c).upper().strip() for c in feat_df.columns]
        feat_df["FEATURE"] = feat_df["FEATURE"].astype(str).str.upper().str.strip()
        features = [
            f for f in feat_df["FEATURE"].tolist()
            if is_allowed_model_input_feature(f)
            and (self.use_latam or not is_latam_specific_feature(f))
        ]
        return features

    def _sample_params(self, rng: np.random.Generator) -> dict[str, Any]:
        return {
            k: rng.choice(v).item() if isinstance(rng.choice(v), np.generic)
               else rng.choice(v)
            for k, v in SEARCH_SPACE.items()
        }

    def _save_leaderboard(self) -> None:
        if not self.results:
            return
        df = pd.DataFrame(self.results)
        ok = df.loc[df["status"].eq("ok")].sort_values("score", ascending=False).copy()
        ok.insert(0, "rank", range(1, len(ok) + 1))
        err = df.loc[df["status"].ne("ok")].copy()
        err.insert(0, "rank", np.nan)
        self.leaderboard = pd.concat([ok, err], ignore_index=True)

        # Keep only defined columns in order
        avail = [c for c in self.LEADERBOARD_COLS if c in self.leaderboard.columns]
        extra = [c for c in self.leaderboard.columns if c not in avail]
        self.leaderboard = self.leaderboard[avail + extra].copy()

        path = OPTIMIZER_OUTPUT_DIR / "optimizer_leaderboard.csv"
        self.leaderboard.to_csv(path, index=False)

    def _print_summary(self) -> None:
        ok = [r for r in self.results if r["status"] == "ok"]
        print("\n" + "=" * 78)
        print("OPTIMIZER SUMMARY")
        print("=" * 78)
        print(f"Total trials      : {self.n_iterations}")
        print(f"Successful trials : {len(ok)}")
        print(f"Failed trials     : {self.n_iterations - len(ok)}")
        if ok:
            scores = [r["score"] for r in ok]
            print(f"Score  mean/std   : {np.mean(scores):.4f} / {np.std(scores):.4f}")
            print(f"Score  min/max    : {np.min(scores):.4f} / {np.max(scores):.4f}")
            print(f"Best score        : {self.best_score:.4f}")
            print("Best parameters:")
            if self.best_params:
                for k, v in self.best_params.items():
                    print(f"  {k:<30} : {v}")
        print(f"\nLeaderboard saved : {OPTIMIZER_OUTPUT_DIR / 'optimizer_leaderboard.csv'}")
        print("=" * 78)


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":

    # ── Verify inputs ──────────────────────────────────────────────────────────
    if not MASTER_CLEAN_PATH.exists():
        raise FileNotFoundError(
            f"MASTER_CLEAN.xlsx not found:\n  {MASTER_CLEAN_PATH}\n"
            "Run data_cleaning.py first."
        )
    if not SELECTED_FEATURES_PATH.exists():
        raise FileNotFoundError(
            f"selected_features.csv not found:\n  {SELECTED_FEATURES_PATH}\n"
            "Run data_cleaning.py first."
        )

    # ======================================================
    # USER SETTINGS — EDIT HERE
    # ======================================================

    # ── How many random configurations to test ────────────────────────────────
    N_ITERATIONS: int = 20      # ← change this (e.g. 20 for a quick test,
                                #   200+ for a thorough search)

    # ── Universe ──────────────────────────────────────────────────────────────
    UNIVERSE_MODE: str = "LATAM"    # "LATAM" | "ALL_EM"

    # ── Reproducibility ───────────────────────────────────────────────────────
    RANDOM_SEED: int = 42

    # ── After the search: re-run the best config with plots and full export ───
    RERUN_BEST: bool  = True
    SHOW_PLOTS: bool  = True

    # ── Optional: override the default composite score weights ────────────────
    # Leave empty {} to use the defaults (R²=0.40, AdjR²=0.20, Sig=0.25, Persist=0.15)
    SCORE_WEIGHTS: dict = {}
    # Example override:
    # SCORE_WEIGHTS = {"w_r2": 0.50, "w_adj": 0.10, "w_sig": 0.30, "w_persist": 0.10}

    # ======================================================
    # Run
    # ======================================================
    OPTIMIZER_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    print(f"\npath_config loaded        : OK")
    print(f"Input  MASTER_CLEAN       : {MASTER_CLEAN_PATH}")
    print(f"Input  selected_features  : {SELECTED_FEATURES_PATH}")
    print(f"Output optimizer_results/ : {OPTIMIZER_OUTPUT_DIR}")

    optimizer = PipelineOptimizer(
        n_iterations  = N_ITERATIONS,
        universe_mode = UNIVERSE_MODE,
        random_seed   = RANDOM_SEED,
        score_weights = SCORE_WEIGHTS,
    )

    leaderboard = optimizer.run()

    optimizer.plot_leaderboard()

    if RERUN_BEST:
        best_pipeline = optimizer.rerun_best(show_plots=SHOW_PLOTS)

    print("\nOptimizer complete.")
    print(f"Leaderboard : {OPTIMIZER_OUTPUT_DIR / 'optimizer_leaderboard.csv'}")
    if RERUN_BEST:
        print(f"Best run    : {OPTIMIZER_OUTPUT_DIR / 'best_run/'}")

# %%
