#!/usr/bin/env python3
"""
generate_latex_snippets.py
Reads all result CSVs from model_results/ and writes
one .tex file per table into model_results/tex_files/.

Files produced (9 total):
    tab_sample_summary.tex
    tab_model_comparison.tex
    tab_baseline_block_shares.tex
    tab_pca_variance.tex
    tab_hmm_component_shares.tex
    tab_regime_durations.tex
    tab_transition_matrix.tex
    tab_regime_component_profile.tex
    tab_top_coefficients.tex

Usage:
    python generate_latex_snippets.py
"""

from pathlib import Path
import numpy as np
import pandas as pd

# ── Paths ─────────────────────────────────────────────────────────────────────
from path_config import OUTPUT_DIR

RESULTS_DIR : Path = OUTPUT_DIR / "model_results"
TEX_DIR     : Path = RESULTS_DIR / "tex_files"
TEX_DIR.mkdir(parents=True, exist_ok=True)

REGIME_ORDER = ["Calm", "Transitional", "Stress"]

# =============================================================================
# Helpers
# =============================================================================

def load(filename: str) -> pd.DataFrame:
    path = RESULTS_DIR / filename
    if not path.exists():
        print(f"  WARNING: {filename} not found — skipping.")
        return pd.DataFrame()
    return pd.read_csv(path)


def write_tex(filename: str, content: str) -> None:
    path = TEX_DIR / filename
    path.write_text(content.strip() + "\n")
    print(f"  Written: {filename}")


def fmt_float(value, decimals: int = 4) -> str:
    if value is None:
        return "n/a"
    try:
        if np.isnan(float(value)):
            return "n/a"
    except Exception:
        return str(value)
    return f"{float(value):.{decimals}f}"


def fmt_pct(value, decimals: int = 1) -> str:
    if value is None:
        return "n/a"
    try:
        if np.isnan(float(value)):
            return "n/a"
    except Exception:
        return str(value)
    return f"{100.0 * float(value):.{decimals}f}\\%"


def fmt_int(value) -> str:
    if value is None:
        return "n/a"
    try:
        if np.isnan(float(value)):
            return "n/a"
    except Exception:
        return str(value)
    return f"{int(float(value)):,}"


# =============================================================================
# 1. Sample summary
# =============================================================================
print("Processing results_sample_summary.csv …")
df = load("results_sample_summary.csv")
if not df.empty:
    sr = dict(zip(df["Metric"], df["Value"]))

    rows = [
        ("Observations",           fmt_int(sr.get("N_observations")),       "Bond-period rows after all filters"),
        ("Periods (ISO-weeks)",     fmt_int(sr.get("N_periods")),            "Unique YEAR\\_WEEK values"),
        ("ISINs",                   fmt_int(sr.get("N_ISINs")),              "Unique bonds"),
        ("Model features",          fmt_int(sr.get("N_features")),           "After correlation and VIF screens"),
        ("Target mean abs.",        fmt_float(sr.get("Target_mean_abs"), 4), "Weekly pct-change of Z-spread"),
        ("Target std.",             fmt_float(sr.get("Target_std"), 4),      ""),
        ("Baseline OLS $R^2$",      fmt_pct(sr.get("Baseline_R2")),         "Observable blocks only"),
        ("Baseline Adj.\\ $R^2$",   fmt_pct(sr.get("Baseline_AdjR2")),      ""),
        ("HMM-cond.\\ $R^2$",       fmt_pct(sr.get("HMM_R2")),              "Full regime-aware decomposition"),
        ("HMM-cond.\\ Adj.\\ $R^2$",fmt_pct(sr.get("HMM_AdjR2")),          ""),
        ("PC1 variance share",      fmt_pct(sr.get("PC1_variance_share")),  "Latent common factor strength"),
        ("Avg.\\ self-transition",  fmt_pct(sr.get("Avg_self_transition")), "Regime persistence"),
    ]

    body = "\n".join(
        f"    {metric} & {value} & {note} \\\\"
        for metric, value, note in rows
    )

    write_tex("tab_sample_summary.tex", f"""
\\begin{{tabular}}{{lrl}}
\\toprule
\\textbf{{Metric}} & \\textbf{{Value}} & \\textbf{{Notes}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 2. Model comparison
# =============================================================================
print("Processing results_model_comparison.csv …")
df = load("results_model_comparison.csv")
if not df.empty:
    labels = [
        "Observable blocks only",
        "+ Residual PCA factors",
        "+ Regime probs.\\ \\& interactions",
    ]
    lines = []
    for i, (row, label) in enumerate(zip(df.itertuples(index=False), labels), start=1):
        r2     = fmt_pct(getattr(row, "R2",     None))
        adjr2  = fmt_pct(getattr(row, "Adj_R2", None))
        rmse   = fmt_float(getattr(row, "RMSE", None), 4)
        mae    = fmt_float(getattr(row, "MAE",  None), 4)
        lines.append(f"    {i}.\\ {getattr(row, 'Model', f'Model {i}').split('. ', 1)[-1]} "
                     f"& {r2} & {adjr2} & {rmse} & {mae} & {label} \\\\")

    body = "\n".join(lines)
    write_tex("tab_model_comparison.tex", f"""
\\begin{{tabular}}{{lccccl}}
\\toprule
\\textbf{{Model}} & \\textbf{{$R^2$}} & \\textbf{{Adj.\\ $R^2$}}
    & \\textbf{{RMSE}} & \\textbf{{MAE}} & \\textbf{{Augmentation}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 3. Baseline block shares
# =============================================================================
print("Processing results_baseline_block_shares.csv …")
df = load("results_baseline_block_shares.csv")
if not df.empty:
    col = "Share_of_explained_abs_contribution"
    descriptions = {
        "Global":   "VIX, MOVE, CDX, FCI, GPR, equity indices",
        "Emerging": "EMBI, MSCI EM, LATAM CDS, country GPR",
        "Bonds":    "Coupon, age, size, seniority, sector dummies",
    }
    lines = []
    for _, row in df.iterrows():
        block = str(row["Risk_block"]).strip()
        share = fmt_pct(float(row[col]))
        desc  = descriptions.get(block, "")
        lines.append(f"    {block} & {share} & {desc} \\\\")
    lines.append(r"    \textit{Total} & 100.0\% & \\")

    body = "\n".join(lines)
    write_tex("tab_baseline_block_shares.tex", f"""
\\begin{{tabular}}{{lcc}}
\\toprule
\\textbf{{Risk block}} & \\textbf{{Share of abs.\\ contribution}} & \\textbf{{Content}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 4. PCA variance
# =============================================================================
print("Processing results_pca_variance.csv …")
df = load("results_pca_variance.csv")
if not df.empty:
    interps = {
        "PC1": "Latent common spread factor",
        "PC2": "Secondary common component",
        "PC3": "Tertiary common component",
    }
    lines = []
    for _, row in df.iterrows():
        comp  = str(row["Component"]).strip()
        evr   = fmt_pct(float(row["Explained_variance_ratio"]))
        cum   = fmt_pct(float(row["Cumulative_explained_variance"]))
        interp = interps.get(comp, "")
        lines.append(f"    {comp} & {evr} & {cum} & {interp} \\\\")

    body = "\n".join(lines)
    write_tex("tab_pca_variance.tex", f"""
\\begin{{tabular}}{{lccc}}
\\toprule
\\textbf{{Component}} & \\textbf{{Explained variance}}
    & \\textbf{{Cumulative}} & \\textbf{{Interpretation}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 5. HMM component shares
# =============================================================================
print("Processing results_hmm_component_shares.csv …")
df = load("results_hmm_component_shares.csv")
if not df.empty:
    descriptions = {
        "Global":   "Global macro and financial conditions",
        "Emerging": "LATAM and EM risk factors",
        "Bonds":    "Bond-level structural controls",
        "Latent":   "Common residual repricing ($\\widehat{PC}_1$)",
        "Regime":   "HMM regime probability loadings",
    }
    lines = []
    for _, row in df.iterrows():
        comp  = str(row["Risk_component"]).strip()
        share = fmt_pct(float(row["Share_of_abs_contribution"]))
        desc  = descriptions.get(comp, "")
        lines.append(f"    {comp} & {share} & {desc} \\\\")
    lines.append(r"    \textit{Total} & 100.0\% & \\")

    body = "\n".join(lines)
    write_tex("tab_hmm_component_shares.tex", f"""
\\begin{{tabular}}{{lcc}}
\\toprule
\\textbf{{Component}} & \\textbf{{Share of abs.\\ contribution}} & \\textbf{{Description}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 6. Regime durations
# =============================================================================
print("Processing results_regime_durations.csv …")
df = load("results_regime_durations.csv")
if not df.empty:
    df = df.set_index("Regime").reindex(REGIME_ORDER).reset_index()
    lines = []
    for _, row in df.iterrows():
        regime = str(row["Regime"])
        nruns  = fmt_int(row["N_runs"])
        mean   = fmt_float(row["Mean_duration"],   1)
        median = fmt_float(row["Median_duration"], 1)
        maxd   = fmt_int(row["Max_duration"])
        lines.append(f"    {regime} & {nruns} & {mean} & {median} & {maxd} \\\\")

    body = "\n".join(lines)
    write_tex("tab_regime_durations.tex", f"""
\\begin{{tabular}}{{lcccc}}
\\toprule
\\textbf{{Regime}} & \\textbf{{N runs}} & \\textbf{{Mean duration}}
    & \\textbf{{Median duration}} & \\textbf{{Max duration}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 7. Transition matrix
# =============================================================================
print("Processing results_regime_transition_matrix.csv …")
df = load("results_regime_transition_matrix.csv")
if not df.empty:
    df = df.set_index(df.columns[0]).reindex(index=REGIME_ORDER, columns=REGIME_ORDER)
    lines = []
    for regime in REGIME_ORDER:
        if regime not in df.index:
            continue
        cells = " & ".join(fmt_pct(df.loc[regime, c]) for c in REGIME_ORDER)
        lines.append(f"    \\textbf{{{regime}}} & {cells} \\\\")

    body = "\n".join(lines)
    write_tex("tab_transition_matrix.tex", f"""
\\begin{{tabular}}{{lccc}}
\\toprule
& \\textbf{{$\\to$ Calm}} & \\textbf{{$\\to$ Transitional}} & \\textbf{{$\\to$ Stress}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 8. Regime × component profile
# =============================================================================
print("Processing results_regime_component_profile.csv …")
df = load("results_regime_component_profile.csv")
if not df.empty:
    if "Regime_State" in df.columns and "Component" in df.columns:
        wide = df.pivot(
            index="Regime_State", columns="Component",
            values="Mean_abs_contribution",
        )
    else:
        wide = df.set_index(df.columns[0])

    wide = wide.reindex(index=REGIME_ORDER)
    comp_cols = ["Global", "Emerging", "Bonds", "Latent", "Regime"]
    lines = []
    for regime in REGIME_ORDER:
        if regime not in wide.index:
            continue
        cells = " & ".join(
            fmt_float(wide.loc[regime, c], 4) if c in wide.columns else "n/a"
            for c in comp_cols
        )
        lines.append(f"    {regime} & {cells} \\\\")

    body = "\n".join(lines)
    write_tex("tab_regime_component_profile.tex", f"""
\\begin{{tabular}}{{lccccc}}
\\toprule
\\textbf{{Regime}} & \\textbf{{Global}} & \\textbf{{Emerging}}
    & \\textbf{{Bonds}} & \\textbf{{Latent}} & \\textbf{{Regime}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
# 9. Top-20 coefficients
# =============================================================================
print("Processing results_top_coefficients.csv …")
df = load("results_top_coefficients.csv")
if not df.empty:
    lines = []
    for _, row in df.head(20).iterrows():
        feat  = str(row["Feature"]).replace("_", r"\_")
        block = str(row.get("Block", ""))
        coef  = fmt_float(row["Coefficient"],     4)
        acoef = fmt_float(row["Abs_coefficient"], 4)
        lines.append(f"    {feat} & {block} & {coef} & {acoef} \\\\")

    body = "\n".join(lines)
    write_tex("tab_top_coefficients.tex", f"""
\\begin{{tabular}}{{llrr}}
\\toprule
\\textbf{{Feature}} & \\textbf{{Block}}
    & \\textbf{{Coefficient}} & \\textbf{{$|\\text{{Coeff.}}|$}} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
""")


# =============================================================================
print(f"\nAll table files written to: {TEX_DIR.resolve()}")
print("Use \\input{model_results/tex_files/tab_<name>} in your LaTeX document.")
