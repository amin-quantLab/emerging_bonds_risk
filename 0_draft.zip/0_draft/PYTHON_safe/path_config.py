"""Single source of truth for project data paths and filenames."""

from __future__ import annotations

import os
from pathlib import Path


DATA_DIR = Path(os.getenv(
    "THESIS_DATA_DIR",
    r"C:\Users\Utilisateur\Desktop\THESIS\DATASET",
))
INPUT_DIR  = DATA_DIR / "Input"
OUTPUT_DIR = DATA_DIR / "Output"

# ── Inputs ────────────────────────────────────────────────────────────────────
BBG_BONDS  = INPUT_DIR / "DATASET_BBG_EMUSTRUU.xlsx"
MACRO      = INPUT_DIR / "DATASET_MACRO.xlsx"
RFR        = INPUT_DIR / "DATASET_RFR.xlsx"
FX_LATAM   = INPUT_DIR / "DATASET_FX_RATES_LATAM.xlsx"
GPR        = INPUT_DIR / "DATASET_GPR.xls"
DATABASE   = INPUT_DIR / "master_dataset.db"

# ── Outputs ───────────────────────────────────────────────────────────────────
FX_RATES          = OUTPUT_DIR / "DATASET_FX_RATES.xlsx"
FEATURE_ENGINEERED= OUTPUT_DIR / "master_dataset_features_eng.xlsx"
SOFR_CURVE        = OUTPUT_DIR / "sofr_zero_curve_timeseries.xlsx"
Z_SPREADS         = OUTPUT_DIR / "bond_z_spreads.xlsx"

# ── Main pipeline files ───────────────────────────────────────────────────────
# Input to data_cleaning.py: the feature-engineered master workbook.
MASTER            = OUTPUT_DIR / "master_dataset_features_eng.xlsx"

# Output of data_cleaning.py: the cleaned, model-ready panel.
MASTER_clean      = OUTPUT_DIR / "MASTER_clean.xlsx"

# Screened feature list written by data_cleaning.py.
CLEAN_DATA        = OUTPUT_DIR / "dataset_cleanedReady.xlsx"
SELECTED_FEATURES = OUTPUT_DIR / "selected_features.csv"

DEFAULT_SHEET = "Worksheet"

DATABASE_EXCEL_CONFIG = {
    BBG_BONDS.name: {"mode": "first_sheet", "table_prefix": "em_bonds"},
    MACRO.name:     {"mode": "first_sheet", "table_prefix": "macro"},
    RFR.name:       {"mode": "all_sheets",  "table_prefix": "rfr"},
}
