# %% END-TO-END THESIS PIPELINE OPTIMIZER
#!/usr/bin/env python3
"""
End-to-end optimizer for the regime-aware EM corporate-bond thesis pipeline.

The optimizer controls all three empirical stages:
    1. feature_engineering.py
       Tests alternative rolling windows, macro transformations, liquidity
       windows, FX/GPR standardisation settings, and LATAM credit-risk methods.
    2. data_cleaning.py
       Runs the complete cleaning and screening pipeline for every generated
       feature dataset, varying correlation/VIF thresholds and panel choices.
    3. master_thesis_analysis.py
       Tests alternative feature subsets, PCA/HMM specifications, robust OLS
       covariance estimators, winsorisation bounds, and regime smoothing.

Search objective
----------------
The winning specification balances:
    - HMM-conditioned R² and adjusted R²;
    - fraction of statistically significant coefficients;
    - absolute contribution share of the Regime component;
    - incremental R² added by the HMM-conditioned specification;
    - significance of direct regime and block×regime terms;
    - minimum HMM stability/occupancy safeguards.

No plots are produced during search.  Only after the complete search does the
script copy the exact winning inputs, rerun the winning analysis with exports,
and display the final analysis and optimizer diagnostic plots.

Important inference note
------------------------
Searching directly on p-values and in-sample R² is specification selection.
The resulting p-values are therefore post-selection statistics, not untouched
confirmatory inference.  Keep the full leaderboard and report this procedure in
thesis methodology; ideally validate the winner on a held-out time period.
"""

from __future__ import annotations

import contextlib
import io
import json
import math
import re
import shutil
import sys
import tempfile
import traceback
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from path_config import DEFAULT_SHEET, OUTPUT_DIR

from cpt_feature_eng import (
    FeatureBuilderConfig,
    make_default_feature_config,
    run_feature_engineering,
)
from data_cleaning import (
    DataCleaningConfig,
    make_cleaning_config,
    run_cleaning,
)
from master_thesis_analysis import (
    RiskDecompositionConfig,
    RegimeRiskDecompositionPipeline,
    is_allowed_model_input_feature,
    is_latam_specific_feature,
    run_analysis,
)


# ==========================================================
# SEARCH SPACES
# ==========================================================

FEATURE_SEARCH_SPACE: dict[str, list[Any]] = {
    "macro_windows": [
        (3,), (5,), (10,), (21,),
        (3, 5), (5, 10), (3, 10),
    ],
    "macro_methods": [
        ("mean",),
        ("ewm",),
        ("median",),
        ("zscore",),
        ("mean", "zscore"),
        ("mean", "diff"),
    ],
    "zr_window": [10, 21, 42, 63],
    "zr_min_periods": [3, 5, 10],
    "roll_credit_risk_features": [False, True],
    "credit_zscore_window_weeks": [26, 52, 104],
    "credit_momentum_window_weeks": [2, 4, 8],
    "credit_vol_window_weeks": [8, 12, 26],
    "credit_max_stale_days": [7, 10, 14],
    "fx_zscore_window": [126, 252, 504],
    "fx_zscore_min_periods": [30, 60, 126],
    "fx_exclude_ars": [False, True],
    "gpr_zscore_window": [24, 36, 60, None],
    "gpr_momentum_window": [6, 12, 18],
    "gpr_vol_window": [6, 12, 24],
}

CLEANING_SEARCH_SPACE: dict[str, list[Any]] = {
    "target_mode": ["weekly_pct_change", "weekly_diff"],
    "target_lag_periods": [1, 2],
    "fixed_coupon_only": [True],
    "exclude_government": [True],
    "drop_option_bonds": [False, True],
    "corr_threshold": [0.70, 0.80, 0.90, 0.95],
    "vif_threshold": [5.0, 10.0, 15.0, 20.0],
    "time_fixed_effect": ["none", "year"],
    "max_dummy_levels": [20, 40],
    "max_corr_features": [30, 45, 60],
    "max_vif_features": [60, 90, 120],
}

MODEL_SEARCH_SPACE: dict[str, list[Any]] = {
    "feature_selection_method": ["all", "random", "block_random", "regime_focused"],
    "feature_fraction": [0.50, 0.70, 0.85, 1.00],
    "hmm_covariance_type": ["diag", "full", "tied", "spherical"],
    "hmm_n_starts": [10, 20, 30, 50],
    "hmm_max_features": [4, 5, 6, 7, 8],
    "n_pca_components": [2, 3, 4],
    "min_isins_per_period": [3, 5, 7],
    "min_regime_duration": [2, 3, 4, 5],
    "ols_cov_type": ["HC3", "HC1", "HC0"],
    "winsorize_lower": [0.005, 0.010, 0.020],
    "winsorize_upper": [0.980, 0.990, 0.995],
    "standardize_features": [True, False],
    "hmm_include_pc1": [True, False],
}

DEFAULT_SCORE_WEIGHTS: dict[str, float] = {
    "r2": 0.25,
    "adjusted_r2": 0.10,
    "significance": 0.20,
    "regime_component_share": 0.20,
    "regime_term_significance": 0.10,
    "regime_incremental_r2": 0.10,
    "regime_stability": 0.05,
}

ENGINEERED_PREFIX_RE = re.compile(r"^(?:MA|MED|EWM|ZS|DIFF|PCT)\d+_")
REGIME_FOCUS_TOKENS = (
    "VIX", "MOVE", "EMBI", "MSCI_EM", "CDS", "JPM_SPREAD",
    "GPR", "EPU", "BFCI", "CDX", "ITRX", "STOXX", "SP500",
    "AONILS", "LATAM", "BZSTSETA", "MXONBR",
)


# ==========================================================
# CONFIGURATION
# ==========================================================

@dataclass
class OptimizerConfig:
    n_data_variants: int = 6
    n_model_variants_per_data: int = 12
    universe_mode: str = "LATAM"
    random_seed: int = 42

    source_target_col: str = "Z_SPREAD_MID"
    sheet_name: int | str = DEFAULT_SHEET

    output_root: str = str(OUTPUT_DIR / "main_results")
    intermediate_format: str = "parquet"  # parquet | csv | xlsx

    show_final_plots: bool = True
    export_final_tables: bool = True
    keep_all_trial_artifacts: bool = False
    save_every_n_models: int = 10

    min_regime_occupancy: float = 0.02
    min_avg_self_transition: float = 0.50
    require_three_regimes: bool = True

    score_weights: dict[str, float] = field(
        default_factory=lambda: dict(DEFAULT_SCORE_WEIGHTS)
    )

    def __post_init__(self) -> None:
        self.universe_mode = str(self.universe_mode).upper().strip()
        if self.universe_mode not in {"LATAM", "ALL_EM"}:
            raise ValueError("universe_mode must be 'LATAM' or 'ALL_EM'.")
        if self.n_data_variants < 1 or self.n_model_variants_per_data < 1:
            raise ValueError("Both iteration counts must be >= 1.")
        self.intermediate_format = str(self.intermediate_format).lower().strip().lstrip(".")
        if self.intermediate_format not in {"parquet", "csv", "xlsx"}:
            raise ValueError("intermediate_format must be parquet, csv, or xlsx.")
        self.source_target_col = str(self.source_target_col).upper().strip()
        if self.source_target_col not in {"Z_SPREAD_MID", "Z_SPREAD_BPS"}:
            raise ValueError("source_target_col must be Z_SPREAD_MID or Z_SPREAD_BPS.")

        unknown = set(self.score_weights) - set(DEFAULT_SCORE_WEIGHTS)
        if unknown:
            raise ValueError(f"Unknown score weight(s): {sorted(unknown)}")
        merged = dict(DEFAULT_SCORE_WEIGHTS)
        merged.update(self.score_weights)
        total = float(sum(merged.values()))
        if total <= 0:
            raise ValueError("Score weights must sum to a positive value.")
        self.score_weights = {k: float(v) / total for k, v in merged.items()}

    @property
    def use_latam(self) -> bool:
        return self.universe_mode == "LATAM"

    @property
    def root(self) -> Path:
        return Path(self.output_root)


# ==========================================================
# SERIALIZATION / UTILITY HELPERS
# ==========================================================

def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (set, frozenset, tuple)):
        return list(value)
    if pd.isna(value):
        return None
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def json_dumps(value: Any) -> str:
    return json.dumps(value, default=_json_default, sort_keys=True)


def choose(rng: np.random.Generator, values: list[Any]) -> Any:
    return values[int(rng.integers(0, len(values)))]


def sample_space(rng: np.random.Generator, space: dict[str, list[Any]]) -> dict[str, Any]:
    return {key: choose(rng, values) for key, values in space.items()}


def silent_call(func, *args, **kwargs):
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(buffer):
        return func(*args, **kwargs)


def read_table(path: str | Path, sheet_name: int | str = 0) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path, sheet_name=sheet_name)
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix == ".parquet":
        return pd.read_parquet(path)
    raise ValueError(f"Unsupported table format: {path}")


def resolve_intermediate_format(requested: str) -> str:
    if requested != "parquet":
        return requested
    try:
        import pyarrow  # noqa: F401
        return "parquet"
    except Exception:
        print("pyarrow unavailable; intermediate format changed from parquet to csv.")
        return "csv"


def normalized_incremental_r2(value: float, reference_gain: float = 0.10) -> float:
    if pd.isna(value):
        return 0.0
    return float(np.clip(value / reference_gain, 0.0, 1.0))


@contextlib.contextmanager
def save_plotly_figures_as_html(output_dir: str | Path, show_figures: bool):
    """Save every Plotly figure shown inside the context as standalone HTML."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    original_show = go.Figure.show
    counter = 0

    def save_then_show(fig, *args, **kwargs):
        nonlocal counter
        counter += 1
        title = getattr(getattr(fig.layout, "title", None), "text", None) or f"plot_{counter:02d}"
        slug = re.sub(r"[^a-z0-9]+", "_", str(title).lower()).strip("_") or "plot"
        fig.write_html(
            output_dir / f"plot_{counter:02d}_{slug}.html",
            include_plotlyjs="cdn",
            full_html=True,
        )
        if show_figures:
            return original_show(fig, *args, **kwargs)
        return None

    go.Figure.show = save_then_show
    try:
        yield
    finally:
        go.Figure.show = original_show


# ==========================================================
# OBJECTIVE
# ==========================================================

def score_trial(
    metrics: dict[str, float],
    config: OptimizerConfig,
) -> tuple[float, bool, str]:
    """Return weighted score, eligibility flag, and any constraint reason."""
    reasons: list[str] = []

    n_regimes = int(metrics.get("n_regimes_identified", 0) or 0)
    min_occupancy = float(metrics.get("min_regime_occupancy", np.nan))
    avg_self = float(metrics.get("avg_self_transition", np.nan))

    if config.require_three_regimes and n_regimes != 3:
        reasons.append(f"n_regimes={n_regimes}")
    if pd.isna(min_occupancy) or min_occupancy < config.min_regime_occupancy:
        reasons.append(f"min_occupancy={min_occupancy:.4f}")
    if pd.isna(avg_self) or avg_self < config.min_avg_self_transition:
        reasons.append(f"avg_self_transition={avg_self:.4f}")

    values = {
        "r2": float(np.clip(metrics.get("hmm_r2", 0.0), 0.0, 1.0)),
        "adjusted_r2": float(np.clip(metrics.get("hmm_adj_r2", 0.0), 0.0, 1.0)),
        "significance": float(np.clip(metrics.get("pct_significant", 0.0), 0.0, 1.0)),
        "regime_component_share": float(
            np.clip(metrics.get("regime_component_share", 0.0), 0.0, 1.0)
        ),
        "regime_term_significance": float(
            np.clip(metrics.get("pct_regime_terms_significant", 0.0), 0.0, 1.0)
        ),
        "regime_incremental_r2": normalized_incremental_r2(
            metrics.get("regime_incremental_r2", 0.0)
        ),
        "regime_stability": float(np.clip(avg_self if pd.notna(avg_self) else 0.0, 0.0, 1.0)),
    }

    raw_score = float(sum(config.score_weights[k] * values[k] for k in values))
    eligible = not reasons
    # Keep failed-constraint models in the leaderboard, but ensure that a stable
    # admissible model wins whenever one exists.
    final_score = raw_score if eligible else raw_score * 0.50
    return final_score, eligible, " | ".join(reasons)


# ==========================================================
# FEATURE / HMM SUBSET SELECTION
# ==========================================================

def _strip_macro_prefix(feature: str) -> str:
    return ENGINEERED_PREFIX_RE.sub("", str(feature).upper().strip())


def _feature_type_column(feature_df: pd.DataFrame) -> str:
    for candidate in ["FEATURE_TYPE", "TYPE", "BLOCK"]:
        if candidate in feature_df.columns:
            return candidate
    return ""


def select_model_features(
    feature_df: pd.DataFrame,
    *,
    method: str,
    fraction: float,
    rng: np.random.Generator,
    use_latam: bool,
) -> list[str]:
    df = feature_df.copy()
    df.columns = [str(c).upper().strip() for c in df.columns]
    if "FEATURE" not in df.columns:
        raise KeyError("selected_features.csv must contain FEATURE.")

    df["FEATURE"] = df["FEATURE"].astype(str).str.upper().str.strip()
    df = df.loc[df["FEATURE"].map(is_allowed_model_input_feature)].copy()
    if not use_latam:
        df = df.loc[~df["FEATURE"].map(is_latam_specific_feature)].copy()
    df = df.drop_duplicates("FEATURE")

    all_features = df["FEATURE"].tolist()
    if not all_features:
        return []

    method = str(method).lower().strip()
    fraction = float(np.clip(fraction, 0.10, 1.00))
    target_n = max(6, min(len(all_features), int(math.ceil(len(all_features) * fraction))))

    if method == "all" or target_n >= len(all_features):
        return all_features

    if method == "random":
        idx = sorted(rng.choice(len(all_features), size=target_n, replace=False).tolist())
        return [all_features[i] for i in idx]

    if method == "block_random":
        type_col = _feature_type_column(df)
        if not type_col:
            return select_model_features(
                df, method="random", fraction=fraction, rng=rng, use_latam=use_latam
            )
        selected: list[str] = []
        for _, group in df.groupby(type_col, dropna=False):
            feats = group["FEATURE"].tolist()
            n = max(1, min(len(feats), int(math.ceil(len(feats) * fraction))))
            idx = sorted(rng.choice(len(feats), size=n, replace=False).tolist())
            selected.extend(feats[i] for i in idx)
        if len(selected) > target_n:
            idx = sorted(rng.choice(len(selected), size=target_n, replace=False).tolist())
            selected = [selected[i] for i in idx]
        return list(dict.fromkeys(selected))

    if method == "regime_focused":
        focused = [
            f for f in all_features
            if any(token in f for token in REGIME_FOCUS_TOKENS)
        ]
        other = [f for f in all_features if f not in set(focused)]
        selected = list(focused)
        remaining = max(0, target_n - len(selected))
        if remaining and other:
            n = min(remaining, len(other))
            idx = sorted(rng.choice(len(other), size=n, replace=False).tolist())
            selected.extend(other[i] for i in idx)
        if len(selected) > target_n:
            # Keep direct LATAM risk composites and sample the rest.
            mandatory = [f for f in selected if f.startswith("LATAM_")]
            optional = [f for f in selected if f not in mandatory]
            n_optional = max(0, target_n - len(mandatory))
            idx = sorted(rng.choice(len(optional), size=n_optional, replace=False).tolist())
            selected = mandatory + [optional[i] for i in idx]
        return list(dict.fromkeys(selected))

    raise ValueError(f"Unknown feature selection method: {method}")


def candidate_hmm_features(features: list[str], use_latam: bool) -> list[str]:
    candidates: list[str] = []
    for feature in features:
        name = str(feature).upper().strip()
        base = _strip_macro_prefix(name)
        if not use_latam and is_latam_specific_feature(name):
            continue
        if name.startswith("LATAM_") or any(token in base for token in REGIME_FOCUS_TOKENS):
            candidates.append(name)
    return list(dict.fromkeys(candidates))


def sample_hmm_features(
    model_features: list[str],
    max_features: int,
    rng: np.random.Generator,
    use_latam: bool,
) -> list[str]:
    pool = candidate_hmm_features(model_features, use_latam=use_latam)
    n = min(int(max_features), len(pool))
    if n < 2:
        return []
    # Guarantee core market-stress coverage when available, then randomize the rest.
    core_tokens = ("VIX", "MOVE", "EMBI", "MSCI_EM")
    core = []
    for token in core_tokens:
        hit = next((f for f in pool if token in f), None)
        if hit and hit not in core:
            core.append(hit)
    core = core[:n]
    remainder = [f for f in pool if f not in core]
    need = n - len(core)
    if need > 0:
        idx = sorted(rng.choice(len(remainder), size=need, replace=False).tolist())
        core.extend(remainder[i] for i in idx)
    return core


# ==========================================================
# OPTIMIZER
# ==========================================================

class EndToEndPipelineOptimizer:
    def __init__(self, config: OptimizerConfig) -> None:
        self.cfg = config
        self.rng = np.random.default_rng(config.random_seed)
        self.intermediate_format = resolve_intermediate_format(config.intermediate_format)

        # One persistent folder only. Trial artifacts are written outside OUTPUT_DIR
        # and removed after the winning specification is rerun.
        if self.cfg.root.exists():
            shutil.rmtree(self.cfg.root)
        self.cfg.root.mkdir(parents=True, exist_ok=True)

        self.trials_dir = Path(tempfile.mkdtemp(prefix="thesis_optimizer_trials_"))
        self.final_dir = self.cfg.root
        self.data_dir = self.final_dir / "data"
        self.html_plots_dir = self.final_dir / "html_plots"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.html_plots_dir.mkdir(parents=True, exist_ok=True)

        self.leaderboard_path = self.data_dir / "optimizer_leaderboard.csv"
        self.data_leaderboard_path = self.data_dir / "data_variant_leaderboard.csv"

        self.results: list[dict[str, Any]] = []
        self.data_results: list[dict[str, Any]] = []
        self.leaderboard: Optional[pd.DataFrame] = None
        self.best_result: Optional[dict[str, Any]] = None

    # ------------------------------------------------------
    # Search
    # ------------------------------------------------------

    def run(self) -> pd.DataFrame:
        print("\n" + "=" * 88)
        print("END-TO-END FEATURE → CLEANING → REGIME ANALYSIS OPTIMIZER")
        print("=" * 88)
        print(f"Data variants             : {self.cfg.n_data_variants}")
        print(f"Model variants / dataset  : {self.cfg.n_model_variants_per_data}")
        print(f"Total planned models      : {self.cfg.n_data_variants * self.cfg.n_model_variants_per_data}")
        print(f"Universe                  : {self.cfg.universe_mode}")
        print(f"Intermediate format       : {self.intermediate_format}")
        print(f"Output                    : {self.cfg.root}")
        print("Plots during search       : disabled")
        print("=" * 88)

        global_model_id = 0

        for data_id in range(1, self.cfg.n_data_variants + 1):
            data_dir = self.trials_dir / f"data_{data_id:04d}"
            data_dir.mkdir(parents=True, exist_ok=True)

            fe_params = self._sample_feature_params()
            clean_params = sample_space(self.rng, CLEANING_SEARCH_SPACE)

            print(f"\n[Data {data_id:>3}/{self.cfg.n_data_variants}] generating and cleaning dataset ...", end=" ", flush=True)
            data_result = self._run_data_variant(data_id, data_dir, fe_params, clean_params)
            self.data_results.append(data_result)

            if data_result["status"] != "ok":
                print("ERROR")
                print(str(data_result.get("error_message", ""))[:500])
                self._save_progress()
                continue

            print(
                f"OK — rows={data_result['n_rows']:,}, selected={data_result['n_selected_features']:,}"
            )

            for model_id in range(1, self.cfg.n_model_variants_per_data + 1):
                global_model_id += 1
                model_params = sample_space(self.rng, MODEL_SEARCH_SPACE)
                result = self._run_model_variant(
                    global_model_id=global_model_id,
                    data_id=data_id,
                    model_id=model_id,
                    data_result=data_result,
                    model_params=model_params,
                )
                self.results.append(result)

                if result["status"] == "ok":
                    flag = "eligible" if result["eligible"] else "penalized"
                    print(
                        f"  Model {model_id:>3}/{self.cfg.n_model_variants_per_data} "
                        f"score={result['score']:.4f} R²={result['hmm_r2']:.4f} "
                        f"sig={result['pct_significant']:.1%} "
                        f"regime={result['regime_component_share']:.1%} [{flag}]"
                    )
                else:
                    print(
                        f"  Model {model_id:>3}/{self.cfg.n_model_variants_per_data} ERROR — "
                        f"{str(result.get('error_message', ''))[:160]}"
                    )

                if global_model_id % self.cfg.save_every_n_models == 0:
                    self._save_progress()

            self._save_progress()

        self._finalize_leaderboard()
        if self.leaderboard is None or self.leaderboard.empty:
            raise RuntimeError("No successful model trial was produced.")

        self.best_result = self._select_best_result()
        self._materialize_and_rerun_best()
        self._save_progress()

        # Plots are generated only after the search and are always saved as HTML.
        self.plot_final_diagnostics()

        if not self.cfg.keep_all_trial_artifacts:
            self._cleanup_nonwinning_artifacts()

        self._print_summary()
        return self.leaderboard

    # ------------------------------------------------------
    # Stage 1 + 2: feature engineering and cleaning
    # ------------------------------------------------------

    def _sample_feature_params(self) -> dict[str, Any]:
        params = sample_space(self.rng, FEATURE_SEARCH_SPACE)
        weights = self.rng.dirichlet(np.array([6.0, 3.0, 1.0]))
        params["credit_level_weight"] = float(weights[0])
        params["credit_momentum_weight"] = float(weights[1])
        params["credit_vol_weight"] = float(weights[2])
        return params

    def _make_feature_config(self, params: dict[str, Any]) -> FeatureBuilderConfig:
        return make_default_feature_config(
            macro_windows=tuple(params["macro_windows"]),
            macro_methods=tuple(params["macro_methods"]),
            zr_window=int(params["zr_window"]),
            zr_min_periods=int(params["zr_min_periods"]),
            roll_credit_risk_features=bool(params["roll_credit_risk_features"]),
            credit_overrides={
                "zscore_window_weeks": int(params["credit_zscore_window_weeks"]),
                "momentum_window_weeks": int(params["credit_momentum_window_weeks"]),
                "vol_window_weeks": int(params["credit_vol_window_weeks"]),
                "max_stale_days": int(params["credit_max_stale_days"]),
                "level_weight": float(params["credit_level_weight"]),
                "momentum_weight": float(params["credit_momentum_weight"]),
                "vol_weight": float(params["credit_vol_weight"]),
            },
            fx_overrides={
                "zscore_window": int(params["fx_zscore_window"]),
                "zscore_min_periods": int(params["fx_zscore_min_periods"]),
                "exclude_ars": bool(params["fx_exclude_ars"]),
            },
            gpr_overrides={
                "zscore_window": params["gpr_zscore_window"],
                "momentum_window": int(params["gpr_momentum_window"]),
                "vol_window": int(params["gpr_vol_window"]),
            },
        )

    def _run_data_variant(
        self,
        data_id: int,
        data_dir: Path,
        feature_params: dict[str, Any],
        cleaning_params: dict[str, Any],
    ) -> dict[str, Any]:
        extension = self.intermediate_format
        feature_path = data_dir / f"feature_engineered.{extension}"
        clean_path = data_dir / f"master_clean.{extension}"
        selected_path = data_dir / "selected_features.csv"

        result: dict[str, Any] = {
            "data_id": data_id,
            "status": "error",
            "feature_path": str(feature_path),
            "clean_path": str(clean_path),
            "selected_features_path": str(selected_path),
            "feature_params_json": json_dumps(feature_params),
            "cleaning_params_json": json_dumps(cleaning_params),
            "n_rows": 0,
            "n_selected_features": 0,
            "error_message": "",
        }

        try:
            feature_config = self._make_feature_config(feature_params)
            silent_call(run_feature_engineering, feature_config, feature_path)

            cleaning_config = make_cleaning_config(
                data_path=feature_path,
                output_dataset=clean_path,
                output_features=selected_path,
                sheet_name=0,
                target_col=self.cfg.source_target_col,
                target_mode=str(cleaning_params["target_mode"]),
                target_lag_periods=int(cleaning_params["target_lag_periods"]),
                latam_only=self.cfg.use_latam,
                fixed_coupon_only=bool(cleaning_params["fixed_coupon_only"]),
                exclude_government=bool(cleaning_params["exclude_government"]),
                drop_option_bonds=bool(cleaning_params["drop_option_bonds"]),
                corr_threshold=float(cleaning_params["corr_threshold"]),
                vif_threshold=float(cleaning_params["vif_threshold"]),
                time_fixed_effect=str(cleaning_params["time_fixed_effect"]),
                max_dummy_levels=int(cleaning_params["max_dummy_levels"]),
                max_corr_features=int(cleaning_params["max_corr_features"]),
                max_vif_features=int(cleaning_params["max_vif_features"]),
            )
            pipeline = silent_call(
                run_cleaning,
                cleaning_config,
                show_plots=False,
                sanitize_features=True,
            )

            if not clean_path.exists() or not selected_path.exists():
                raise FileNotFoundError("Cleaning stage did not produce required outputs.")

            result.update({
                "status": "ok",
                "n_rows": int(len(pipeline.df)) if pipeline.df is not None else 0,
                "n_selected_features": int(len(pipeline.selected_features)),
            })
        except Exception:
            result["error_message"] = traceback.format_exc(limit=8)

        return result

    # ------------------------------------------------------
    # Stage 3: analysis specifications
    # ------------------------------------------------------

    def _run_model_variant(
        self,
        *,
        global_model_id: int,
        data_id: int,
        model_id: int,
        data_result: dict[str, Any],
        model_params: dict[str, Any],
    ) -> dict[str, Any]:
        model_dir = self.trials_dir / f"data_{data_id:04d}" / f"model_{model_id:04d}"
        model_dir.mkdir(parents=True, exist_ok=True)
        exact_features_path = model_dir / "selected_features_exact.csv"

        result: dict[str, Any] = {
            "global_model_id": global_model_id,
            "data_id": data_id,
            "model_id": model_id,
            "status": "error",
            "eligible": False,
            "score": np.nan,
            "constraint_reason": "",
            "feature_path": data_result["feature_path"],
            "clean_path": data_result["clean_path"],
            "base_selected_features_path": data_result["selected_features_path"],
            "exact_selected_features_path": str(exact_features_path),
            "feature_params_json": data_result["feature_params_json"],
            "cleaning_params_json": data_result["cleaning_params_json"],
            "model_params_json": json_dumps(model_params),
            "exact_features_json": "[]",
            "hmm_features_json": "[]",
            "error_message": "",
        }

        try:
            feature_df = pd.read_csv(data_result["selected_features_path"])
            selected = select_model_features(
                feature_df,
                method=str(model_params["feature_selection_method"]),
                fraction=float(model_params["feature_fraction"]),
                rng=self.rng,
                use_latam=self.cfg.use_latam,
            )
            if len(selected) < 4:
                raise ValueError(f"Only {len(selected)} model features selected.")

            normalized = feature_df.copy()
            normalized.columns = [str(c).upper().strip() for c in normalized.columns]
            normalized["FEATURE"] = normalized["FEATURE"].astype(str).str.upper().str.strip()
            exact_df = normalized.loc[normalized["FEATURE"].isin(selected)].copy()
            exact_df.to_csv(exact_features_path, index=False)

            hmm_features = sample_hmm_features(
                selected,
                max_features=int(model_params["hmm_max_features"]),
                rng=self.rng,
                use_latam=self.cfg.use_latam,
            )
            if len(hmm_features) < 2:
                raise ValueError("Fewer than two valid HMM state features.")

            cleaning_params = json.loads(data_result["cleaning_params_json"])
            analysis_config = RiskDecompositionConfig(
                data_path=data_result["clean_path"],
                features_path=str(exact_features_path),
                sheet_name=0,
                universe_mode=self.cfg.universe_mode,
                use_latam_specific_inputs=self.cfg.use_latam,
                target_col="MODEL_TARGET_LEVEL",
                regime_target_col="MODEL_TARGET",
                source_target_col=self.cfg.source_target_col,
                target_mode_label=str(cleaning_params["target_mode"]),
                winsorize_target=True,
                winsorize_lower=float(model_params["winsorize_lower"]),
                winsorize_upper=float(model_params["winsorize_upper"]),
                ols_cov_type=str(model_params["ols_cov_type"]),
                standardize_features=bool(model_params["standardize_features"]),
                n_pca_components=int(model_params["n_pca_components"]),
                min_isins_per_period=int(model_params["min_isins_per_period"]),
                n_regimes=3,
                hmm_covariance_type=str(model_params["hmm_covariance_type"]),
                hmm_n_iter=400,
                hmm_tol=1e-4,
                hmm_n_starts=int(model_params["hmm_n_starts"]),
                hmm_random_state=self.cfg.random_seed + global_model_id,
                hmm_include_pc1=bool(model_params["hmm_include_pc1"]),
                hmm_features=hmm_features,
                hmm_auto_select_features=False,
                hmm_max_features=int(model_params["hmm_max_features"]),
                smooth_regime_states=True,
                min_regime_duration=int(model_params["min_regime_duration"]),
                output_dir=str(model_dir / "analysis_output"),
            )

            pipeline: RegimeRiskDecompositionPipeline = silent_call(
                run_analysis,
                analysis_config,
                show_plots=False,
                export_tables=False,
                show_monitoring_table=False,
            )
            metrics = pipeline.extract_objective_metrics(alpha=0.05)
            score, eligible, reason = score_trial(metrics, self.cfg)

            result.update({
                "status": "ok",
                "eligible": bool(eligible),
                "score": float(score),
                "constraint_reason": reason,
                "exact_features_json": json_dumps(selected),
                "hmm_features_json": json_dumps(hmm_features),
                **{key: value for key, value in metrics.items()},
                **{f"model_{key}": value for key, value in model_params.items()},
            })

        except Exception:
            result["error_message"] = traceback.format_exc(limit=8)

        return result

    # ------------------------------------------------------
    # Ranking and exact final rerun
    # ------------------------------------------------------

    def _finalize_leaderboard(self) -> None:
        if not self.results:
            self.leaderboard = pd.DataFrame()
            return
        df = pd.DataFrame(self.results)
        ok = df.loc[df["status"].eq("ok")].copy()
        err = df.loc[~df["status"].eq("ok")].copy()
        if not ok.empty:
            ok = ok.sort_values(
                ["eligible", "score", "hmm_r2", "pct_significant", "regime_component_share"],
                ascending=[False, False, False, False, False],
            ).reset_index(drop=True)
            ok.insert(0, "rank", np.arange(1, len(ok) + 1))
        if not err.empty:
            err.insert(0, "rank", np.nan)
        self.leaderboard = pd.concat([ok, err], ignore_index=True, sort=False)
        self.leaderboard.to_csv(self.leaderboard_path, index=False)

    def _select_best_result(self) -> dict[str, Any]:
        if self.leaderboard is None:
            raise RuntimeError("Leaderboard not built.")
        ok = self.leaderboard.loc[self.leaderboard["status"].eq("ok")].copy()
        if ok.empty:
            raise RuntimeError("No successful model trial.")
        eligible = ok.loc[ok["eligible"].astype(bool)]
        winner = eligible.iloc[0] if not eligible.empty else ok.iloc[0]
        return winner.to_dict()

    def _materialize_and_rerun_best(self) -> RegimeRiskDecompositionPipeline:
        if self.best_result is None:
            raise RuntimeError("Best result not selected.")

        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.html_plots_dir.mkdir(parents=True, exist_ok=True)

        source_clean = Path(self.best_result["clean_path"])
        source_exact_features = Path(self.best_result["exact_selected_features_path"])

        # Keep only presentation outputs in OUTPUT_DIR/main_results.
        # The winning cleaned dataset remains temporary and is removed afterward.
        final_clean = source_clean
        final_features = self.data_dir / "selected_features.csv"
        shutil.copy2(source_exact_features, final_features)

        model_params = json.loads(self.best_result["model_params_json"])
        cleaning_params = json.loads(self.best_result["cleaning_params_json"])
        hmm_features = json.loads(self.best_result["hmm_features_json"])

        config = RiskDecompositionConfig(
            data_path=str(final_clean),
            features_path=str(final_features),
            sheet_name=0,
            universe_mode=self.cfg.universe_mode,
            use_latam_specific_inputs=self.cfg.use_latam,
            target_col="MODEL_TARGET_LEVEL",
            regime_target_col="MODEL_TARGET",
            source_target_col=self.cfg.source_target_col,
            target_mode_label=str(cleaning_params["target_mode"]),
            winsorize_target=True,
            winsorize_lower=float(model_params["winsorize_lower"]),
            winsorize_upper=float(model_params["winsorize_upper"]),
            ols_cov_type=str(model_params["ols_cov_type"]),
            standardize_features=bool(model_params["standardize_features"]),
            n_pca_components=int(model_params["n_pca_components"]),
            min_isins_per_period=int(model_params["min_isins_per_period"]),
            n_regimes=3,
            hmm_covariance_type=str(model_params["hmm_covariance_type"]),
            hmm_n_iter=500,
            hmm_tol=1e-4,
            hmm_n_starts=int(model_params["hmm_n_starts"]),
            hmm_random_state=self.cfg.random_seed + int(self.best_result["global_model_id"]),
            hmm_include_pc1=bool(model_params["hmm_include_pc1"]),
            hmm_features=hmm_features,
            hmm_auto_select_features=False,
            hmm_max_features=int(model_params["hmm_max_features"]),
            smooth_regime_states=True,
            min_regime_duration=int(model_params["min_regime_duration"]),
            output_dir=str(self.data_dir),
        )

        print("\n" + "=" * 88)
        print("FINAL RERUN OF THE EXACT WINNING SPECIFICATION")
        print("=" * 88)
        print(f"Score                     : {float(self.best_result['score']):.4f}")
        print(f"HMM R²                    : {float(self.best_result['hmm_r2']):.4f}")
        print(f"Significant coefficients  : {float(self.best_result['pct_significant']):.1%}")
        print(f"Regime contribution share : {float(self.best_result['regime_component_share']):.1%}")
        print(f"Regime incremental R²     : {float(self.best_result['regime_incremental_r2']):.4f}")
        print("=" * 88)

        with save_plotly_figures_as_html(
            self.html_plots_dir,
            show_figures=self.cfg.show_final_plots,
        ):
            pipeline = run_analysis(
                config,
                show_plots=True,
                export_tables=self.cfg.export_final_tables,
                show_monitoring_table=True,
            )

        # Export every feature that actually remains in the winning baseline OLS,
        # together with its robust p-value and 95% confidence interval.
        self.plot_best_feature_significance(pipeline)

        best_config_payload = {
            "optimizer": asdict(self.cfg),
            "best_result": self.best_result,
            "feature_params": json.loads(self.best_result["feature_params_json"]),
            "cleaning_params": cleaning_params,
            "model_params": model_params,
            "exact_features": json.loads(self.best_result["exact_features_json"]),
            "hmm_features": hmm_features,
            "final_paths": {
                "selected_features": str(final_features),
                "data_folder": str(self.data_dir),
                "html_plots_folder": str(self.html_plots_dir),
            },
        }

        # Keep every HTML output in the dedicated HTML folder.
        for html_file in self.data_dir.glob("*.html"):
            shutil.move(str(html_file), self.html_plots_dir / html_file.name)

        (self.data_dir / "best_configuration.json").write_text(
            json.dumps(best_config_payload, indent=2, default=_json_default),
            encoding="utf-8",
        )
        return pipeline

    # ------------------------------------------------------
    # Winning-feature coefficient and significance plot
    # ------------------------------------------------------

    def plot_best_feature_significance(
        self,
        pipeline: RegimeRiskDecompositionPipeline,
    ) -> None:
        """
        Save a robust t-statistic plot and CSV for every individual feature
        that remains in the winning baseline OLS specification.

        T-statistics are plotted instead of raw coefficients because they are
        comparable across variables measured in different units. Raw robust
        coefficients, p-values and 95% confidence intervals remain available
        in the CSV and in the interactive hover information.
        """
        model = pipeline.baseline_model
        if model is None:
            print("Best-feature significance plot skipped: baseline model unavailable.")
            return

        params = pd.Series(model.params).drop(labels="const", errors="ignore")
        if params.empty:
            print("Best-feature significance plot skipped: no retained coefficients.")
            return

        p_values = pd.Series(model.pvalues).reindex(params.index)
        t_values = pd.Series(model.tvalues).reindex(params.index)

        raw_conf_int = model.conf_int(alpha=0.05)
        if isinstance(raw_conf_int, pd.DataFrame):
            confidence_intervals = raw_conf_int.copy()
            confidence_intervals.index = model.params.index
            confidence_intervals.columns = ["CI_95_low", "CI_95_high"]
        else:
            confidence_intervals = pd.DataFrame(
                np.asarray(raw_conf_int),
                index=model.params.index,
                columns=["CI_95_low", "CI_95_high"],
            )
        confidence_intervals = confidence_intervals.reindex(params.index)

        if isinstance(pipeline.feature_blocks, pd.Series):
            blocks = pipeline.feature_blocks.reindex(params.index).fillna("Unknown")
        elif pipeline.feature_blocks is not None:
            blocks = pd.Series(pipeline.feature_blocks).reindex(params.index).fillna("Unknown")
        else:
            blocks = pd.Series("Unknown", index=params.index)

        results = pd.DataFrame({
            "Feature": params.index.astype(str),
            "Coefficient": pd.to_numeric(params, errors="coerce").to_numpy(),
            "T_statistic": pd.to_numeric(t_values, errors="coerce").to_numpy(),
            "P_value": pd.to_numeric(p_values, errors="coerce").to_numpy(),
            "CI_95_low": pd.to_numeric(
                confidence_intervals["CI_95_low"], errors="coerce"
            ).to_numpy(),
            "CI_95_high": pd.to_numeric(
                confidence_intervals["CI_95_high"], errors="coerce"
            ).to_numpy(),
            "Block": blocks.astype(str).to_numpy(),
        }).dropna(subset=["Coefficient", "T_statistic"])

        results["Significant_1pct"] = results["P_value"] < 0.01
        results["Significant_5pct"] = results["P_value"] < 0.05
        results["Significant_10pct"] = results["P_value"] < 0.10

        results["Stars"] = np.select(
            [
                results["P_value"] < 0.01,
                results["P_value"] < 0.05,
                results["P_value"] < 0.10,
            ],
            ["***", "**", "*"],
            default="",
        )
        results["Significance"] = np.select(
            [
                results["P_value"] < 0.01,
                results["P_value"] < 0.05,
                results["P_value"] < 0.10,
            ],
            ["*** p < 0.01", "** p < 0.05", "* p < 0.10"],
            default="Not significant",
        )
        results["Feature_label"] = np.where(
            results["Stars"].eq(""),
            results["Feature"],
            results["Feature"] + " " + results["Stars"],
        )
        results["Abs_t_statistic"] = results["T_statistic"].abs()

        # Ascending order places the strongest absolute t-statistics at the top
        # of the horizontal Plotly chart.
        results = results.sort_values(
            ["Abs_t_statistic", "Feature"],
            ascending=[True, True],
        ).reset_index(drop=True)

        results.to_csv(
            self.data_dir / "best_model_feature_significance.csv",
            index=False,
        )

        significance_order = [
            "*** p < 0.01",
            "** p < 0.05",
            "* p < 0.10",
            "Not significant",
        ]
        significance_colors = {
            "*** p < 0.01": "#1b7837",
            "** p < 0.05": "#5aae61",
            "* p < 0.10": "#9970ab",
            "Not significant": "#969696",
        }
        block_symbols = {
            "Global": "circle",
            "Emerging": "diamond",
            "Bonds": "square",
            "Latent": "triangle-up",
            "Unknown": "x",
        }

        fig = go.Figure()
        for significance in significance_order:
            subset = results.loc[results["Significance"].eq(significance)].copy()
            if subset.empty:
                continue

            customdata = np.column_stack([
                subset["Feature"].astype(str),
                subset["Block"].astype(str),
                subset["Coefficient"].astype(float),
                subset["P_value"].astype(float),
                subset["CI_95_low"].astype(float),
                subset["CI_95_high"].astype(float),
            ])

            fig.add_trace(go.Scatter(
                x=subset["T_statistic"],
                y=subset["Feature_label"],
                mode="markers",
                name=significance,
                marker={
                    "size": 10,
                    "color": significance_colors[significance],
                    "symbol": [
                        block_symbols.get(block, "x")
                        for block in subset["Block"]
                    ],
                    "line": {"width": 0.5, "color": "black"},
                },
                customdata=customdata,
                hovertemplate=(
                    "<b>%{customdata[0]}</b><br>"
                    "Block: %{customdata[1]}<br>"
                    "Robust t-statistic: %{x:.3f}<br>"
                    "Coefficient: %{customdata[2]:.6f}<br>"
                    "Robust p-value: %{customdata[3]:.4g}<br>"
                    "95% CI: [%{customdata[4]:.6f}, %{customdata[5]:.6f}]"
                    "<extra></extra>"
                ),
            ))

        # Zero separates negative from positive effects.
        fig.add_vline(
            x=0.0,
            line_width=1.2,
            line_dash="solid",
            line_color="black",
        )

        # Approximate two-sided normal critical values. Exact significance is
        # still determined by the robust model p-values and displayed by color.
        for threshold, dash in ((1.645, "dot"), (1.960, "dash"), (2.576, "dashdot")):
            fig.add_vline(
                x=-threshold,
                line_width=1,
                line_dash=dash,
                line_color="#7f7f7f",
            )
            fig.add_vline(
                x=threshold,
                line_width=1,
                line_dash=dash,
                line_color="#7f7f7f",
            )

        fig.add_annotation(
            x=1.645,
            y=1.035,
            xref="x",
            yref="paper",
            text="10%",
            showarrow=False,
            font={"size": 10, "color": "#666666"},
        )
        fig.add_annotation(
            x=1.960,
            y=1.035,
            xref="x",
            yref="paper",
            text="5%",
            showarrow=False,
            font={"size": 10, "color": "#666666"},
        )
        fig.add_annotation(
            x=2.576,
            y=1.035,
            xref="x",
            yref="paper",
            text="1%",
            showarrow=False,
            font={"size": 10, "color": "#666666"},
        )

        fig.update_yaxes(
            categoryorder="array",
            categoryarray=results["Feature_label"].tolist(),
            title="Retained feature",
        )
        fig.update_xaxes(
            title="Robust t-statistic",
            zeroline=False,
        )
        fig.update_layout(
            title=(
                "Retained features in the winning specification"
                "<br><sup>Robust t-statistics; raw coefficients, p-values and "
                "95% confidence intervals are available on hover</sup>"
            ),
            template="plotly_white",
            height=max(700, 29 * len(results) + 230),
            margin={"l": 330, "r": 60, "t": 120, "b": 70},
            legend_title_text="Statistical significance",
        )

        fig.write_html(
            self.html_plots_dir / "best_model_feature_significance.html",
            include_plotlyjs="cdn",
            full_html=True,
        )

        if self.cfg.show_final_plots:
            fig.show()

    # ------------------------------------------------------
    # Persistence / plots / cleanup
    # ------------------------------------------------------

    def _save_progress(self) -> None:
        if self.data_results:
            pd.DataFrame(self.data_results).to_csv(self.data_leaderboard_path, index=False)
        if self.results:
            self._finalize_leaderboard()

    def plot_final_diagnostics(self) -> None:
        if self.leaderboard is None or self.leaderboard.empty:
            return
        ok = self.leaderboard.loc[self.leaderboard["status"].eq("ok")].copy()
        if ok.empty:
            return

        by_id = ok.sort_values("global_model_id").copy()
        by_id["running_best"] = by_id["score"].cummax()
        fig = px.line(
            by_id,
            x="global_model_id",
            y=["score", "running_best"],
            title="End-to-end optimizer convergence",
            labels={"global_model_id": "Model trial", "value": "Objective score"},
            template="plotly_white",
        )
        fig.write_html(
            self.html_plots_dir / "optimizer_convergence.html",
            include_plotlyjs="cdn",
            full_html=True,
        )
        if self.cfg.show_final_plots:
            fig.show()

        fig = px.scatter(
            ok,
            x="hmm_r2",
            y="pct_significant",
            color="regime_component_share",
            size="score",
            symbol="eligible",
            hover_data=[
                "rank", "data_id", "model_id", "hmm_adj_r2",
                "regime_incremental_r2", "pct_regime_terms_significant",
                "avg_self_transition", "min_regime_occupancy",
            ],
            title="R², coefficient significance, and Regime-component impact",
            labels={
                "hmm_r2": "HMM-conditioned R²",
                "pct_significant": "Significant coefficients (p < 0.05)",
                "regime_component_share": "Regime share",
            },
            template="plotly_white",
        )
        fig.update_yaxes(tickformat=".0%")
        fig.write_html(
            self.html_plots_dir / "optimizer_r2_significance_regime.html",
            include_plotlyjs="cdn",
            full_html=True,
        )
        if self.cfg.show_final_plots:
            fig.show()

        top = ok.head(15)[[
            "rank", "score", "hmm_r2", "hmm_adj_r2", "pct_significant",
            "regime_component_share", "regime_incremental_r2",
            "pct_regime_terms_significant", "avg_self_transition",
            "data_id", "model_id",
        ]].copy()
        for col in top.columns:
            if col not in {"rank", "data_id", "model_id"}:
                top[col] = pd.to_numeric(top[col], errors="coerce").round(4)

        table = go.Figure(data=[go.Table(
            header=dict(values=[f"<b>{c}</b>" for c in top.columns], align="center"),
            cells=dict(values=[top[c].tolist() for c in top.columns], align="center"),
        )])
        table.update_layout(title="Top 15 end-to-end specifications", height=520)
        table.write_html(
            self.html_plots_dir / "optimizer_top_15_specifications.html",
            include_plotlyjs="cdn",
            full_html=True,
        )
        if self.cfg.show_final_plots:
            table.show()

    def _cleanup_nonwinning_artifacts(self) -> None:
        if not self.trials_dir.exists():
            return
        shutil.rmtree(self.trials_dir, ignore_errors=True)

    def _print_summary(self) -> None:
        assert self.best_result is not None
        print("\n" + "=" * 88)
        print("OPTIMIZER COMPLETE")
        print("=" * 88)
        print(f"Successful model trials   : {int((self.leaderboard['status'] == 'ok').sum()) if self.leaderboard is not None else 0}")
        print(f"Best score                : {float(self.best_result['score']):.4f}")
        print(f"Best HMM R²               : {float(self.best_result['hmm_r2']):.4f}")
        print(f"Best adjusted R²          : {float(self.best_result['hmm_adj_r2']):.4f}")
        print(f"Significant coefficients  : {float(self.best_result['pct_significant']):.1%}")
        print(f"Regime contribution share : {float(self.best_result['regime_component_share']):.1%}")
        print(f"Regime-term significance  : {float(self.best_result['pct_regime_terms_significant']):.1%}")
        print(f"Regime incremental R²     : {float(self.best_result['regime_incremental_r2']):.4f}")
        print(f"Leaderboard               : {self.leaderboard_path}")
        print(f"Data folder               : {self.data_dir}")
        print(f"HTML plots folder         : {self.html_plots_dir}")
        print("=" * 88)


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":
    # The total number of analysis runs is:
    #     N_DATA_VARIANTS × N_MODEL_VARIANTS_PER_DATA
    # Start small to validate paths, then increase for the final search.
    N_DATA_VARIANTS = 4
    N_MODEL_VARIANTS_PER_DATA = 10

    config = OptimizerConfig(
        n_data_variants=N_DATA_VARIANTS,
        n_model_variants_per_data=N_MODEL_VARIANTS_PER_DATA,
        universe_mode="LATAM",
        random_seed=42,
        source_target_col="Z_SPREAD_MID",
        output_root=str(OUTPUT_DIR / "main_results"),
        intermediate_format="parquet",
        show_final_plots=True,
        export_final_tables=True,
        keep_all_trial_artifacts=False,
        # Explicit emphasis requested: fit + significance + Regime impact.
        score_weights={
            "r2": 0.25,
            "adjusted_r2": 0.10,
            "significance": 0.20,
            "regime_component_share": 0.20,
            "regime_term_significance": 0.10,
            "regime_incremental_r2": 0.10,
            "regime_stability": 0.05,
        },
    )

    optimizer = EndToEndPipelineOptimizer(config)
    optimizer.run()

# %%